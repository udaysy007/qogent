-- Find the McGill University university ID (assuming it already exists)
DO $$
DECLARE
    mcgill_id uuid;
BEGIN
    -- Get the ID of McGill University
    SELECT id INTO mcgill_id FROM universities WHERE name = 'McGill University';
    
    -- If McGill University doesn't exist, we don't update anything
    IF mcgill_id IS NOT NULL THEN
        -- Update McGill University with enhanced data
        UPDATE universities
        SET 
            founding_year = 1821,
            campus_image_url = 'https://images.unsplash.com/photo-1566159199020-92b1e7c3baa6?q=80&w=1200',
            student_population = 40000,
            international_student_percentage = 30,
            ranking_the = 46,
            ranking_arwu = 78,
            tuition_fee_domestic = 'CAD 2,500 - CAD 9,500 per year (Quebec residents)',
            tuition_fee_international = 'CAD 23,000 - CAD 56,000 per year',
            application_fee = 'CAD 120',
            other_fees = 'Student services, athletics, and society fees: Approximately CAD 1,500 per year',
            health_insurance = 'Mandatory health insurance for international students: CAD 1,200 per year',
            living_expense_accommodation = 'CAD 10,000 - CAD 15,000 per year',
            living_expense_food = 'CAD 4,000 - CAD 6,000 per year',
            living_expense_transportation = 'CAD 500 - CAD 1,000 per year',
            living_expense_other = 'CAD 2,000 - CAD 4,000 per year',
            housing_info = 'McGill offers guaranteed housing for first-year undergraduate students in its residence halls, with both traditional dormitory-style rooms and apartment-style options. Upper-year and graduate students typically live off-campus in the neighborhoods surrounding the university, such as the Plateau-Mont-Royal, Mile End, and downtown Montreal. The Off-Campus Housing Office assists students in finding suitable apartments and roommates.',
            campus_facilities = ARRAY['Libraries', 'Research Centers', 'Athletic Facilities', 'Student Centers', 'Health Services', 'Innovation Hubs', 'Performing Arts Spaces'],
            international_support = 'International Student Services provides comprehensive support including pre-arrival information, orientation programs, immigration advising, and cultural adjustment activities. The office also assists with health insurance, work permits, and integration into Montreal life.',
            clubs_info = 'McGill has over 230 student clubs and organizations, from academic and cultural groups to sports teams and special interest clubs. Student societies represent various faculties and departments, organizing academic events, social activities, and professional networking opportunities.',
            admission_success_rate = '38%',
            students_placed = 790
        WHERE id = mcgill_id;
        
        -- Clear any existing programs for McGill University and add new ones
        DELETE FROM university_programs 
        WHERE university_id = mcgill_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (mcgill_id, 'Computer Science', 'Bachelor', 'Technology', 'English', '3-4 years', 'A comprehensive program covering algorithms, software development, artificial intelligence, and theoretical computer science with opportunities for research and industry internships.', 'CAD 4,500 (Quebec) / CAD 36,000 (International) per year', 'January 15', true),
        (mcgill_id, 'Medicine', 'Doctor', 'Medicine', 'English', '4 years', 'A prestigious medical program integrating biomedical sciences with clinical training at McGill''s teaching hospitals, known for its emphasis on research and patient-centered care.', 'CAD 9,000 (Quebec) / CAD 56,000 (International) per year', 'November 1', true),
        (mcgill_id, 'Master of Business Administration (MBA)', 'Master', 'Business', 'English', '2 years', 'A globally recognized MBA program emphasizing analytical thinking, leadership, and global business management with options for specializations in various business domains.', 'CAD 47,000 per year (all students)', 'January 15 (Round 2) / March 15 (Round 3)', true),
        (mcgill_id, 'International Development Studies', 'Bachelor', 'Social Sciences', 'English', '3-4 years', 'An interdisciplinary program examining global development challenges through economic, political, and social lenses with opportunities for fieldwork in developing countries.', 'CAD 4,400 (Quebec) / CAD 29,500 (International) per year', 'January 15', false);
        
        -- Clear any existing admission requirements for McGill University and add new ones
        DELETE FROM admission_requirements 
        WHERE university_id = mcgill_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (mcgill_id, 'Academic', 'For Bachelor''s programs: Strong secondary school performance with prerequisites in subjects relevant to your chosen program. For graduate programs: Bachelor''s degree with a minimum GPA of 3.0 (or equivalent). For competitive programs like Medicine, much higher GPAs are expected.', 'McGill places heavy emphasis on academic excellence, particularly in prerequisite subjects. For competitive programs like Medicine or Law, even near-perfect grades may not guarantee admission. Focus on maintaining exceptional grades in all courses relevant to your desired field, as McGill''s admission process is notably more selective than many Canadian universities.'),
        (mcgill_id, 'Language', 'For English-taught programs: Evidence of English proficiency through TOEFL (minimum 100), IELTS (minimum 6.5), or other approved tests. Exceptions for those who have studied for at least 5 years in an English-medium institution.', 'While basic French is not required for admission to English programs, having some French proficiency will significantly enhance your Montreal experience. Consider taking advantage of McGill''s French language courses to help with integration into Quebec society and improve employability in the province.'),
        (mcgill_id, 'Documents', 'Online application, academic transcripts, standardized test scores (if applicable), personal statement or letter of intent, CV, two reference letters (for graduate applicants), portfolio (for certain programs).', 'In your application documents, particularly personal statements, demonstrate how your background aligns with McGill''s emphasis on research and global engagement. As a research-intensive university, McGill values students who show scholarly potential and intellectual curiosity beyond classroom achievements.'),
        (mcgill_id, 'Additional Requirements', 'Some programs require interviews, portfolios, or auditions. Medicine requires the MCAT. Music requires auditions. Architecture and some arts programs require portfolios. Graduate programs often require the GRE or GMAT.', 'For programs requiring additional assessments, preparation should begin months in advance. McGill''s Medicine program, for example, uses a holistic review process that considers not only MCAT scores but also CASPer test results (evaluating interpersonal skills) and interview performance. Research exactly what each program requires and develop a strategic preparation plan.');
        
        -- Clear any existing scholarships for McGill University and add new ones
        DELETE FROM scholarships 
        WHERE university_id = mcgill_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (mcgill_id, 'Major Entrance Scholarships', 'University', 'CAD 3,000 - CAD 12,000 per year (renewable)', 'Prestigious merit-based entrance scholarships awarded to top incoming undergraduate students based on academic excellence and leadership.', 'Incoming undergraduate students with outstanding academic achievement (typically top 1-2% of applicants) and demonstrated leadership skills.', 'Automatically considered upon application to undergraduate programs; select candidates invited to submit supplementary materials.', 'Same as admission application', '2%'),
        (mcgill_id, 'McGill Graduate Excellence Fellowships', 'University', 'CAD 5,000 - CAD 15,000 per year', 'Merit-based funding packages for outstanding graduate students across all disciplines.', 'Incoming Master''s and PhD students with exceptional academic records and research potential.', 'Automatically considered upon application to graduate programs; some departments may require additional application materials.', 'Same as program application', '15%'),
        (mcgill_id, 'Schulich Leader Scholarships', 'Schulich Foundation', 'CAD 100,000 - CAD 120,000 (distributed over 4 years)', 'Canada''s most coveted STEM scholarships for high school graduates enrolling in Science, Technology, Engineering or Mathematics.', 'Canadian high school graduates entering STEM programs who demonstrate academic excellence, leadership, and financial need.', 'Nomination by high school followed by application submission with personal statement and supporting documents.', 'January 30', '1%');
        
        -- Clear any existing FAQs for McGill University and add new ones
        DELETE FROM university_faqs 
        WHERE university_id = mcgill_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (mcgill_id, 'What is McGill University known for?', 'McGill University, founded in 1821, is one of Canada''s most prestigious institutions and has a strong global reputation for academic excellence and research innovation. It''s particularly renowned for medicine, law, engineering, and management programs. McGill has produced 12 Nobel laureates and 145 Rhodes Scholars - the highest in Canada. The university is recognized for its research intensity, ranking among the top research universities in Canada, with particular strengths in neuroscience, artificial intelligence, sustainability, and public policy. Located in Montreal, McGill offers students the opportunity to study in a bilingual, culturally rich environment. The university maintains a strong international outlook, with students from over 150 countries, giving it one of the most internationally diverse student bodies in North America.'),
        (mcgill_id, 'What is student life like in Montreal?', 'Montreal offers one of North America''s most vibrant and unique student experiences. As a bilingual city, it offers the opportunity to experience both French and English cultures. The city is known for its festivals, arts scene, diverse neighborhoods, and relatively affordable cost of living compared to other major North American cities. McGill''s downtown campus is integrated into the heart of Montreal, with Mount Royal park providing a natural retreat just steps from campus. The city''s excellent public transportation system makes it easy for students to explore. Montreal''s food scene is internationally renowned, from casual student-friendly cafes to high-end restaurants. The city has four major universities, creating a significant student population and atmosphere. Winter in Montreal is cold and snowy, but the city embraces the season with winter sports and activities, while summer offers warm weather perfect for outdoor festivals and events. Many students appreciate Montreal''s European charm combined with North American conveniences.'),
        (mcgill_id, 'How does the Canadian university system work?', 'Canadian universities typically offer three academic levels: Bachelor''s (3-4 years), Master''s (1-2 years), and Doctoral degrees (4-6 years). The academic year generally runs from September to April, divided into two semesters, with optional summer courses. Most Canadian universities use a credit system, with full-time students taking 4-5 courses per semester. Grading typically uses a combination of GPA (4.0 scale) and letter grades (A, B, C, etc.). Tuition fees vary significantly between provinces and between domestic and international students. In Quebec, where McGill is located, Quebec residents pay substantially lower tuition than other Canadian or international students. Canadian universities emphasize both theoretical knowledge and practical experience, with many programs offering co-op or internship options. Universities in Canada are largely publicly funded and maintain a high standard of education across the country, though each institution has its own strengths and specializations.'),
        (mcgill_id, 'What research opportunities are available at McGill?', 'McGill is one of Canada''s most research-intensive universities, offering extensive opportunities across disciplines. Undergraduate students can participate through the McGill Undergraduate Research Conference, the Arts Undergraduate Research Internship Awards, the Science Undergraduate Research Awards, and various department-specific research programs. The McGill Research Match portal helps connect students with faculty research projects. Graduate students benefit from McGill''s membership in prestigious research networks and partnerships with research institutes, hospitals, and industry partners. The university houses over 150 research centers and institutes, including the Montreal Neurological Institute, the McGill Space Institute, and the Centre for Intelligent Machines. McGill''s libraries and research facilities provide world-class resources, including rare collections and state-of-the-art laboratories. The university secures approximately CAD 500 million in research funding annually, supporting projects across all faculties.'),
        (mcgill_id, 'What support services are available for international students?', 'McGill provides comprehensive support for international students through International Student Services (ISS), which offers orientation programs, immigration advising, and cultural adjustment workshops. The International Student Network pairs new international students with current McGill students for peer support. The university offers workshops on topics like adapting to the Canadian education system and managing culture shock. ISS advisors provide personalized guidance on immigration matters, including study permits, work permits, and permanent residency pathways. McGill''s health insurance plan for international students covers essential medical services. The Career Planning Service offers specialized support for international students seeking internships and post-graduation employment in Canada. The university''s English and French language courses help students improve their language skills. Cultural celebrations and international community events throughout the year help students maintain connections to their home cultures while experiencing Canadian traditions.');
        
        -- Delete any existing testimonials for McGill University
        DELETE FROM testimonials 
        WHERE university_id = mcgill_id;
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (mcgill_id, 'David Kim', 'https://randomuser.me/api/portraits/men/67.jpg', 'As an international student studying Computer Science at McGill, I''ve found the perfect balance of rigorous academics and vibrant student life. The program is challenging but incredibly rewarding, with professors who are experts in their fields and genuinely care about student success. What sets McGill apart is the remarkable diversity - in my study groups alone, I collaborate with students from at least six different countries, each bringing unique perspectives to problem-solving. Montreal is an amazing city for students, with its blend of European charm and North American energy. The bilingual environment has given me the opportunity to improve my French while studying in English. McGill''s strong industry connections have opened doors to internship opportunities with tech companies in Montreal''s growing tech hub. The winters are definitely cold, but the warm community spirit and the university''s indoor tunnels connecting buildings make it manageable!', 5, true);
    END IF;
END $$; 
-- Find the University College Dublin university ID (assuming it already exists)
DO $$
DECLARE
    ucd_id uuid;
BEGIN
    -- Get the ID of University College Dublin
    SELECT id INTO ucd_id FROM universities WHERE name = 'University College Dublin';
    
    -- If University College Dublin doesn't exist, we don't update anything
    IF ucd_id IS NOT NULL THEN
        -- Update University College Dublin with enhanced data
        UPDATE universities
        SET 
            founding_year = 1854,
            campus_image_url = 'https://images.unsplash.com/photo-1562448079-b5631888209a?q=80&w=1200',
            student_population = 33000,
            international_student_percentage = 29,
            ranking_the = 201,
            ranking_arwu = 301,
            tuition_fee_domestic = '€8,000 per year',
            tuition_fee_international = '€19,900 - €27,400 per year',
            application_fee = '€50',
            other_fees = 'Student levy: €254 per year; Materials fee: Varies by program',
            health_insurance = 'Non-EU students must have health insurance. Cost ranges from €120-€700 depending on coverage.',
            living_expense_accommodation = '€7,000 - €14,000 per year',
            living_expense_food = '€3,000 - €4,000 per year',
            living_expense_transportation = '€500 - €1,000 per year',
            living_expense_other = '€2,000 - €3,000 per year',
            housing_info = 'UCD offers on-campus housing for over 3,800 students across seven residential locations. First-year and international students get priority for on-campus accommodation. Most residences are apartment-style with single rooms in shared units. The UCD Residences Office also assists students in finding off-campus housing options in Dublin.',
            campus_facilities = ARRAY['Libraries', 'Sports Centre', 'Student Centre', 'Science Centre', 'Health Services', 'Innovation Hub', 'Woodland Walkways'],
            international_support = 'UCD Global provides comprehensive support for international students, including pre-arrival guidance, orientation programs, visa and immigration assistance, and ongoing cultural adjustment support. The International Student Society organizes social events and trips throughout the year.',
            clubs_info = 'UCD has over 80 student societies and 60 sports clubs, providing opportunities for students to engage in activities ranging from debate to volunteering, performing arts to entrepreneurship. The UCD Student Union organizes campus events and represents student interests.',
            admission_success_rate = '35%',
            students_placed = 780
        WHERE id = ucd_id;
        
        -- Clear any existing programs for University College Dublin and add new ones
        DELETE FROM university_programs 
        WHERE university_id = ucd_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (ucd_id, 'Computer Science', 'Bachelor', 'Technology', 'English', '4 years', 'UCD''s Computer Science degree offers specializations in areas such as data science, AI, and software engineering, with strong industry connections and internship opportunities.', '€8,000 (EU) / €24,800 (Non-EU) per year', 'February 1 (EU) / May 1 (Non-EU)', true),
        (ucd_id, 'Business and Law', 'Bachelor', 'Business', 'English', '4 years', 'A prestigious dual degree program combining business fundamentals with legal knowledge, preparing graduates for careers in corporate law, consulting, or entrepreneurship.', '€8,000 (EU) / €21,600 (Non-EU) per year', 'February 1 (EU) / May 1 (Non-EU)', true),
        (ucd_id, 'MSc in Data & Computational Science', 'Master', 'Technology', 'English', '1 year', 'An advanced program developing expertise in big data analytics, machine learning, and computational methods with applications across various sectors.', '€10,200 (EU) / €23,800 (Non-EU)', 'May 31', true),
        (ucd_id, 'Medicine', 'Bachelor', 'Medicine', 'English', '6 years', 'UCD''s globally recognized medical program offering comprehensive clinical training in Ireland''s leading teaching hospitals with opportunities for international electives.', '€8,000 (EU) / €55,140 (Non-EU) per year', 'February 1 (EU) / January 15 (Non-EU)', false);
        
        -- Clear any existing admission requirements for University College Dublin and add new ones
        DELETE FROM admission_requirements 
        WHERE university_id = ucd_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (ucd_id, 'Academic', 'For EU applicants: Points-based system through the CAO (typically 480+ points for competitive courses). For Non-EU: Country-specific requirements, generally equivalent to ABB at A-Level or 1800+ on SAT with strong Subject Tests.', 'UCD weighs academic performance heavily, but also considers subject relevance. For competitive programs like Medicine or Law, aim for significantly higher than the minimum requirements and ensure strong performance in relevant subjects.'),
        (ucd_id, 'Language', 'Non-native English speakers need IELTS (minimum 6.5 overall with no band below 6.0), TOEFL (minimum 90 internet-based), or Cambridge Proficiency/Advanced (minimum 180).', 'UCD''s programs involve extensive writing and discussions. Consider preparing by practicing academic writing in English and participating in English-language discussions about your field of interest.'),
        (ucd_id, 'Documents', 'Application through CAO for EU students or direct application for non-EU students. Academic transcripts, personal statement, reference letters, and CV required.', 'In your personal statement, highlight not only your academic achievements but also extracurricular activities and volunteer work. UCD values well-rounded students who can contribute to campus life beyond academics.'),
        (ucd_id, 'Additional Requirements', 'Some courses have additional requirements: HPAT test for Medicine, portfolio for Architecture, audition for Music, etc.', 'Begin preparing for specialized entrance requirements well in advance. For example, HPAT preparation should ideally begin a year before applications open, and Architecture portfolios should demonstrate a range of skills and creative thinking.');
        
        -- Clear any existing scholarships for University College Dublin and add new ones
        DELETE FROM scholarships 
        WHERE university_id = ucd_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (ucd_id, 'Global Excellence Scholarship', 'University', '€2,000 - €12,000 reduction in tuition fees', 'Merit-based scholarships for international students with outstanding academic achievement.', 'Non-EU international students with excellent academic records applying to undergraduate or graduate programs.', 'Automatically considered upon application to your chosen program.', 'Same as program application deadline', '15%'),
        (ucd_id, 'Sport Scholarship', 'University', 'Financial support plus specialized services worth up to €10,000', 'Elite athlete support program providing financial assistance, specialized coaching, medical support, and academic flexibility.', 'Students competing at national or international level in their sport.', 'Submit application with supporting documentation of sporting achievements.', 'April 30', '8%'),
        (ucd_id, 'Science Foundation Ireland Research Scholarship', 'SFI/University', 'Full tuition fees plus €18,500 annual stipend', 'Prestigious scholarships for outstanding PhD candidates in science, technology, engineering, and mathematics.', 'Exceptional students pursuing PhD research in STEM fields with a strong research proposal.', 'Apply through the UCD School with research proposal and academic references.', 'January 31 and June 30', '7%');
        
        -- Clear any existing FAQs for University College Dublin and add new ones
        DELETE FROM university_faqs 
        WHERE university_id = ucd_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (ucd_id, 'What is University College Dublin known for?', 'University College Dublin (UCD) is Ireland''s largest university and a leading research institution in Europe. It''s particularly renowned for its programs in Business, Law, Agriculture, Veterinary Medicine, and Computer Science. UCD has a large, modern campus in Belfield, about 4km south of Dublin city center. The university emphasizes internationalization and innovation, with strong connections to industry and research centers worldwide.'),
        (ucd_id, 'What is the UCD Horizons system?', 'UCD Horizons is a flexible modular curriculum structure that allows students to customize their education. Students take core modules in their main subject area plus elective modules that can be within their field or from other disciplines. This system enables students to broaden their education, explore other interests, or specialize further in their main field. Each module carries credits under the European Credit Transfer System (ECTS), with students typically completing 60 credits per academic year.'),
        (ucd_id, 'How does UCD support international students?', 'UCD Global provides comprehensive support for international students, starting with pre-arrival information and welcome guides. Upon arrival, students can participate in orientation programs specific to international students. Throughout their studies, UCD offers cultural and social activities, visa and immigration advice, and academic support. The International Student Society organizes events and trips, helping students connect and explore Ireland. UCD has a diverse campus with students from over 140 countries.'),
        (ucd_id, 'What is campus life like at UCD?', 'UCD offers a vibrant campus experience on its 133-hectare campus in Belfield. The campus features modern facilities including a state-of-the-art student center, Olympic-standard sports facilities, woodland walks, and numerous cafes and restaurants. The Student Union organizes regular events and manages over 80 societies and 60 sports clubs. UCD''s proximity to Dublin city center (about 15 minutes by bus) also gives students easy access to the cultural and social life of Ireland''s capital.'),
        (ucd_id, 'What career services does UCD offer?', 'UCD Career Development Centre provides comprehensive support for career planning and job searches. Services include one-on-one career coaching, CV and interview workshops, career assessment tools, and employer networking events. The center organizes several career fairs throughout the year, bringing employers to campus. Many UCD programs include internship or placement opportunities, and the university maintains strong connections with employers across various industries. UCD has a strong record of graduate employability, with 96% of graduates employed or in further study within nine months of graduation.');
        
        -- Delete any existing testimonials for University College Dublin
        DELETE FROM testimonials 
        WHERE university_id = ucd_id;
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (ucd_id, 'Sarah Chen', 'https://randomuser.me/api/portraits/women/76.jpg', 'Studying Business at UCD has given me both academic knowledge and practical experience that''s invaluable in today''s job market. The Horizons system allowed me to complement my business studies with modules in data analytics, which has made me much more competitive. The international atmosphere on campus is amazing - I''ve made friends from at least 20 different countries! The campus facilities are excellent, especially the student center and sports center, and Dublin is an amazing city to live in as a student.', 5, true);
    END IF;
END $$; 
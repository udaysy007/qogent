-- Find the National University of Singapore university ID (assuming it already exists)
DO $$
DECLARE
    nus_id uuid;
BEGIN
    -- Get the ID of National University of Singapore
    SELECT id INTO nus_id FROM universities WHERE name = 'National University of Singapore';
    
    -- If National University of Singapore doesn't exist, we don't update anything
    IF nus_id IS NOT NULL THEN
        -- Update National University of Singapore with enhanced data
        UPDATE universities
        SET 
            founding_year = 1905,
            campus_image_url = 'https://images.unsplash.com/photo-1600352761482-50c8b8df23ce?q=80&w=1200',
            student_population = 38000,
            international_student_percentage = 30,
            ranking_the = 19,
            ranking_arwu = 86,
            tuition_fee_domestic = 'SGD 8,200 - SGD 12,900 per year (subsidized for Singaporeans)',
            tuition_fee_international = 'SGD 17,550 - SGD 46,050 per year',
            application_fee = 'SGD 20',
            other_fees = 'Student services fee: SGD 300 per year',
            health_insurance = 'Mandatory for all students: SGD 250 per year',
            living_expense_accommodation = 'SGD 3,600 - SGD 11,400 per year',
            living_expense_food = 'SGD 3,600 - SGD 7,200 per year',
            living_expense_transportation = 'SGD 1,000 - SGD 1,500 per year',
            living_expense_other = 'SGD 2,000 - SGD 3,000 per year',
            housing_info = 'NUS offers on-campus accommodation in six residential colleges, halls of residence, and student residences. Each has its own unique culture and programs. Priority is given to international students, scholars, and freshmen. The university also assists students in finding off-campus housing through its hostel services office. Most campus residences offer various room types from single to shared accommodations, with options for air-conditioning and meal plans.',
            campus_facilities = ARRAY['Libraries', 'Sports Facilities', 'Medical Center', 'Student Hubs', 'Cultural Centers', 'Research Centers', 'Innovation Labs'],
            international_support = 'The NUS International Relations Office provides comprehensive support for international students, including pre-arrival guidance, orientation programs, visa assistance, and cultural integration activities. The university also offers peer mentoring programs pairing international students with local buddies.',
            clubs_info = 'NUS has over 200 student organizations spanning academic, cultural, arts, sports, and special interest areas. The NUS Students'' Union coordinates many campus-wide events and represents student interests. Each faculty and residence also has its own societies organizing discipline-specific or residential activities.',
            admission_success_rate = '25%',
            students_placed = 820
        WHERE id = nus_id;
        
        -- Clear any existing programs for National University of Singapore and add new ones
        DELETE FROM university_programs 
        WHERE university_id = nus_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (nus_id, 'Computer Science', 'Bachelor', 'Technology', 'English', '4 years', 'A comprehensive program exploring algorithms, software development, artificial intelligence, and data science with research opportunities and strong industry connections.', 'SGD 8,200 (Subsidized) / SGD 20,550 (International) per year', 'December 1 (International) / March 1 (Local)', true),
        (nus_id, 'Medicine', 'Bachelor', 'Medicine', 'English', '5 years', 'A rigorous program integrating biomedical sciences with clinical training at NUS teaching hospitals, emphasizing medical research, professional ethics, and patient-centered care.', 'SGD 12,900 (Subsidized) / SGD 46,050 (International) per year', 'December 1 (International) / March 1 (Local)', true),
        (nus_id, 'MBA', 'Master', 'Business', 'English', '17 months', 'A globally recognized MBA program with focus on Asian business perspectives, leadership development, and international immersion opportunities with over 20 exchange partners worldwide.', 'SGD 62,000 (all students)', 'October 31 (Round 1) / January 31 (Round 2) / March 31 (Round 3)', true),
        (nus_id, 'Master of Environmental Management', 'Master', 'Environmental Science', 'English', '1 year', 'An interdisciplinary program addressing environmental challenges with focus on sustainable development, environmental policy, and management practices relevant to tropical and Asian contexts.', 'SGD 30,000 (all students)', 'January 31', false);
        
        -- Clear any existing admission requirements for National University of Singapore and add new ones
        DELETE FROM admission_requirements 
        WHERE university_id = nus_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (nus_id, 'Academic', 'For Bachelor''s programs: Excellent high school qualification equivalent to Singapore-Cambridge GCE ''A'' Levels or International Baccalaureate (IB). For graduate programs: Bachelor''s degree with at least second upper honors (or equivalent) from a recognized university.', 'NUS is one of Asia''s most competitive universities, and successful applicants typically rank in the top 10-15% of their cohort. For programs like Medicine, Law, and Computer Science, competition is exceptionally intense, and candidates need near-perfect academic records. The university places significant weight on subject relevance - strong performance in subjects directly related to your chosen program is more important than overall GPA.'),
        (nus_id, 'Language', 'For all programs: TOEFL (minimum 100 internet-based), IELTS (minimum 6.5 overall, with no sub-score below 6.0), or other approved tests. Exemptions for those from English-medium institutions.', 'While Singapore is an English-speaking country, academic English at NUS is rigorous and demanding. Strong writing skills are particularly important for success. If your scores are borderline, consider taking additional academic English courses before applying, as competition for places means that meeting the minimum may not be sufficient for competitive programs.'),
        (nus_id, 'Documents', 'Online application, academic transcripts, personal statement, CV, recommendation letters (for graduate applicants), standardized test scores (if applicable), and copy of passport.', 'Your personal statement should demonstrate not only academic excellence but also how you align with Singapore''s meritocratic values and multicultural environment. NUS looks for students who can contribute to both academic and campus life, so highlight extracurricular achievements that demonstrate leadership and initiative.'),
        (nus_id, 'Additional Requirements', 'Medicine, Dentistry, Law, and Architecture require interviews. Some faculties may require additional tests or written assessments. MBA and certain graduate programs require GMAT/GRE scores.', 'For programs requiring interviews, thorough preparation is essential. Research shows only about 10-20% of applicants are invited to interview for Medicine, and of those, about half receive offers. Prepare for scenario-based questions and ethical dilemmas, particularly for healthcare programs. For business programs, emphasize your understanding of Asia''s role in the global economy.');
        
        -- Clear any existing scholarships for National University of Singapore and add new ones
        DELETE FROM scholarships 
        WHERE university_id = nus_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (nus_id, 'ASEAN Undergraduate Scholarship', 'University', 'Full tuition plus annual living allowance of SGD 5,800', 'Prestigious scholarships for outstanding students from ASEAN countries pursuing undergraduate studies at NUS.', 'Citizens of ASEAN countries (except Singapore) with excellent academic achievements and strong co-curricular records.', 'Apply through the NUS scholarship application system after applying for admission.', 'Same as admission application', '8%'),
        (nus_id, 'Science & Technology Undergraduate Scholarship', 'Singapore Ministry of Education', 'Full tuition, living allowance of SGD 6,000 per year, and other benefits', 'Scholarships for exceptional students pursuing undergraduate degrees in science and technology disciplines at NUS.', 'Singaporean citizens and permanent residents with outstanding academic results and strong interest in science and technology.', 'Apply through the MOE scholarship portal with supporting documents.', 'March 31', '15%'),
        (nus_id, 'NUS Research Scholarship', 'University', 'Full tuition plus monthly stipend of SGD 1,800 - SGD 2,500', 'Scholarships for outstanding graduate students pursuing research-based master''s or doctoral studies at NUS.', 'Excellent academic record with research potential. Open to all nationalities.', 'Apply through the respective faculty/department when applying for graduate admission.', 'Same as program application', '25%');
        
        -- Clear any existing FAQs for National University of Singapore and add new ones
        DELETE FROM university_faqs 
        WHERE university_id = nus_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (nus_id, 'What is NUS known for?', 'The National University of Singapore (NUS) is consistently ranked as one of Asia''s top universities and among the world''s leading institutions. Founded in 1905, it''s known for excellence across disciplines, with particular strengths in engineering, computer science, medicine, business, and social sciences. NUS is renowned for its innovative approach to education, including its Yale-NUS College liberal arts program (a collaboration with Yale University) and entrepreneurship initiatives. The university is a research powerhouse, especially in areas like quantum technologies, artificial intelligence, biomedical sciences, and Asian studies. NUS places strong emphasis on global exposure through its extensive exchange programs, overseas colleges, and international research collaborations. The university''s campus combines modern facilities with lush tropical greenery, reflecting Singapore''s reputation as a "garden city." NUS graduates are highly sought after by employers globally, with the university consistently ranked among the top 20 in the world for graduate employability.'),
        (nus_id, 'What is student life like in Singapore?', 'Singapore offers a unique student experience combining Asian and Western influences in a safe, efficient, and cosmopolitan environment. As a global hub for business, technology, and education, Singapore provides numerous internship and networking opportunities across industries. NUS campus life is vibrant, with a wide range of student organizations, cultural events, and recreational activities. The tropical climate means warm weather year-round, though most buildings are well air-conditioned. Singapore''s food scene is legendary, with affordable and diverse options from hawker centers to international restaurants. The city-state has excellent public transportation, making it easy to navigate without a car. While Singapore is one of the safest cities in the world, it also has strict laws that students should familiarize themselves with. The cost of living is higher than in most Southeast Asian countries but lower than in many Western cities. Singapore''s strategic location makes it an excellent base for exploring the rest of Asia during term breaks. The multicultural environment, with Chinese, Malay, Indian, and Western influences, creates a rich cultural tapestry that mirrors global business environments.'),
        (nus_id, 'How does the NUS academic system work?', 'NUS follows a modular system similar to North American universities, where students accumulate credits through various modules (courses). Most undergraduate programs take 3-4 years to complete, while graduate programs range from 1-2 years for master''s degrees and 3-5 years for PhDs. The academic year consists of two regular semesters (August-December and January-May) and an optional special term during the summer. NUS uses a 5-point Cumulative Average Point (CAP) grading system, with 5.0 being the highest. The university offers various degree types including honors degrees, which require a higher credit load and typically a thesis or capstone project. NUS emphasizes multidisciplinary learning, with students encouraged to take modules outside their main field of study. Many programs incorporate practical experiences through internships, research projects, or community service. The university''s global dimension includes numerous exchange opportunities, double degree programs with international partner universities, and the NUS Overseas Colleges entrepreneurship program.'),
        (nus_id, 'What research opportunities are available at NUS?', 'NUS is one of Asia''s premier research universities, offering extensive research opportunities across all levels. The university has over 30 university-level research institutes and centers, including the Centre for Quantum Technologies, the Mechanobiology Institute, and the Risk Management Institute. Undergraduate students can participate in the Undergraduate Research Opportunities Programme (UROP), which allows them to work on faculty-led research projects for academic credit. The NUS Student Research Opportunities Platform connects students with research openings across the university. Graduate research opportunities are available through research-based master''s and PhD programs, with significant funding support available through various scholarships and research grants. NUS maintains research collaborations with top global universities and research institutions, providing international research exposure. The university''s close ties with industry and government research agencies create opportunities for applied research with real-world impact. NUS secures approximately SGD 600 million in research funding annually, supporting cutting-edge research across disciplines.'),
        (nus_id, 'What career support does NUS provide?', 'NUS offers comprehensive career services through the Centre for Future-ready Graduates, which provides career counseling, resume and interview preparation, career assessments, and job search strategies. The university hosts multiple career fairs annually, bringing hundreds of employers to campus. NUS maintains strong connections with employers across industries, with many companies specifically recruiting NUS graduates. The NUS Internship-as-a-Learning programme integrates internships into the curriculum, allowing students to earn academic credit while gaining work experience. The NUS Overseas Colleges program enables entrepreneurially-minded students to work in startups in global innovation hubs while taking courses at partner universities. Many programs incorporate industry-relevant projects or capstone experiences that build practical skills valued by employers. The university''s Innovation and Entrepreneurship unit supports students interested in startups through mentorship, funding, and incubation spaces. The NUS alumni network spans over 300,000 graduates worldwide, creating valuable professional connections. The university''s global reputation opens doors for international career opportunities, with graduates working in multinational companies and organizations worldwide.');
        
        -- Delete any existing testimonials for National University of Singapore
        DELETE FROM testimonials 
        WHERE university_id = nus_id;
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (nus_id, 'Aditya Patel', 'https://randomuser.me/api/portraits/men/36.jpg', 'My experience studying Computer Science at NUS has been transformative both academically and personally. The program is rigorous and cutting-edge, with courses that blend theoretical foundations with practical applications in areas like AI and data science. What sets NUS apart is the global perspective - in my cohort alone, I have classmates from over 20 countries, creating a truly international learning environment. The professors are not only leading researchers but also dedicated teachers who challenge us to think critically and innovatively. Through the NUS Overseas College program, I spent a semester in Silicon Valley interning at a tech startup while taking entrepreneurship courses at Stanford. This experience gave me invaluable insights into the global tech industry and helped me build an international professional network. The university''s strong industry connections have opened doors for internships and job opportunities with tech giants that have a significant presence in Singapore. Beyond academics, Singapore itself is an incredible place to live and study - safe, efficient, and a perfect gateway to exploring Asia.', 5, true);
    END IF;
END $$; 
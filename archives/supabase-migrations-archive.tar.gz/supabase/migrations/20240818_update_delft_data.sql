-- Find the Delft University of Technology university ID (assuming it already exists)
DO $$
DECLARE
    delft_id uuid;
BEGIN
    -- Get the ID of Delft University of Technology
    SELECT id INTO delft_id FROM universities WHERE name = 'Delft University of Technology';
    
    -- If Delft University of Technology doesn't exist, we don't update anything
    IF delft_id IS NOT NULL THEN
        -- Update Delft University of Technology with enhanced data
        UPDATE universities
        SET 
            founding_year = 1842,
            campus_image_url = 'https://images.unsplash.com/photo-1624962483365-0623e7d6de2f?q=80&w=1200',
            student_population = 26000,
            international_student_percentage = 30,
            ranking_the = 58,
            ranking_arwu = 151,
            tuition_fee_domestic = '€2,209 per year',
            tuition_fee_international = '€15,500 - €19,600 per year',
            application_fee = '€100',
            other_fees = 'Student services fee: Varies by program',
            health_insurance = 'EU students can use European Health Insurance Card; non-EU students need private health insurance (approximately €50-€100 per month)',
            living_expense_accommodation = '€4,800 - €9,600 per year',
            living_expense_food = '€2,400 - €4,800 per year',
            living_expense_transportation = '€700 - €1,500 per year',
            living_expense_other = '€1,200 - €2,400 per year',
            housing_info = 'TU Delft does not directly provide student housing but works with housing providers like DUWO and The Student Hotel. The university provides priority for international students through the Housing Office, but housing is limited and competitive. Most accommodations are shared student houses with private bedrooms and shared kitchens/bathrooms, located within biking distance of campus.',
            campus_facilities = ARRAY['State-of-the-art Laboratories', 'Libraries', 'Sports Centers', 'Cultural Centers', 'Student Associations Facilities', 'Innovation Hubs', 'Dream Hall (Prototype Workshop)'],
            international_support = 'The International Office provides support for international students, including pre-arrival information, visa assistance, orientation weeks, buddy programs, and ongoing cultural adaptation support. TU Delft has an active international student community with mentorship programs and cultural events.',
            clubs_info = 'TU Delft has over 100 student associations, including study associations linked to specific faculties, sports clubs, cultural organizations, and student teams that participate in international competitions. D.S.V. "Sint Jansbrug" is the main social student association, organizing events, parties, and activities throughout the year.',
            admission_success_rate = '31%',
            students_placed = 540
        WHERE id = delft_id;
        
        -- Clear any existing programs for Delft University of Technology and add new ones
        DELETE FROM university_programs 
        WHERE university_id = delft_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (delft_id, 'Aerospace Engineering', 'Bachelor', 'Engineering', 'English', '3 years', 'A comprehensive program covering aircraft and spacecraft design, aerodynamics, materials, and systems engineering with strong connections to the Dutch aerospace industry.', '€2,209 (EU) / €15,500 (Non-EU) per year', 'January 15 (Numerus Fixus program)', true),
        (delft_id, 'Architecture', 'Master', 'Architecture', 'English', '2 years', 'A globally recognized program combining design creativity with technical knowledge and sustainability principles, offering specializations in building technology, urbanism, and landscape architecture.', '€2,209 (EU) / €19,600 (Non-EU) per year', 'March 1 (non-EU) / June 1 (EU)', true),
        (delft_id, 'Computer Science and Engineering', 'Bachelor', 'Technology', 'English', '3 years', 'A rigorous program covering programming, algorithms, artificial intelligence, data science, and computer systems with hands-on project work and industrial collaborations.', '€2,209 (EU) / €15,500 (Non-EU) per year', 'January 15 (Non-EU) / April 1 (EU)', true),
        (delft_id, 'MSc in Sustainable Energy Technology', 'Master', 'Engineering', 'English', '2 years', 'An interdisciplinary program developing expertise in renewable energy systems, energy efficiency, and sustainable energy transitions with research opportunities at leading Dutch energy institutes.', '€2,209 (EU) / €19,600 (Non-EU) per year', 'December 1 (Non-EU with scholarship) / March 1 (all others)', false);
        
        -- Clear any existing admission requirements for Delft University of Technology and add new ones
        DELETE FROM admission_requirements 
        WHERE university_id = delft_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (delft_id, 'Academic', 'For Bachelor''s programs: Secondary school diploma equivalent to Dutch VWO with strong focus on mathematics, physics, and chemistry. For Master''s programs: Relevant Bachelor''s degree from recognized university with good GPA (typically 75% or higher).', 'TU Delft prioritizes mathematical and scientific proficiency above all else. For competitive programs like Aerospace Engineering and Architecture, having exceptional grades in mathematics and physics is crucial, even more so than overall GPA.'),
        (delft_id, 'Language', 'For English-taught programs: IELTS (minimum 6.5 overall, no band below 6.0), TOEFL (minimum 90 internet-based), or Cambridge C1 Advanced/C2 Proficiency (minimum 180).', 'The technical nature of TU Delft''s programs requires strong English comprehension. Beyond meeting minimum requirements, developing technical vocabulary in your field will significantly enhance your academic success.'),
        (delft_id, 'Documents', 'Online application, CV, motivation letter, academic transcripts, diploma, proof of English proficiency, letters of recommendation for some programs.', 'In your motivation letter, emphasize specific aspects of TU Delft''s approach or facilities that align with your interests. The university values students who show genuine interest in their specific methodology and research areas.'),
        (delft_id, 'Additional Requirements', 'Some programs have limited spaces (Numerus Fixus) requiring earlier applications. Architecture and Industrial Design programs require portfolios. Some programs have additional subject tests or prerequisite coursework.', 'For Numerus Fixus programs like Aerospace Engineering and Industrial Design, apply as early as possible. If a portfolio is required, showcase projects demonstrating technical skills alongside creative problem-solving abilities, as TU Delft values this combination.');
        
        -- Clear any existing scholarships for Delft University of Technology and add new ones
        DELETE FROM scholarships 
        WHERE university_id = delft_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (delft_id, 'Justus & Louise van Effen Excellence Scholarships', 'University', 'Full tuition fees plus €11,500 per year for living expenses', 'Prestigious scholarships for exceptional international Master''s students, covering full tuition and living expenses.', 'Non-EU/EEA students applying to Master''s programs with outstanding academic records and demonstrated leadership potential.', 'Apply through the regular TU Delft scholarship application portal after being admitted to a Master''s program.', 'December 1', '3%'),
        (delft_id, 'Holland Scholarship', 'Dutch Ministry of Education and TU Delft', '€5,000 (one-time payment)', 'Scholarships for non-EEA international students studying Bachelor''s or Master''s programs in the Netherlands.', 'Non-EU/EEA students with excellent academic records applying for first year of a degree program.', 'Apply through the TU Delft scholarship application portal after being admitted to a program.', 'February 1', '15%'),
        (delft_id, 'DAAD-TU Delft Scholarship', 'DAAD and TU Delft', 'Tuition fee waiver plus €750 per month for living expenses', 'Scholarships for German students pursuing Master''s degrees at TU Delft.', 'German students with excellent academic records applying to Master''s programs at TU Delft.', 'Apply through the DAAD portal and indicate interest in the TU Delft scholarship application.', 'October 15', '8%');
        
        -- Clear any existing FAQs for Delft University of Technology and add new ones
        DELETE FROM university_faqs 
        WHERE university_id = delft_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (delft_id, 'What is TU Delft known for?', 'TU Delft (Delft University of Technology) is the oldest and largest technical university in the Netherlands, globally renowned for its engineering and technical programs. It''s particularly distinguished in water management, architecture, civil engineering, aerospace engineering, and sustainable energy technology. The university has strong industry connections, especially with major Dutch corporations and the European Space Agency. TU Delft is known for its practical, problem-solving approach to education, innovative research, and focus on addressing global challenges through technology.'),
        (delft_id, 'How does the Dutch education system work at TU Delft?', 'TU Delft follows the European credit system (ECTS), where each academic year consists of 60 credits. The academic year is divided into four quarters of ten weeks each. Most courses are worth 5 ECTS and run for one quarter, though some larger projects may span multiple quarters. The grading system uses a 1-10 scale, with 6 being the minimum passing grade. Dutch education emphasizes self-directed learning, group work, and practical applications. At TU Delft, there''s particular focus on project-based learning, with many courses culminating in team-based design or research projects.'),
        (delft_id, 'What is student life like in Delft?', 'Delft is a charming, historic Dutch city with a strong student culture. About 15% of Delft''s population are students, creating a vibrant atmosphere. Most students get around by bicycle on the city''s extensive cycling infrastructure. Student associations play a major role in social life, with events, parties, sports competitions, and cultural activities throughout the year. The historic city center offers cafes, restaurants, and cultural venues, while the compact size makes everything accessible. Delft''s location is also strategic - it''s just a short train ride to major cities like Rotterdam and The Hague, and Amsterdam is less than an hour away.'),
        (delft_id, 'What are the career opportunities after graduating from TU Delft?', 'TU Delft graduates are highly sought after by employers worldwide. The university''s strong industry connections lead to excellent job placement rates, particularly in engineering, technology, and design fields. The TU Delft Career Centre offers services including career counseling, CV reviews, interview preparation, and job fairs. Many programs include internships or projects with industry partners, providing professional experience and networking opportunities. The Netherlands'' favorable visa regulations allow international graduates to stay for up to one year to find work (orientation year visa). Many multinational companies recruit directly from TU Delft, including Shell, Philips, ASML, Airbus, and various engineering consultancies.'),
        (delft_id, 'How does TU Delft support innovation and entrepreneurship?', 'TU Delft has one of Europe''s strongest ecosystems for technology innovation and startups. The university houses YES!Delft, one of the top university-linked business incubators in Europe, which has helped launch over 200 companies. The TU Delft Valorisation Centre supports researchers and students in commercializing their innovations through patents, licensing, and startup formation. The university''s Dream Hall provides workspace for student teams developing technologies for international competitions, like solar cars and hyperloop concepts. Many courses incorporate entrepreneurial projects, and the university offers minor programs in entrepreneurship. TU Delft also hosts regular hackathons, innovation challenges, and startup weekends to foster creative problem-solving and business development skills.');
        
        -- Delete any existing testimonials for Delft University of Technology
        DELETE FROM testimonials 
        WHERE university_id = delft_id;
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (delft_id, 'Elena Petrov', 'https://randomuser.me/api/portraits/women/54.jpg', 'Studying Aerospace Engineering at TU Delft has been the most challenging and rewarding experience of my life. The program is intensely technical and demanding, but the quality of education is exceptional. What I particularly value is the hands-on approach - we''re constantly applying theory to practical projects, from building small aircraft components to designing satellite systems. The professors are leading experts who bring real industry challenges into the classroom. Campus life is vibrant with students from all over the world, and the Dutch biking culture makes getting around incredibly convenient. If you''re passionate about engineering and ready for a challenge, TU Delft is the place to be.', 5, true);
    END IF;
END $$; 
-- Find the Stanford university ID (assuming it already exists)
DO $$
DECLARE
    stanford_id uuid;
BEGIN
    -- Get the ID of Stanford
    SELECT id INTO stanford_id FROM universities WHERE name = 'Stanford University';
    
    -- If Stanford doesn't exist, we don't update anything
    IF stanford_id IS NOT NULL THEN
        -- Update Stanford with enhanced data
        UPDATE universities
        SET 
            founding_year = 1885,
            campus_image_url = 'https://images.unsplash.com/photo-1541625602330-2277a4c46182?q=80&w=1200',
            student_population = 17249,
            international_student_percentage = 24,
            ranking_the = 3,
            ranking_arwu = 2,
            tuition_fee_domestic = '$56,169 per year',
            tuition_fee_international = '$56,169 per year',
            application_fee = '$90',
            other_fees = 'Student activity fee: $171, Health fee: $695',
            health_insurance = 'Cardinal Care: $6,768 per year',
            living_expense_accommodation = '$10,800 - $16,433 per year',
            living_expense_food = '$7,559 per year',
            living_expense_transportation = '$1,000 - $1,500 per year',
            living_expense_other = '$2,700 - $3,500 per year',
            housing_info = 'Stanford guarantees four years of housing for undergraduates. First-year students live in residence halls in one of eight residential neighborhoods. Upperclassmen can choose from various housing options including row houses, theme houses, apartments, and suites.',
            campus_facilities = ARRAY['Libraries', 'Research Centers', 'Recreation Facilities', 'Performance Venues', 'Museums', 'Medical Center', 'Innovation Labs'],
            international_support = 'The Bechtel International Center offers comprehensive services for international students, including immigration advising, cultural adjustment programs, and social activities.',
            clubs_info = 'Stanford has over 600 student organizations and clubs spanning academics, arts, athletics, community service, entrepreneurship, politics, and cultural interests.',
            admission_success_rate = '42%',
            students_placed = 780
        WHERE id = stanford_id;
        
        -- Clear any existing programs for Stanford and add new ones
        DELETE FROM university_programs 
        WHERE university_id = stanford_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (stanford_id, 'Computer Science', 'Bachelor', 'Technology', 'English', '4 years', 'Stanford''s CS program offers a comprehensive curriculum covering theory, systems, artificial intelligence, and human-computer interaction.', '$56,169 per year', 'Regular: January 5, Early: November 1', true),
        (stanford_id, 'Symbolic Systems', 'Bachelor', 'Interdisciplinary', 'English', '4 years', 'An interdisciplinary program combining computer science, psychology, linguistics, and philosophy to study human and computational systems.', '$56,169 per year', 'Regular: January 5, Early: November 1', true),
        (stanford_id, 'MBA', 'Master', 'Business', 'English', '2 years', 'The Stanford Graduate School of Business MBA emphasizes leadership, innovation, and global perspective through rigorous coursework and experiential learning.', '$76,950 per year', 'Round 1: September, Round 2: January, Round 3: April', true),
        (stanford_id, 'MS in Computer Science (AI specialization)', 'Master', 'Technology', 'English', '1-2 years', 'Advanced study in artificial intelligence, machine learning, computer vision, and natural language processing with opportunities for cutting-edge research.', '$58,281 per year', 'December 6', false);
        
        -- Clear any existing admission requirements for Stanford and add new ones
        DELETE FROM admission_requirements 
        WHERE university_id = stanford_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (stanford_id, 'Academic', 'Exceptional academic achievement in challenging courses. No minimum GPA or test score requirements, but admitted students typically have top grades in the most rigorous courses available at their school. SAT/ACT optional but considered if submitted.', 'Stanford values intellectual vitality over perfect grades. Demonstrate your passion for learning by pursuing advanced coursework in areas that genuinely interest you, not just to impress admissions officers.'),
        (stanford_id, 'Language', 'For international students: TOEFL (minimum 100), IELTS (minimum 7.0), or Duolingo English Test (minimum 120) required if English is not your native language.', 'Stanford''s collaborative learning environment requires strong communication skills. Even if you meet the minimum requirements, consider highlighting experiences that demonstrate your ability to communicate complex ideas effectively in English.'),
        (stanford_id, 'Documents', 'Common Application or Coalition Application, Stanford supplemental essays, school report and transcripts, counselor recommendation, two teacher recommendations, mid-year report.', 'Stanford''s supplemental essays are crucial for demonstrating fit. Use them to showcase your intellectual curiosity, how you''ll contribute to the community, and your distinctive perspective.'),
        (stanford_id, 'Additional Requirements', 'Optional arts portfolio for students with exceptional talent. Some programs require subject-specific achievement tests or additional materials.', 'If you have extraordinary talent or accomplishments in a specific area, be sure to highlight them through the appropriate supplementary materials. Stanford looks for students who will make significant contributions in their fields.');
        
        -- Clear any existing scholarships for Stanford and add new ones
        DELETE FROM scholarships 
        WHERE university_id = stanford_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (stanford_id, 'Stanford Need-Based Financial Aid', 'University', 'Average award: $58,494 per year', 'Stanford meets 100% of demonstrated financial need for all admitted domestic students. Families with incomes below $75,000 pay no tuition, room, or board, while those with incomes below $150,000 receive full tuition coverage.', 'Based on financial need as determined by CSS Profile and FAFSA. Available to all U.S. citizens and permanent residents.', 'Submit CSS Profile, FAFSA, and supporting financial documents.', 'Priority deadline: December 1', '80%'),
        (stanford_id, 'Knight-Hennessy Scholars Program', 'University', 'Full tuition and living stipend', 'Prestigious graduate fellowship covering full cost of attendance for any Stanford graduate degree, plus leadership development programming.', 'Graduate applicants demonstrating academic excellence, leadership potential, and commitment to addressing global challenges.', 'Separate application in addition to degree program application.', 'October', '2%'),
        (stanford_id, 'Stanford International Undergraduate Financial Aid', 'University', 'Varies based on need', 'Need-based financial aid for international undergraduate students, though funding is limited and highly competitive.', 'International students with demonstrated financial need and exceptional academic and extracurricular achievements.', 'Submit CSS Profile and International Student Supplement.', 'Same as admission deadline', '10%');
        
        -- Clear any existing FAQs for Stanford and add new ones
        DELETE FROM university_faqs 
        WHERE university_id = stanford_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (stanford_id, 'What is Stanford''s quarter system?', 'Stanford operates on a quarter system with three main academic quarters: Autumn (September-December), Winter (January-March), and Spring (April-June). A shorter Summer Quarter is also offered. Each quarter lasts approximately 10 weeks followed by a final exam period. The quarter system allows students to take more courses and explore diverse subjects during their Stanford career.'),
        (stanford_id, 'What is the Stanford Core Curriculum?', 'The Stanford Core Curriculum ensures breadth of study across disciplines. Undergraduates must fulfill requirements in Writing and Rhetoric, Ways of Thinking/Ways of Doing (including aesthetic and interpretive inquiry, social inquiry, scientific method and analysis, formal reasoning, applied quantitative reasoning, creative expression, and ethical reasoning), and Language.'),
        (stanford_id, 'Does Stanford have an Early Decision program?', 'Stanford offers Restrictive Early Action (REA), which is non-binding, rather than Early Decision. Under REA, students apply by November 1 and receive a decision by December 15. If admitted, students have until May 1 to decide whether to attend. REA applicants cannot apply to any other private college''s early program but may apply to public universities'' early programs.'),
        (stanford_id, 'What are Introductory Seminars?', 'Introductory Seminars (IntroSems) are small classes taught by Stanford faculty for first- and second-year students. Limited to 16 students or fewer, these classes offer a unique opportunity for close interaction with professors and hands-on learning experiences across a wide range of topics.'),
        (stanford_id, 'What entrepreneurship resources does Stanford offer?', 'Stanford offers numerous entrepreneurship resources including the Stanford Technology Ventures Program, StartX accelerator, Stanford Venture Studio, and courses through the Stanford d.school. The university''s proximity to Silicon Valley provides unique opportunities for mentorship, internships, and venture funding for student startups.');
        
        -- Delete any existing testimonials for Stanford
        DELETE FROM testimonials 
        WHERE university_id = stanford_id;
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (stanford_id, 'Marcus Chen', 'https://randomuser.me/api/portraits/men/22.jpg', 'Coming to Stanford has been one of the best decisions of my life. The academic opportunities are incredible, but what truly sets Stanford apart is the entrepreneurial spirit that permeates campus. I''ve been able to take my classroom learning directly into developing my own startup, with mentorship from professors who are leaders in their fields and classmates who share my passion for innovation.', 5, true);
    END IF;
END $$; 
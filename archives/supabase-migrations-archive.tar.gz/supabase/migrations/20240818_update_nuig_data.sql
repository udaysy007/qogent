-- Find the National University of Ireland Galway university ID (assuming it already exists)
DO $$
DECLARE
    nuig_id uuid;
BEGIN
    -- Get the ID of National University of Ireland Galway
    SELECT id INTO nuig_id FROM universities WHERE name = 'National University of Ireland Galway';
    
    -- If National University of Ireland Galway doesn't exist, we don't update anything
    IF nuig_id IS NOT NULL THEN
        -- Update National University of Ireland Galway with enhanced data
        UPDATE universities
        SET 
            founding_year = 1845,
            campus_image_url = 'https://images.unsplash.com/photo-1605969353711-234dea348ce1?q=80&w=1200',
            student_population = 19000,
            international_student_percentage = 15,
            ranking_the = 351,
            ranking_arwu = 501,
            tuition_fee_domestic = '€3,250 - €8,250 per year (for EU students)',
            tuition_fee_international = '€13,750 - €22,350 per year',
            application_fee = '€50',
            other_fees = 'Student levy: €224 per year',
            health_insurance = 'Non-EU students must have health insurance: Approximately €120 per year',
            living_expense_accommodation = '€4,200 - €7,800 per year',
            living_expense_food = '€2,400 - €3,600 per year',
            living_expense_transportation = '€500 - €1,000 per year',
            living_expense_other = '€1,500 - €2,500 per year',
            housing_info = 'NUI Galway offers on-campus accommodation in five student residences: Corrib Village, Goldcrest Village, Mara House, Shangan House, and Donegan House. These provide a mix of apartment-style and traditional dormitory options. Places are limited and in high demand, so early application is essential. The university''s accommodation office also assists students in finding private rentals in Galway city, which offers a range of options from shared houses to purpose-built student apartments.',
            campus_facilities = ARRAY['Libraries', 'Sports Centre', 'Student Centre', 'Arts in Action', 'IT Services', 'Medical Centre', 'Research Facilities'],
            international_support = 'The International Office provides comprehensive support for international students, including pre-arrival information, orientation programs, visa and immigration advice, and cultural integration activities. The university offers English language support courses and operates a buddy system pairing international students with local peers.',
            clubs_info = 'NUI Galway has over 120 student societies and sports clubs covering academic, cultural, social, and athletic interests. The Students'' Union organizes regular events and represents student interests. Societies range from course-specific groups to those focused on drama, music, politics, and international cultures.',
            admission_success_rate = '55%',
            students_placed = 460
        WHERE id = nuig_id;
        
        -- Clear any existing programs for National University of Ireland Galway and add new ones
        DELETE FROM university_programs 
        WHERE university_id = nuig_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (nuig_id, 'Medicine', 'Bachelor', 'Medicine', 'English', '5-6 years', 'A comprehensive medical program with early clinical exposure, emphasizing clinical skills, research, and professional development. Includes clinical placements at university-affiliated hospitals throughout the West of Ireland.', '€8,250 (EU) / €22,350 (Non-EU) per year', 'February 1', true),
        (nuig_id, 'Computer Science and Information Technology', 'Bachelor', 'Technology', 'English', '4 years', 'A well-rounded program covering software development, artificial intelligence, data science, and information systems with industry partnerships and internship opportunities.', '€3,250 (EU) / €15,550 (Non-EU) per year', 'February 1 (EU) / May 1 (Non-EU)', true),
        (nuig_id, 'MSc in Biotechnology', 'Master', 'Science', 'English', '1 year', 'An advanced program developing expertise in modern biotechnology techniques, bioprocessing, and biopharmaceutical applications with strong industry connections in Ireland''s thriving biotech sector.', '€8,500 (EU) / €16,500 (Non-EU)', 'June 1', true),
        (nuig_id, 'Law (LLB)', 'Bachelor', 'Law', 'English', '3-4 years', 'A comprehensive law program focusing on Irish, European, and international law with opportunities for clinical legal education and international exchange programs.', '€3,250 (EU) / €14,750 (Non-EU) per year', 'February 1 (EU) / May 1 (Non-EU)', false);
        
        -- Clear any existing admission requirements for National University of Ireland Galway and add new ones
        DELETE FROM admission_requirements 
        WHERE university_id = nuig_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (nuig_id, 'Academic', 'For EU undergraduate students: Points-based system through the CAO based on Leaving Certificate or equivalent results. For international undergraduates: Country-specific requirements equivalent to Irish Leaving Certificate. For postgraduate programs: Relevant bachelor''s degree with minimum 2.2 honors (or equivalent).', 'NUI Galway''s points requirements vary significantly by program. For competitive courses like Medicine, even perfect Leaving Certificate results may need to be supplemented with a strong HPAT score. For international students, the university is often more flexible than the highest-ranked Irish universities, making it a good option if your grades are strong but not exceptional.'),
        (nuig_id, 'Language', 'For non-native English speakers: IELTS (minimum 6.5 overall, no band below 5.5), TOEFL (minimum 88 internet-based), or equivalent. Higher requirements for programs like Medicine and Law.', 'While meeting minimum English requirements is sufficient for admission, stronger language skills will significantly improve your academic experience, particularly for programs with substantial reading and writing components. The university offers pre-sessional English courses that can help bridge the gap if your scores are borderline.'),
        (nuig_id, 'Documents', 'Academic transcripts, proof of English proficiency, copy of passport, personal statement (for some programs), references (for postgraduate programs).', 'In your application documents, particularly for postgraduate programs, highlight any connections to western Ireland or interest in the region''s unique cultural and natural environment. NUI Galway values students who show genuine interest in contributing to the local community and regional development.'),
        (nuig_id, 'Additional Requirements', 'Medicine requires the HPAT-Ireland test. Some creative arts programs require portfolios or auditions. Certain programs have subject-specific requirements or prerequisite courses.', 'For Medicine, your HPAT score combined with academic results determines admission. Preparation for this test should begin months in advance, as it assesses logical reasoning and interpersonal understanding rather than scientific knowledge. For other programs with specific requirements, contact the department directly for guidance, as requirements may change annually.');
        
        -- Clear any existing scholarships for National University of Ireland Galway and add new ones
        DELETE FROM scholarships 
        WHERE university_id = nuig_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (nuig_id, 'Excellence Scholarships', 'University', '€1,500 - €3,000', 'Merit-based scholarships awarded to undergraduate students with exceptional academic achievement.', 'First-year undergraduate students with top results in the Leaving Certificate or equivalent (typically 600+ points).', 'Automatically considered based on CAO points or equivalent international results.', 'No separate application required', '5%'),
        (nuig_id, 'International Student Scholarships', 'University', '€2,000 - €5,000 reduction in tuition fees', 'Partial scholarships for international students based on academic merit and country of origin.', 'Non-EU international students with excellent academic records applying to specific programs.', 'Apply through the online portal after receiving an offer of admission.', 'June 30', '20%'),
        (nuig_id, 'Hardiman PhD Scholarships', 'University', 'Full tuition fees plus €16,000 annual stipend for 4 years', 'Prestigious scholarships for doctoral students undertaking research in priority areas aligned with NUI Galway''s research strengths.', 'Exceptional students pursuing PhD research in specified areas with an outstanding research proposal.', 'Apply through the Hardiman Scholarship application portal with research proposal and references.', 'February 15', '8%');
        
        -- Clear any existing FAQs for National University of Ireland Galway and add new ones
        DELETE FROM university_faqs 
        WHERE university_id = nuig_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (nuig_id, 'What is NUI Galway known for?', 'National University of Ireland Galway (NUI Galway) is one of Ireland''s oldest and most respected universities, known for its strong programs in medicine, biomedical engineering, marine science, Irish studies, and human rights law. Founded in 1845 as Queen''s College Galway, the university has a rich history and has played a significant role in Irish educational and cultural development. NUI Galway is particularly recognized for its emphasis on research, with notable strengths in biomedical science and engineering, marine science, and social science. The university has a distinctive campus that blends historic quadrangles with modern facilities along the River Corrib. It''s known for its strong connection to the Irish language and culture, being located in Ireland''s largest Gaeltacht (Irish-speaking) region. The university is also recognized for its community engagement and sustainability initiatives, having been named the world''s 21st most sustainable university in the UI GreenMetric rankings.'),
        (nuig_id, 'What is student life like in Galway?', 'Galway offers one of the most vibrant and culturally rich student experiences in Ireland. The city is known as Ireland''s cultural heart, with a thriving arts scene, music tradition, and year-round festivals. With approximately 20% of Galway''s population being students, the city has a youthful energy and welcoming atmosphere. The compact city center means everything is within walking distance, from the historic Spanish Arch to the bustling Shop Street. The cost of living is generally lower than in Dublin, though finding accommodation can be challenging due to high demand. Galway''s location on Ireland''s west coast provides easy access to stunning natural landscapes including Connemara, the Burren, and the Cliffs of Moher. The local cuisine emphasizes fresh seafood and farm-to-table produce, with the famous Galway food market showcasing local specialties. The city is known for its traditional Irish pubs with live music sessions almost every night of the week. Despite being a small city by international standards, Galway has a cosmopolitan feel due to its significant international student population and tourism industry.'),
        (nuig_id, 'How does the Irish university system work?', 'The Irish university system follows the European Bologna Process model with three main cycles: Bachelor''s (3-4 years), Master''s (1-2 years), and Doctoral degrees (3-4 years). For undergraduate admission, Irish and EU students apply through the Central Applications Office (CAO) with a points-based system determined by Leaving Certificate results or equivalent qualifications. Non-EU international students apply directly to universities. The academic year typically runs from September to May, divided into two semesters with examinations at the end of each. Irish universities use the European Credit Transfer System (ECTS), with a standard full-time academic year consisting of 60 ECTS credits. Grading traditionally uses a classification system of First Class Honours (70%+), Second Class Honours (50-69%), and Pass (40-49%). Tuition fees vary significantly between EU and non-EU students, with many EU undergraduates paying only a student contribution fee (around €3,000) while international students pay full tuition fees. The seven universities in Ireland maintain high standards of education recognized internationally, with degrees generally well-respected by employers worldwide.'),
        (nuig_id, 'What research opportunities are available at NUI Galway?', 'NUI Galway offers extensive research opportunities across disciplines, with particular strengths in biomedical science and engineering, marine science, physical and computational sciences, social sciences, and humanities. The university hosts several major research institutes including the Ryan Institute for Environmental, Marine, and Energy Research, the CÚRAM Centre for Research in Medical Devices, and the Whitaker Institute for Innovation and Societal Change. Undergraduate students can engage with research through final year projects, the ALIVE volunteering program with research components, and summer research internships in various departments. Postgraduate research opportunities are available through taught master''s programs with research components, research master''s degrees, and PhD programs. The university secures significant research funding from national and EU sources, including Science Foundation Ireland and Horizon Europe. NUI Galway maintains active research collaborations with industry partners, particularly in the medical technology sector which has a strong presence in Galway. The university''s location provides unique opportunities for field research in marine science, biodiversity, and rural development.'),
        (nuig_id, 'How integrated is the Irish language at NUI Galway?', 'NUI Galway has a distinctive bilingual character and strong commitment to the Irish language (Gaeilge), reflecting its location near Ireland''s largest Gaeltacht (Irish-speaking) region. The university''s Acadamh na hOllscolaíochta Gaeilge offers undergraduate and postgraduate programs taught entirely through Irish. Students can choose to live in Irish-language residences (Áras na Gaeilge) where Irish is the daily language of communication. The university offers scholarships specifically for students studying through Irish or from Gaeltacht regions. Many services and facilities have bilingual signage and staff capable of assisting students in both English and Irish. While most programs are taught primarily in English, many offer modules or components in Irish for interested students. Cultural events celebrating the Irish language and Gaeltacht culture are a regular feature of campus life. The university''s An Cumann Gaelach (Irish language society) organizes social events and conversational circles for students interested in practicing their Irish. The university also conducts significant research on the Irish language, its literature, and its cultural context through its Centre for Irish Studies.');
        
        -- Delete any existing testimonials for National University of Ireland Galway
        DELETE FROM testimonials 
        WHERE university_id = nuig_id;
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (nuig_id, 'Ciara O''Sullivan', 'https://randomuser.me/api/portraits/women/32.jpg', 'My experience studying Biotechnology at NUI Galway has exceeded all my expectations. The program brilliantly combines theoretical knowledge with practical laboratory skills, and the facilities here are state-of-the-art. What makes NUI Galway special is the supportive community - professors know you by name and genuinely care about your progress. The university''s connections with Ireland''s booming biotech industry have been invaluable, with guest lectures from industry professionals and internship opportunities at leading companies. But studying here is about more than just academics - Galway city is an incredible place to be a student, with its vibrant arts scene, traditional music, and friendly atmosphere. I''ve particularly enjoyed exploring the west coast of Ireland on weekends, from the stunning Connemara mountains to the Aran Islands. The perfect balance of academic excellence and quality of life makes NUI Galway an ideal choice for anyone looking for a truly enriching university experience.', 5, true);
    END IF;
END $$; 
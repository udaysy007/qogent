-- Find the University of Warsaw university ID (assuming it already exists)
DO $$
DECLARE
    warsaw_id uuid;
BEGIN
    -- Get the ID of University of Warsaw
    SELECT id INTO warsaw_id FROM universities WHERE name = 'University of Warsaw';
    
    -- If University of Warsaw doesn't exist, we don't update anything
    IF warsaw_id IS NOT NULL THEN
        -- Update University of Warsaw with enhanced data
        UPDATE universities
        SET 
            founding_year = 1816,
            campus_image_url = 'https://images.unsplash.com/photo-1623160850346-e5bf22bbd524?q=80&w=1200',
            student_population = 40000,
            international_student_percentage = 13,
            ranking_the = 601,
            ranking_arwu = 401,
            tuition_fee_domestic = 'No tuition for Polish/EU students studying in Polish',
            tuition_fee_international = '€2,000 - €6,000 per year',
            application_fee = '€20',
            other_fees = 'Registration fee: €200 (one-time, for fee-paying programs)',
            health_insurance = 'EU students: European Health Insurance Card; Non-EU: Approximately €60 per year',
            living_expense_accommodation = '€150 - €350 per month',
            living_expense_food = '€150 - €250 per month',
            living_expense_transportation = '€15 - €25 per month',
            living_expense_other = '€100 - €200 per month',
            housing_info = 'The University of Warsaw offers student dormitories for both Polish and international students at affordable rates, though places are limited and priority is often given to Polish students from outside Warsaw. The university''s Accommodation Office assists international students in securing housing in one of their dormitories located across the city. Many international students choose private accommodation, either in shared apartments or private student residences. Warsaw offers a range of options from budget rooms to luxury apartments, with costs significantly lower than in Western European capitals.',
            campus_facilities = ARRAY['Libraries', 'Research Centers', 'Sports Facilities', 'Student Clubs', 'Canteens', 'Medical Services', 'Cultural Centers'],
            international_support = 'The International Relations Office provides comprehensive support for international students, including pre-arrival information, orientation programs, visa and residence permit assistance, and cultural integration activities. The university offers Polish language courses and buddy programs pairing international students with local peers.',
            clubs_info = 'The university hosts over 100 student scientific circles and organizations covering academic, cultural, and social interests. The Student Union represents student interests in university governance and organizes various events throughout the academic year, including the famous Juwenalia student festival in the spring.',
            admission_success_rate = '60%',
            students_placed = 580
        WHERE id = warsaw_id;
        
        -- Clear any existing programs for University of Warsaw and add new ones
        DELETE FROM university_programs 
        WHERE university_id = warsaw_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (warsaw_id, 'International Relations', 'Bachelor', 'Social Sciences', 'English', '3 years', 'A comprehensive program examining global politics, international law, and diplomacy with a special focus on Central and Eastern European perspectives and EU integration.', '€3,000 per year', 'July 10', true),
        (warsaw_id, 'Psychology', 'Master', 'Social Sciences', 'English', '2 years', 'An advanced program covering various psychological disciplines including clinical, social, and cognitive psychology with opportunities for research and practical training.', '€4,000 per year', 'July 10', true),
        (warsaw_id, 'Finance and International Investment', 'Bachelor', 'Business', 'English', '3 years', 'A specialized program focusing on global financial markets, investment strategies, and economic analysis with emphasis on emerging markets and European integration.', '€3,000 per year', 'July 10', true),
        (warsaw_id, 'Polish Studies', 'Bachelor', 'Humanities', 'Polish', '3 years', 'A program exploring Polish language, literature, and culture with opportunities for field studies, cultural excursions, and internships at cultural institutions.', '€2,000 per year', 'July 10', false);
        
        -- Clear any existing admission requirements for University of Warsaw and add new ones
        DELETE FROM admission_requirements 
        WHERE university_id = warsaw_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (warsaw_id, 'Academic', 'For Bachelor''s programs: Secondary school leaving certificate equivalent to Polish Matura. For Master''s programs: Bachelor''s degree in a relevant field. For some programs, entrance exams may be required.', 'The University of Warsaw evaluates international qualifications on a country-by-country basis. For undergraduate admissions, your high school GPA is particularly important, along with scores in subjects relevant to your chosen program. For competitive programs like Psychology or International Relations, preparing for entrance exams is crucial, as these often weigh heavily in the final admission decision.'),
        (warsaw_id, 'Language', 'For English-taught programs: IELTS (minimum 6.0-6.5), TOEFL (minimum 87-100), or equivalent. For Polish-taught programs: Polish language certificate (minimum B1-B2) or completion of a preparatory course.', 'While English-taught programs at UW don''t require knowledge of Polish for admission, learning at least basic Polish will significantly enhance your experience in Warsaw. Consider enrolling in one of the university''s Polish language courses for international students, which are offered at various levels and often include cultural components.'),
        (warsaw_id, 'Documents', 'Application form, secondary school/university certificates with transcripts, language certificates, passport copy, medical certificate, photos, application fee payment confirmation.', 'All documents in languages other than Polish or English must be translated by a sworn translator. The legalization process for educational documents can be time-consuming, particularly for countries without apostille agreements with Poland, so start the process early. The University of Warsaw is quite formal about documentation requirements, and incomplete applications are typically rejected without review.'),
        (warsaw_id, 'Additional Requirements', 'Some programs require entrance exams testing subject knowledge and aptitude. Certain programs may require interviews, motivation letters, or portfolios.', 'For programs with entrance exams, review the exam format and sample questions available on the faculty website. The exams often test both knowledge and analytical skills, so focus on understanding concepts rather than just memorizing facts. For arts and humanities programs, demonstrating knowledge of Polish culture and history in your application materials can be advantageous, even for English-taught programs.');
        
        -- Clear any existing scholarships for University of Warsaw and add new ones
        DELETE FROM scholarships 
        WHERE university_id = warsaw_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (warsaw_id, 'Rector''s Scholarship for Academic Achievement', 'University', 'PLN 700 - 1,000 per month', 'Merit-based scholarships awarded to students with outstanding academic performance.', 'Students with exceptional grades (top 10% of their program) in the previous academic year.', 'Apply through the university''s online system at the beginning of the academic year.', 'October 10', '10%'),
        (warsaw_id, 'Polish National Agency for Academic Exchange (NAWA) Scholarship', 'Polish Government', 'PLN 1,500 per month plus tuition waiver', 'Scholarships for international students studying in Poland, with focus on selected disciplines and countries.', 'International students with strong academic records. Priority given to students from Eastern Partnership countries and developing nations.', 'Apply directly through the NAWA portal with required documents.', 'Varies by program (typically March-April)', '20%'),
        (warsaw_id, 'Visegrad Scholarship Program', 'International Visegrad Fund', '€2,500 per semester', 'Scholarships supporting mobility between V4 countries (Poland, Czech Republic, Slovakia, Hungary) and Western Balkans/Eastern Partnership regions.', 'Students from eligible countries pursuing Master''s or PhD studies in specific fields related to regional development and cooperation.', 'Apply through the Visegrad Fund with research proposal and recommendation letters.', 'March 15', '25%');
        
        -- Clear any existing FAQs for University of Warsaw and add new ones
        DELETE FROM university_faqs 
        WHERE university_id = warsaw_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (warsaw_id, 'What is the University of Warsaw known for?', 'The University of Warsaw (Uniwersytet Warszawski), established in 1816, is Poland''s largest and most prestigious university. It''s particularly renowned for its programs in humanities, social sciences, mathematics, and natural sciences. The university produces world-class research in fields like archaeology, astronomy, chemistry, linguistics, philosophy, physics, and psychology. UW has educated many notable figures including Nobel Prize winners Henryk Sienkiewicz, Czesław Miłosz, Joseph Rotblat, and Leonid Hurwicz. As one of Central Europe''s leading academic institutions, it plays a significant role in Poland''s intellectual and cultural life. The university operates in beautiful historic buildings throughout Warsaw, with its main campus located in the heart of the city in restored palaces and manors. UW has a strong international orientation with growing numbers of English-taught programs and research collaborations with universities worldwide.'),
        (warsaw_id, 'What is student life like in Warsaw?', 'Warsaw offers a vibrant and affordable student experience in one of Central Europe''s most dynamic capitals. The city has transformed dramatically in recent decades, combining historic architecture with modern development. The cost of living is significantly lower than in Western European capitals, making it accessible for international students. Public transportation is excellent and affordable with student discounts, making it easy to navigate the city. Warsaw has a rich cultural scene with numerous museums, theaters, music venues, film festivals, and art galleries, many offering student discounts. The nightlife is diverse and affordable, with entertainment options ranging from traditional Polish pubs to modern clubs and alternative venues. The city has many green spaces, including the famous Łazienki Park, perfect for relaxation and outdoor activities. Student events are plentiful, especially during the Juwenalia festival in May when students take over the city with concerts and celebrations. Warsaw''s central location in Europe makes it an ideal base for exploring Poland and neighboring countries during academic breaks. The city has a growing international student community, creating opportunities for cultural exchange and building global networks.'),
        (warsaw_id, 'How does the Polish university system work?', 'Polish universities follow the European Bologna system with three-cycle degrees: Bachelor''s (Licencjat or Inżynier, 3-3.5 years), Master''s (Magister, 1.5-2 years), and Doctoral studies (Doktor, 3-4 years). The academic year runs from October to June, divided into two semesters with examination periods at the end of each. Grading uses a 2-5 scale, with 5 being the highest and 2 being a failing grade. Students accumulate ECTS credits, with 60 ECTS representing a full academic year of work. Full-time studies in Polish are free for Polish and EU citizens, while studies in English or for non-EU citizens typically require tuition fees. Many programs have entrance exams or evaluate candidates based on secondary school results. The system emphasizes theoretical knowledge but is increasingly incorporating practical components and internships. Classes typically include lectures, seminars, and practical laboratories or workshops. Attendance policies vary by faculty, with some requiring mandatory participation while others are more flexible.'),
        (warsaw_id, 'What research opportunities are available at the University of Warsaw?', 'The University of Warsaw offers extensive research opportunities across its 21 faculties and numerous research centers. Undergraduate students can participate in student scientific circles (koła naukowe) that conduct research projects, organize conferences, and publish journals in various disciplines. These provide valuable experience and networking opportunities with faculty and fellow researchers. For Master''s students, research forms a significant component of their studies, culminating in a research-based thesis. The university offers research grants and funding for student projects through various programs, including the Student Research Grants competition. UW has particularly strong research in disciplines including archaeology, astronomy, chemistry, mathematics, physics, and various humanities fields. The university participates in major international research initiatives and EU-funded programs, creating opportunities for students to join collaborative projects. The Interdisciplinary Centre for Mathematical and Computational Modelling provides advanced computing resources for research across disciplines. For doctoral students, the university offers structured PhD programs with dedicated research funding and opportunities for international collaboration.'),
        (warsaw_id, 'How affordable is studying at the University of Warsaw compared to other European universities?', 'The University of Warsaw offers one of the most affordable quality education options in the European Union. EU citizens can study full-time programs in Polish free of tuition, paying only a small semester administrative fee (around €40). Programs taught in English typically charge tuition fees ranging from €2,000 to €6,000 per year, significantly lower than similar programs in Western European countries where fees can range from €10,000 to €20,000 annually. The cost of living in Warsaw is approximately 50-60% lower than in cities like London, Paris, or Amsterdam. Student accommodation in university dormitories costs between €100-150 per month, while a room in a shared private apartment typically ranges from €200-350 per month. Monthly food expenses average €150-250, and public transportation costs about €15 per month with a student discount. Overall, a student can live comfortably in Warsaw on €500-700 per month, making it one of Europe''s most affordable capital cities for students. Various scholarship opportunities can further reduce costs, particularly for students from Eastern Partnership countries and developing nations. The university offers emergency financial aid for students facing unexpected financial difficulties during their studies.');
        
        -- Delete any existing testimonials for University of Warsaw
        DELETE FROM testimonials 
        WHERE university_id = warsaw_id;
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (warsaw_id, 'Carlos Mendez', 'https://randomuser.me/api/portraits/men/42.jpg', 'Studying International Relations at the University of Warsaw has been an enlightening academic and cultural journey. The program offers a unique perspective on global politics, with particular emphasis on Central and Eastern European dynamics that you won''t find at Western European universities. What surprised me most was the quality of education compared to the affordable cost - the value is unmatched anywhere else I considered studying. The professors bring both academic expertise and practical experience from diplomatic and governmental backgrounds, providing valuable insights beyond textbook theories. Being in Warsaw itself has been an education in European transformation; the city beautifully blends its historical legacy with rapid modernization. While the bureaucracy can be challenging for international students, the International Relations Office provides excellent support navigating paperwork and cultural adjustment. The diverse student community includes peers from across Europe, Asia, and the Americas, creating vibrant discussions and lasting friendships. The only significant challenge has been the language barrier in daily life, but this has improved with the basic Polish courses offered by the university. For someone seeking quality education at an affordable price in a historically rich European capital, the University of Warsaw offers an exceptional experience.', 5, true);
    END IF;
END $$; 
-- Find the University of Cambridge university ID (assuming it already exists)
DO $$
DECLARE
    cambridge_id uuid;
BEGIN
    -- Get the ID of University of Cambridge
    SELECT id INTO cambridge_id FROM universities WHERE name = 'University of Cambridge';
    
    -- If University of Cambridge doesn't exist, we don't update anything
    IF cambridge_id IS NOT NULL THEN
        -- Update University of Cambridge with enhanced data
        UPDATE universities
        SET 
            founding_year = 1209,
            campus_image_url = 'https://images.unsplash.com/photo-1579789618670-79a700d05a21?q=80&w=1200',
            student_population = 23380,
            international_student_percentage = 38,
            ranking_the = 5,
            ranking_arwu = 3,
            tuition_fee_domestic = '£9,250 per year',
            tuition_fee_international = '£23,340 - £58,038 per year',
            application_fee = '£70',
            other_fees = 'College fees: £8,250 - £10,920 per year (for international undergraduates)',
            health_insurance = 'Immigration Health Surcharge for visa holders: £624 per year',
            living_expense_accommodation = '£7,200 - £12,800 per year',
            living_expense_food = '£3,600 - £5,400 per year',
            living_expense_transportation = '£400 - £1,000 per year',
            living_expense_other = '£1,800 - £3,000 per year',
            housing_info = 'Cambridge has a collegiate system where most students live in college-owned accommodation throughout their studies. Each college has its own character and facilities, offering various housing options from historic buildings to modern purpose-built residences. Most colleges provide accommodation for three years of undergraduate study, and many offer accommodation for graduate students as well.',
            campus_facilities = ARRAY['Libraries', 'Museums', 'Laboratories', 'Sports Complexes', 'Gardens', 'Concert Halls', 'Historic Buildings'],
            international_support = 'The International Student Office provides comprehensive support including visa advice, orientation programs, and cultural adjustment assistance. Individual colleges also have dedicated staff for international student welfare.',
            clubs_info = 'Cambridge offers over 500 student societies covering sports, arts, politics, religion, culture, and special interest groups. The Cambridge Union, one of the world''s oldest and most prestigious debating societies, hosts prominent speakers from around the world.',
            admission_success_rate = '18%',
            students_placed = 620
        WHERE id = cambridge_id;
        
        -- Clear any existing programs for University of Cambridge and add new ones
        DELETE FROM university_programs 
        WHERE university_id = cambridge_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (cambridge_id, 'Natural Sciences', 'Bachelor', 'Science', 'English', '3-4 years', 'Cambridge''s flagship science program offering flexible study across biological and physical sciences before specializing in areas ranging from astrophysics to zoology.', '£9,250 (UK) / £38,827 (International) per year', 'October 15', true),
        (cambridge_id, 'Computer Science', 'Bachelor', 'Technology', 'English', '3-4 years', 'A rigorous program combining theoretical foundations with practical applications in areas like artificial intelligence, machine learning, and systems design.', '£9,250 (UK) / £38,827 (International) per year', 'October 15', true),
        (cambridge_id, 'MBA', 'Master', 'Business', 'English', '1 year', 'Cambridge''s intensive one-year MBA program focusing on practical learning, entrepreneurship, and global business with strong connections to Cambridge''s innovation ecosystem.', '£59,000', 'September (Round 1), October (Round 2), January (Round 3), March (Round 4), May (Round 5)', true),
        (cambridge_id, 'Mathematics', 'Bachelor', 'Mathematics', 'English', '3-4 years', 'Cambridge''s world-renowned mathematics program covering pure and applied mathematics, statistics, and theoretical physics with optional fourth year leading to Master of Mathematics.', '£9,250 (UK) / £38,827 (International) per year', 'October 15', false);
        
        -- Clear any existing admission requirements for University of Cambridge and add new ones
        DELETE FROM admission_requirements 
        WHERE university_id = cambridge_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (cambridge_id, 'Academic', 'Exceptionally strong academic record with top grades. For UK students: A*A*A or A*AA at A-level depending on the course. International qualifications assessed for equivalence.', 'Cambridge seeks academic excellence in subjects directly relevant to your chosen course. Depth of understanding matters more than breadth of subjects, and they place significant emphasis on achievement in prerequisite subjects.'),
        (cambridge_id, 'Language', 'For non-native English speakers: IELTS (minimum 7.5 overall, no less than 7.0 in any component), TOEFL (minimum 110), or Cambridge English: C2 Proficiency (minimum 200).', 'Cambridge''s tutorial and supervision system demands exceptional English proficiency, both written and spoken. Consider obtaining a higher score than the minimum requirements to ensure you can fully engage in Cambridge''s rigorous academic environment.'),
        (cambridge_id, 'Documents', 'UCAS application, college selection, personal statement, academic transcripts, reference letters. For some courses, you may need to submit examples of written work.', 'Your personal statement should demonstrate deep engagement with your subject beyond school curriculum. Show intellectual curiosity and independent exploration of your chosen field. Reference letters should speak specifically to your academic potential.'),
        (cambridge_id, 'Additional Requirements', 'Most applicants must take a pre-interview assessment or written assessment as part of the application process. Most shortlisted candidates will be invited to interview.', 'Cambridge interviews assess how you think, not just what you know. Practice thinking aloud when solving problems. The assessments test your potential and aptitude for your subject, so review the specific format for your course and practice with past papers if available.');
        
        -- Clear any existing scholarships for University of Cambridge and add new ones
        DELETE FROM scholarships 
        WHERE university_id = cambridge_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (cambridge_id, 'Cambridge Trust Scholarships', 'Cambridge Trust', 'Full or partial funding for tuition fees and maintenance', 'The Cambridge Trust offers one of the most extensive scholarship programs available to international students, supporting over 500 scholars from 80 countries annually.', 'International students with outstanding academic merit and potential. Specific criteria vary by country and award.', 'Most applicants are automatically considered after applying to the University. Some country-specific scholarships require separate applications.', 'Same as course application deadline', '5%'),
        (cambridge_id, 'Gates Cambridge Scholarship', 'Gates Foundation', 'Full cost of studying at Cambridge including tuition, maintenance, travel, and visa costs', 'Prestigious scholarships for outstanding applicants from outside the UK to pursue a full-time postgraduate degree in any subject available at Cambridge.', 'Non-UK citizens applying for a postgraduate degree. Selection based on academic excellence, leadership potential, commitment to improving lives of others, and fit with Cambridge.', 'Apply via the University''s graduate application portal and complete the Gates Cambridge section.', 'December (US round) / January (International round)', '1.5%'),
        (cambridge_id, 'Cambridge Commonwealth, European & International Trust Scholarships', 'Cambridge Trust', 'Varies: partial to full funding', 'Scholarships for students from Commonwealth, European, and other countries, offered in partnership with various organizations, companies, and Cambridge colleges.', 'Students from specific countries or regions, studying particular subjects. Awarded based on academic merit and financial need.', 'Most applicants are automatically considered after applying to the University. Some scholarships require separate applications.', 'Same as course application deadline', '8%');
        
        -- Clear any existing FAQs for University of Cambridge and add new ones
        DELETE FROM university_faqs 
        WHERE university_id = cambridge_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (cambridge_id, 'What is the Cambridge collegiate system?', 'Cambridge University is made up of 31 autonomous colleges, each with its own character and traditions. When you apply to Cambridge, you apply to a specific college or can make an open application. Your college is your academic and social hub, providing accommodation, dining, small-group teaching (supervisions), pastoral support, and recreational activities. Colleges are where you''ll live, eat, socialize, and receive much of your teaching, while departments provide lectures, labs, and faculty-level resources. Each college has its own admissions process, following university guidelines.'),
        (cambridge_id, 'What is the supervision system at Cambridge?', 'Supervisions are a distinctive feature of Cambridge education, consisting of small-group teaching sessions (typically 1-4 students) with subject experts (supervisors). Students prepare work in advance, such as essays or problem sets, which are then discussed in-depth during the supervision. This intensive teaching method provides personalized feedback and challenges students to defend and develop their ideas. Supervisions complement lectures and labs, allowing students to explore topics in greater depth and clarify understanding. This system dates back centuries and remains central to Cambridge''s educational approach.'),
        (cambridge_id, 'How does the Cambridge academic year work?', 'The Cambridge academic year consists of three eight-week terms: Michaelmas (October-December), Lent (January-March), and Easter (April-June). Terms are intensive periods of teaching and learning, with breaks between terms for independent study, dissertation work, and vacation. The short, intensive terms mean students need to work consistently throughout the term. Many courses have examinations at the end of each academic year rather than after each term.'),
        (cambridge_id, 'How competitive is admission to Cambridge?', 'Cambridge is extremely competitive, with an overall acceptance rate of about 18-20%, though this varies significantly by course and college. For the most competitive courses like Economics, Medicine, and Law, acceptance rates can be below 10%. The university receives around 20,000 applications for approximately 3,500 undergraduate places each year. International applicants face particularly competitive odds in many programs due to limited places.'),
        (cambridge_id, 'What makes Cambridge different from other universities?', 'Cambridge offers a unique combination of several distinctive elements: the collegiate system providing small, supportive communities within the larger university; the supervision system delivering personalized teaching in small groups with leading academics; world-class research facilities and resources including over 100 libraries and 9 museums; centuries of history and tradition (founded in 1209); and a global network of distinguished alumni across all fields. Cambridge consistently ranks among the world''s top universities for both teaching and research, particularly excelling in natural sciences, mathematics, engineering, and humanities.');
        
        -- Delete any existing testimonials for University of Cambridge
        DELETE FROM testimonials 
        WHERE university_id = cambridge_id;
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (cambridge_id, 'James Wilson', 'https://randomuser.me/api/portraits/men/32.jpg', 'The supervision system at Cambridge truly transformed my intellectual development. Having to defend my ideas every week to world-leading academics pushed me to think more deeply and rigorously than I ever had before. My college became a true home, providing not just accommodation but a supportive community of diverse, brilliant minds. The traditions might seem quaint at first, but they connect you to centuries of scholarship and create a unique sense of belonging. The workload is intense, but the growth and opportunities are unparalleled.', 5, true);
    END IF;
END $$; 
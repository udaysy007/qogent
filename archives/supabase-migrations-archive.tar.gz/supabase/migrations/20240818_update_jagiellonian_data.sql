-- Find the Jagiellonian University university ID (assuming it already exists)
DO $$
DECLARE
    jagiellonian_id uuid;
BEGIN
    -- Get the ID of Jagiellonian University
    SELECT id INTO jagiellonian_id FROM universities WHERE name = 'Jagiellonian University';
    
    -- If Jagiellonian University doesn't exist, we don't update anything
    IF jagiellonian_id IS NOT NULL THEN
        -- Update Jagiellonian University with enhanced data
        UPDATE universities
        SET 
            founding_year = 1364,
            campus_image_url = 'https://images.unsplash.com/photo-1586722806006-8440f9ad1a6b?q=80&w=1200',
            student_population = 40000,
            international_student_percentage = 11,
            ranking_the = 501,
            ranking_arwu = 401,
            tuition_fee_domestic = 'No tuition for Polish/EU students studying in Polish',
            tuition_fee_international = '€2,000 - €14,000 per year (depending on program)',
            application_fee = '€20',
            other_fees = 'Registration fee: €200 (one-time, for fee-paying programs)',
            health_insurance = 'EU students: European Health Insurance Card; Non-EU: Approx. €60 per year',
            living_expense_accommodation = '€150 - €350 per month',
            living_expense_food = '€150 - €250 per month',
            living_expense_transportation = '€15 - €25 per month',
            living_expense_other = '€100 - €200 per month',
            housing_info = 'Jagiellonian University offers student dormitories for both Polish and international students at affordable rates, though places are limited and priority is often given to Polish students from outside Krakow. Many international students find private accommodation, either in shared apartments or private dormitories, which are widely available in Krakow at reasonable prices compared to other European university cities.',
            campus_facilities = ARRAY['Libraries', 'Research Centers', 'Sports Facilities', 'Student Clubs', 'Canteens', 'Medical Centers', 'Cultural Centers'],
            international_support = 'The International Students Office provides comprehensive support including orientation programs, cultural adaptation assistance, and administrative help with residence permits and insurance. Mentor programs pair international students with local students to help with initial adjustment.',
            clubs_info = 'The university hosts over 100 scientific circles and student organizations covering academic interests, cultural activities, sports, and international exchange. The Student Government actively represents student interests and organizes various events throughout the academic year.',
            admission_success_rate = '62%',
            students_placed = 540
        WHERE id = jagiellonian_id;
        
        -- Clear any existing programs for Jagiellonian University and add new ones
        DELETE FROM university_programs 
        WHERE university_id = jagiellonian_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (jagiellonian_id, 'Medicine', 'Master', 'Medicine', 'English', '6 years', 'A comprehensive medical program taught entirely in English, combining theoretical knowledge with clinical practice at university hospitals. Graduates are eligible to practice medicine throughout the EU.', '€14,000 per year', 'May 31', true),
        (jagiellonian_id, 'International Relations', 'Bachelor', 'Social Sciences', 'English', '3 years', 'An interdisciplinary program exploring global politics, international law, and diplomacy with a special focus on Central and Eastern European perspectives.', '€2,500 per year', 'July 15', true),
        (jagiellonian_id, 'Computer Science', 'Master', 'Technology', 'English', '2 years', 'An advanced program covering algorithms, artificial intelligence, data science, and software engineering with research opportunities in collaboration with technology companies.', '€3,000 per year', 'July 5', true),
        (jagiellonian_id, 'European Studies', 'Bachelor', 'Humanities', 'English', '3 years', 'An interdisciplinary program examining European integration, politics, culture, and society from historical and contemporary perspectives with opportunities for exchange programs.', '€2,000 per year', 'July 15', false);
        
        -- Clear any existing admission requirements for Jagiellonian University and add new ones
        DELETE FROM admission_requirements 
        WHERE university_id = jagiellonian_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (jagiellonian_id, 'Academic', 'For Bachelor''s programs: Secondary school leaving certificate equivalent to Polish Matura. For Master''s programs: Bachelor''s degree in a relevant field. For Medical programs: Strong background in biology and chemistry.', 'Jagiellonian values consistent academic performance across subjects relevant to your chosen program. For competitive programs like Medicine, additional entrance exams may be required regardless of your previous grades. Prepare specifically for these tests as they often carry significant weight in the admission decision.'),
        (jagiellonian_id, 'Language', 'For English-taught programs: IELTS (minimum 6.0-6.5), TOEFL (minimum 87-100), or equivalent. For Polish-taught programs: Polish language certificate (minimum B1-B2) or completion of a preparatory course.', 'While the minimum language requirements are moderate, stronger proficiency will significantly improve your academic experience. Consider taking advantage of the university''s pre-semester intensive Polish language courses, as even basic Polish skills will enhance your daily life in Krakow.'),
        (jagiellonian_id, 'Documents', 'Application form, secondary school/university certificates with transcripts, language certificates, passport copy, medical certificate (for some programs), photos, application fee payment confirmation.', 'All documents in languages other than Polish or English must be translated by a sworn translator. Start the application process early, as document verification can take considerable time, especially for qualifications from non-EU countries.'),
        (jagiellonian_id, 'Additional Requirements', 'Medical programs require entrance exams testing biology, chemistry, and reasoning skills. Some programs require interviews or motivational letters. Portfolio requirements for arts and design programs.', 'For programs with additional requirements like Medicine, consider preparing with specialized courses. The entrance exam is competitive, and private preparation courses are available in Krakow and online. For humanities programs, a strong motivational letter explaining your interest in Polish culture or Central European studies can significantly strengthen your application.');
        
        -- Clear any existing scholarships for Jagiellonian University and add new ones
        DELETE FROM scholarships 
        WHERE university_id = jagiellonian_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (jagiellonian_id, 'Rector''s Scholarship for the Best Students', 'University', 'PLN 700 - 1,000 per month', 'Merit-based scholarships awarded to students with outstanding academic achievement and research potential.', 'Students with exceptional grades (typically top 10% of class) and research or extracurricular achievements.', 'Apply through the university''s online system with academic records and documentation of achievements.', 'October 10', '5%'),
        (jagiellonian_id, 'Polish National Agency for Academic Exchange (NAWA) Scholarship', 'Polish Government', 'PLN 1,500 per month plus tuition waiver', 'Scholarships for international students studying in Poland, promoting Polish language and culture.', 'International students with strong academic records and interest in Polish studies. Priority given to students from Eastern Partnership countries and developing nations.', 'Apply through the NAWA portal with required documents and research/study plan.', 'March 31', '15%'),
        (jagiellonian_id, 'Visegrad Scholarship', 'International Visegrad Fund', '€2,500 per semester', 'Scholarships supporting exchange of knowledge and research among V4 countries (Poland, Czech Republic, Slovakia, Hungary) and neighboring regions.', 'Students from V4 countries, Western Balkans, and Eastern Partnership countries pursuing Master''s or PhD studies.', 'Apply through the Visegrad Fund portal with research proposal and recommendation letters.', 'March 15', '20%');
        
        -- Clear any existing FAQs for Jagiellonian University and add new ones
        DELETE FROM university_faqs 
        WHERE university_id = jagiellonian_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (jagiellonian_id, 'What is Jagiellonian University known for?', 'Jagiellonian University, founded in 1364, is Poland''s oldest and most prestigious university, and one of the oldest in Europe. It''s particularly renowned for its medicine, law, and humanities programs. The university has educated numerous notable figures, including Nicolaus Copernicus, Pope John Paul II, and two Nobel Prize winners. Jagiellonian is consistently ranked as Poland''s top university and is known for its rich history, research contributions, and academic excellence. The university combines centuries of tradition with modern research facilities and teaching methods, and plays a significant role in Polish academic and cultural life.'),
        (jagiellonian_id, 'What is student life like in Krakow?', 'Krakow offers one of Europe''s most vibrant student experiences at an affordable cost. With over 200,000 students in the city, there''s a dynamic atmosphere with countless cafes, clubs, cultural venues, and events catering to young people. The historic Old Town, a UNESCO World Heritage site, serves as the backdrop for student life, with its market square, castle, and numerous historical landmarks. The cost of living is relatively low compared to Western European cities, making it accessible for international students. The city hosts numerous festivals throughout the year, including film festivals, Jewish culture festivals, and street art events. Student associations organize regular international student gatherings, trips, and cultural exchanges. Many students appreciate Krakow''s walkable size, excellent public transportation, and central location for exploring other parts of Poland and Central Europe.'),
        (jagiellonian_id, 'How does the Polish university system work?', 'Polish universities follow the European Bologna system with three-cycle degrees: Bachelor''s (Licencjat or Inżynier, 3-3.5 years), Master''s (Magister, 1.5-2 years), and Doctoral studies (Doktor, 3-4 years). Some programs like Medicine are offered as long-cycle Master''s programs (5-6 years). The academic year is divided into two semesters: winter (October-February) and summer (February-June), each ending with an examination session. Grading uses a 2-5 scale, with 5 being the highest and 2 being a failing grade. Students accumulate ECTS credits, with 60 ECTS representing a full academic year. Universities offer both full-time and part-time study options. Full-time studies in Polish are free for Polish and EU citizens, while studies in foreign languages and for non-EU citizens typically require tuition fees. Many programs require entrance exams or evaluate candidates based on secondary school results.'),
        (jagiellonian_id, 'What research opportunities are available at Jagiellonian University?', 'Jagiellonian University offers extensive research opportunities across all academic levels. The university has over 80 research centers and institutes, including the Malopolska Centre of Biotechnology, Jagiellonian Centre for Experimental Therapeutics, and Centre for Quantum Technologies. For Bachelor''s students, research opportunities include participation in student scientific circles (koła naukowe) which conduct research projects and organize conferences. Master''s students engage in research through thesis projects, often connected to faculty research initiatives. PhD students benefit from dedicated research funding and opportunities to join international research networks. The university maintains collaborations with research institutions worldwide and participates in EU-funded research projects. Particularly strong research areas include life sciences, physics, astronomy, and humanities, with Poland''s first synchrotron radiation facility, SOLARIS, located at the university''s Campus of the 600th Anniversary of the Jagiellonian University Revival.'),
        (jagiellonian_id, 'What support services are available for international students?', 'Jagiellonian University provides comprehensive support for international students through the International Students Office, which assists with admission procedures, visa requirements, and orientation programs. The university offers a buddy program pairing international students with local students for personal support and cultural integration. Pre-semester intensive Polish language courses are available for international students. The university''s Welcome Centre provides practical assistance with residence permits, insurance, banking, and accommodation. Psychological support services are available in multiple languages. The Career Office offers tailored support for international students planning to enter the Polish job market or pursue international opportunities. Academic advisors in each faculty provide guidance on course selection and academic requirements. The International Students Association organizes regular social events, cultural trips, and integration activities.');
        
        -- Delete any existing testimonials for Jagiellonian University
        DELETE FROM testimonials 
        WHERE university_id = jagiellonian_id;
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (jagiellonian_id, 'Anna Martinez', 'https://randomuser.me/api/portraits/women/89.jpg', 'Studying International Relations at Jagiellonian University has been an incredible journey. The program offers a perfect blend of theoretical knowledge and practical experience, with opportunities to participate in model UN conferences and diplomatic simulations. What makes Jagiellonian special is how it combines centuries of academic tradition with a modern, international outlook. The professors bring valuable insights from their diplomatic and academic careers, while the diverse student body ensures lively debates incorporating perspectives from around the world. Krakow itself is the perfect student city - beautiful, affordable, and incredibly vibrant. From studying in historic university buildings to discussing politics in Krakow''s cozy cafes, every day offers something new. The university also organizes field trips to European institutions and provides excellent networking opportunities with diplomats and international organizations.', 5, true);
    END IF;
END $$; 
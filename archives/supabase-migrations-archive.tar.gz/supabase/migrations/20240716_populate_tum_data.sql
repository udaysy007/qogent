-- Find the TUM university ID (assuming it already exists)
DO $$
DECLARE
    tum_id uuid;
BEGIN
    -- Get the ID of TUM
    SELECT id INTO tum_id FROM universities WHERE name = 'Technical University of Munich';
    
    -- If TUM doesn't exist, insert it
    IF tum_id IS NULL THEN
        INSERT INTO universities (
            name, 
            slug, 
            country_id, 
            city, 
            is_public, 
            ranking, 
            description, 
            website, 
            logo_url
        ) 
        VALUES (
            'Technical University of Munich',
            'technical-university-of-munich',
            (SELECT id FROM countries WHERE name = 'Germany'),
            'Munich',
            true,
            50,
            'The Technical University of Munich (TUM) is one of Europe''s top universities. It is committed to excellence in research and teaching, interdisciplinary education and the active promotion of promising young scientists. The university also forges strong links with companies and scientific institutions across the world.',
            'https://www.tum.de/en/',
            'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c8/Logo_of_the_Technical_University_of_Munich.svg/800px-Logo_of_the_Technical_University_of_Munich.svg.png'
        )
        RETURNING id INTO tum_id;
    END IF;
    
    -- Update TUM with enhanced data
    UPDATE universities
    SET 
        founding_year = 1868,
        campus_image_url = 'https://images.unsplash.com/photo-1597088437850-45adb696d05c?q=80&w=1200',
        student_population = 45000,
        international_student_percentage = 30,
        ranking_the = 41,
        ranking_arwu = 52,
        tuition_fee_domestic = 'No tuition fees, only semester fee: €144.40',
        tuition_fee_international = 'No tuition fees, only semester fee: €144.40',
        application_fee = 'None',
        other_fees = 'Administrative fee: €52',
        health_insurance = 'Approximately €110 per month',
        living_expense_accommodation = '€400 - €800 per month',
        living_expense_food = '€200 - €300 per month',
        living_expense_transportation = '€70 per month (semester ticket)',
        living_expense_other = '€100 - €200 per month',
        housing_info = 'TUM offers student housing through the Munich Student Union (Studentenwerk München). Housing costs range from €250 to €450 per month depending on the type of accommodation. Due to high demand, it''s recommended to apply early.',
        campus_facilities = ARRAY['Libraries', 'Sports Facilities', 'Cafeterias', 'IT Labs', 'Research Centers', 'Student Lounges'],
        international_support = 'TUM Global & Alumni Office provides comprehensive support for international students including orientation programs, language courses, and social events.',
        clubs_info = 'TUM has over 100 student-run clubs and organizations covering academic, cultural, sports, and social interests.',
        admission_success_rate = '70%',
        students_placed = 350
    WHERE id = tum_id;
    
    -- Clear any existing programs for TUM and add new ones
    DELETE FROM university_programs WHERE university_id = tum_id;
    
    -- Add featured programs
    INSERT INTO university_programs (
        university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
    ) VALUES
    (tum_id, 'Computer Science', 'Master', 'Engineering', 'English', '4 semesters (2 years)', 'The Master''s Program in Computer Science at TUM is designed to provide students with a strong foundation in the principles and practices of computer science, with an emphasis on practical applications and research.', 'Semester fee: €144.40', 'Winter: January 15 - May 31, Summer: November 15 - January 15', true),
    (tum_id, 'Data Engineering and Analytics', 'Master', 'Data Science', 'English', '4 semesters (2 years)', 'This program focuses on the analysis and processing of large amounts of data, including statistical data analysis and machine learning techniques.', 'Semester fee: €144.40', 'Winter: January 15 - May 31', true),
    (tum_id, 'Electrical Engineering', 'Master', 'Engineering', 'English', '4 semesters (2 years)', 'The program covers advanced topics in electrical engineering, including embedded systems, power electronics, and telecommunications.', 'Semester fee: €144.40', 'Winter: January 15 - May 31, Summer: November 15 - January 15', false),
    (tum_id, 'Management & Technology', 'Master', 'Business', 'English', '4 semesters (2 years)', 'A program combining business administration and management with technological expertise, preparing students for leadership roles at the interface of business and technology.', 'Semester fee: €144.40', 'Winter: January 15 - May 31', true);
    
    -- Clear any existing admission requirements for TUM and add new ones
    DELETE FROM admission_requirements WHERE university_id = tum_id;
    
    -- Add admission requirements
    INSERT INTO admission_requirements (
        university_id, type, description, qogent_insight
    ) VALUES
    (tum_id, 'Academic', 'A Bachelor''s degree in a related field with above-average grades. TUM evaluates applicants based on their previous academic performance and the relevance of their previous studies to the chosen program.', 'TUM places high importance on the quality of your previous university. Graduates from top-ranked universities typically have a higher chance of acceptance.'),
    (tum_id, 'Language', 'For English-taught programs: TOEFL (88+) or IELTS (6.5+). For German-taught programs: DSH-2 or TestDaF 4', 'Even for English programs, having some knowledge of German can significantly improve your experience and job prospects in Germany. Consider taking at least A1 level German courses.'),
    (tum_id, 'Documents', 'CV, motivation letter, transcript of records, degree certificate (if already available), proof of language proficiency, and passport copy.', 'Your motivation letter should specifically address why you want to study at TUM rather than other German universities. Mentioning specific professors or research projects can strengthen your application.');
    
    -- Clear any existing scholarships for TUM and add new ones
    DELETE FROM scholarships WHERE university_id = tum_id;
    
    -- Add scholarships
    INSERT INTO scholarships (
        university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
    ) VALUES
    (tum_id, 'Deutschlandstipendium', 'University', '€300 per month for one year', 'The Deutschlandstipendium supports talented and high-achieving students of all nationalities. Half of the funding comes from private sponsors and the other half from the German Federal Government.', 'Open to all students with excellent academic achievements, social commitment, and personal circumstances.', 'Online application through the TUM portal with academic records, CV, and letter of motivation.', 'Usually in June for the following winter semester', '20%'),
    (tum_id, 'DAAD Scholarship', 'Government', 'Varies (typically covers living expenses and health insurance)', 'The German Academic Exchange Service (DAAD) offers scholarships for international students to pursue studies in Germany.', 'International students with excellent academic records; specific requirements vary by program.', 'Apply directly through the DAAD portal with required documents.', 'Varies by program, typically October-December for the following year', '15%'),
    (tum_id, 'TUM Foundation Fellowship', 'University', '€800 - €1,500 per month', 'Scholarships for outstanding international Master''s students with an excellent academic record.', 'International students applying for Master''s programs with a GPA of 1.7 or better (German scale).', 'Automatic consideration during the admission process.', 'Same as program application deadline', '10%');
    
    -- Clear any existing FAQs for TUM and add new ones
    DELETE FROM university_faqs WHERE university_id = tum_id;
    
    -- Add FAQs
    INSERT INTO university_faqs (
        university_id, question, answer
    ) VALUES
    (tum_id, 'Are there any tuition fees at TUM?', 'No, TUM does not charge tuition fees for most programs. Students only need to pay a semester fee of approximately €144.40, which includes a semester ticket for public transportation in Munich.'),
    (tum_id, 'How competitive is admission to TUM?', 'Admission to TUM is highly competitive, especially for popular programs like Computer Science and Management & Technology. The university looks for students with strong academic backgrounds and relevant experience. Having a degree from a recognized institution with good grades significantly improves your chances.'),
    (tum_id, 'Is knowledge of German necessary for studying at TUM?', 'For English-taught programs, knowledge of German is not required for admission. However, learning German is recommended for daily life in Germany and can improve job prospects. TUM offers German language courses for international students.'),
    (tum_id, 'What accommodation options are available for students?', 'TUM students can apply for accommodation through the Munich Student Union (Studentenwerk München), which offers various types of student housing. Due to high demand, it''s recommended to apply as early as possible. Alternatively, students can look for private accommodation, although this tends to be more expensive in Munich.'),
    (tum_id, 'What career support services does TUM offer?', 'TUM offers comprehensive career support through its Career Service, including job and internship placements, career counseling, CV checks, and regular career fairs. The university also has strong industry connections, particularly in the Munich area, which is home to many global companies.');
    
    -- Add a testimonial (fixed to match the existing table structure)
    INSERT INTO testimonials (
        university_id, student_name, student_image, content, rating, featured
    ) VALUES
    (tum_id, 'Sophie Müller', 'https://randomuser.me/api/portraits/women/54.jpg', 'Studying at TUM was challenging but incredibly rewarding. The university''s strong connections with industry allowed me to secure an internship at BMW, which later turned into a full-time position.', 5, true);
    
END $$; 
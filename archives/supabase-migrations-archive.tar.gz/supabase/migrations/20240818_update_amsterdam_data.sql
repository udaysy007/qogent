-- Find the University of Amsterdam university ID (assuming it already exists)
DO $$
DECLARE
    amsterdam_id uuid;
BEGIN
    -- Get the ID of University of Amsterdam
    SELECT id INTO amsterdam_id FROM universities WHERE name = 'University of Amsterdam';
    
    -- If University of Amsterdam doesn't exist, we don't update anything
    IF amsterdam_id IS NOT NULL THEN
        -- Update University of Amsterdam with enhanced data
        UPDATE universities
        SET 
            founding_year = 1632,
            campus_image_url = 'https://images.unsplash.com/photo-1576016770956-debb63d92058?q=80&w=1200',
            student_population = 39000,
            international_student_percentage = 27,
            ranking_the = 65,
            ranking_arwu = 101,
            tuition_fee_domestic = '€2,209 per year (EU/EEA students)',
            tuition_fee_international = '€10,100 - €20,600 per year',
            application_fee = '€100',
            other_fees = 'Variable by program',
            health_insurance = 'EU students: European Health Insurance Card; Non-EU: Approximately €550 per year',
            living_expense_accommodation = '€5,400 - €12,000 per year',
            living_expense_food = '€3,000 - €4,800 per year',
            living_expense_transportation = '€500 - €1,200 per year',
            living_expense_other = '€1,800 - €3,000 per year',
            housing_info = 'The University of Amsterdam does not operate its own student housing but works with housing providers to offer accommodation options for international students. UvA guarantees housing for certain categories of international students who apply before the deadline. Most student housing consists of shared facilities with private bedrooms. The university''s housing office assists students in navigating Amsterdam''s competitive housing market. Many students live in private accommodations throughout the city, with student housing often concentrated in areas like Amsterdam-East, Amsterdam-West, and Diemen.',
            campus_facilities = ARRAY['Libraries', 'Study Centers', 'Research Labs', 'Student Centers', 'Cafeterias', 'Sports Facilities', 'Cultural Centers'],
            international_support = 'The International Student Office provides comprehensive support including pre-arrival guidance, orientation programs, immigration advice, and cultural integration activities. UvA offers Dutch language courses and cultural programs to help international students adapt to life in the Netherlands.',
            clubs_info = 'UvA has numerous student organizations spanning academic, cultural, political, and social interests. Study associations are tied to specific academic programs, while student associations focus on social activities and networking. The student council represents student interests in university governance.',
            admission_success_rate = '48%',
            students_placed = 710
        WHERE id = amsterdam_id;
        
        -- Clear any existing programs for University of Amsterdam and add new ones
        DELETE FROM university_programs 
        WHERE university_id = amsterdam_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (amsterdam_id, 'Psychology', 'Bachelor', 'Social Sciences', 'English', '3 years', 'A comprehensive program exploring human behavior and mental processes, featuring specializations in clinical, social, and cognitive psychology with strong emphasis on research methodology.', '€2,209 (EU) / €11,500 (Non-EU) per year', 'January 15 (Non-EU) / May 1 (EU)', true),
        (amsterdam_id, 'Business Administration', 'Bachelor', 'Business', 'English', '3 years', 'An interdisciplinary program providing a solid foundation in business principles, economics, and management with opportunities for specialization and international exchange.', '€2,209 (EU) / €11,000 (Non-EU) per year', 'January 15 (Non-EU) / May 1 (EU)', true),
        (amsterdam_id, 'Artificial Intelligence', 'Master', 'Technology', 'English', '2 years', 'A cutting-edge program combining computer science, cognitive science, and logic to develop intelligent systems and applications with research opportunities in top AI laboratories.', '€2,209 (EU) / €17,800 (Non-EU) per year', 'February 1', true),
        (amsterdam_id, 'International and European Law', 'Master', 'Law', 'English', '1 year', 'A specialized program examining international legal frameworks and European Union law with options to focus on human rights, commercial law, or public international law.', '€2,209 (EU) / €16,400 (Non-EU) per year', 'March 1 (scholarships) / May 1 (regular)', false);
        
        -- Clear any existing admission requirements for University of Amsterdam and add new ones
        DELETE FROM admission_requirements 
        WHERE university_id = amsterdam_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (amsterdam_id, 'Academic', 'For Bachelor''s programs: Secondary school diploma equivalent to Dutch VWO diploma with specific subject requirements depending on the program. For Master''s programs: Bachelor''s degree in a relevant field, often with specific GPA requirements (typically 7 out of 10 in the Dutch system or equivalent).', 'UvA evaluates international qualifications for equivalence to Dutch standards, which can be quite strict. For competitive programs like Psychology or Business, even meeting the minimum requirements may not guarantee admission. Create a "matching profile" by taking additional advanced courses relevant to your program of interest, especially if your educational system doesn''t perfectly align with Dutch requirements.'),
        (amsterdam_id, 'Language', 'For English-taught programs: IELTS (minimum 6.5-7.0 overall, with at least 6.0-6.5 in each component) or TOEFL (minimum 92-100 internet-based) depending on the program. For Dutch-taught programs: NT2-II certificate or equivalent.', 'While UvA offers many programs in English, having some Dutch language skills will significantly enhance your social experience and employment prospects in the Netherlands. Consider taking advantage of the free Dutch language courses offered to international students, even if your program is taught in English.'),
        (amsterdam_id, 'Documents', 'Online application, academic transcripts, CV, motivation letter, research proposal (for research Master''s), and letters of recommendation (for some programs).', 'In your motivation letter, demonstrate specific research interests that align with UvA''s strengths rather than generic academic goals. The university values students who can articulate why UvA specifically is the right fit for their academic pursuits, so research faculty members and ongoing projects in your field of interest.'),
        (amsterdam_id, 'Additional Requirements', 'Some programs have additional requirements such as entrance exams, interviews, or portfolio assessments. Numerus fixus programs (with limited places) have more competitive admissions processes.', 'For numerus fixus programs like Psychology, prepare thoroughly for the selection process, as these are highly competitive with far more applicants than available places. The selection often includes assessments of both cognitive skills and non-cognitive attributes like motivation and understanding of the field.');
        
        -- Clear any existing scholarships for University of Amsterdam and add new ones
        DELETE FROM scholarships 
        WHERE university_id = amsterdam_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (amsterdam_id, 'Amsterdam Excellence Scholarship', 'University', '€25,000 per year', 'Prestigious scholarships for outstanding international students pursuing Master''s degrees at UvA.', 'Non-EU/EEA students with exceptional academic achievement (top 10% of class) and demonstrated excellence in extracurricular activities.', 'Apply through the scholarship application portal after being admitted to a Master''s program.', 'January 15', '5%'),
        (amsterdam_id, 'Amsterdam Merit Scholarship', 'University', '€5,000 - €10,000 (one-time payment)', 'Partial scholarships for talented international students based on academic excellence.', 'Non-EU/EEA students with strong academic records admitted to specific Master''s programs.', 'Apply through the faculty scholarship committee after receiving an offer of admission.', 'Varies by faculty (February-April)', '15%'),
        (amsterdam_id, 'Holland Scholarship', 'Dutch Ministry of Education and UvA', '€5,000 (one-time payment)', 'Scholarships for non-EEA international students studying Bachelor''s or Master''s programs in the Netherlands.', 'Non-EU/EEA students with excellent academic records applying for their first year of study at UvA.', 'Submit scholarship application after applying to a degree program.', 'February 1', '20%');
        
        -- Clear any existing FAQs for University of Amsterdam and add new ones
        DELETE FROM university_faqs 
        WHERE university_id = amsterdam_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (amsterdam_id, 'What is the University of Amsterdam known for?', 'The University of Amsterdam (UvA), founded in 1632, is one of Europe''s most historic and prestigious research universities. It''s particularly renowned for its programs in social sciences, humanities, economics, and business, consistently ranking among the world''s top 100 universities. UvA has a strong international orientation, with over 100 English-taught programs and students from more than 100 countries. The university is known for its innovative research in areas like artificial intelligence, brain and cognitive sciences, sustainability, and urban studies. As the largest university in the Netherlands, UvA offers a comprehensive range of disciplines spanning sciences, social sciences, humanities, medicine, law, economics, and more. The university is deeply integrated into Amsterdam''s urban fabric, with buildings spread throughout the city rather than on a single campus, contributing to its dynamic atmosphere and close connections with Dutch society and culture.'),
        (amsterdam_id, 'What is student life like in Amsterdam?', 'Amsterdam offers one of Europe''s most vibrant and unique student experiences. The city is known for its liberal, tolerant atmosphere and multicultural environment, making international students feel welcome. Amsterdam''s compact size and excellent cycling infrastructure make it easy to navigate, with most places accessible by bike within 30 minutes. The city offers a rich cultural life, with world-class museums, theaters, music venues, and festivals throughout the year. UvA''s buildings are integrated throughout the city, giving students an urban campus experience that merges academic and city life. Student associations and study associations organize numerous events, parties, and activities throughout the academic year. The cost of living is relatively high, particularly for housing, though still lower than cities like London or Paris. Amsterdam''s central location in Europe and excellent transportation connections make it ideal for exploring other European cities on weekends or holidays. The city''s famous canals, historic architecture, and café culture create a picturesque and enjoyable setting for student life. While Amsterdam has a reputation for its liberal policies on cannabis and nightlife, the city offers much more, with rich history, cultural diversity, and intellectual atmosphere.'),
        (amsterdam_id, 'How does the Dutch university system work?', 'The Dutch higher education system distinguishes between research universities (like UvA) offering research-oriented programs and universities of applied sciences focusing on professional education. Most bachelor''s programs take three years to complete, while master''s programs range from one to two years depending on the field. The academic year typically runs from September to June, divided into two semesters or three trimesters depending on the program. Dutch universities use a 10-point grading scale, with 10 being the highest and 5.5 the minimum passing grade. The system emphasizes independent learning, critical thinking, and practical application of knowledge, with less classroom hours than many other countries but more self-study and group projects. Teaching methods include lectures, seminars, tutorials, and practical sessions, with active student participation expected. Most programs use the European Credit Transfer System (ECTS), with each year consisting of 60 ECTS credits. Dutch universities offer relatively affordable tuition for EU students (around €2,200 per year), while non-EU students pay higher tuition fees that still compare favorably with those in the UK or US. The bachelor-master structure follows the Bologna process, making degrees internationally recognized and compatible with other European systems.'),
        (amsterdam_id, 'What research opportunities are available at UvA?', 'UvA offers extensive research opportunities across all academic levels, reflecting its status as one of Europe''s major research universities. For bachelor''s students, opportunities include honors programs with research components, thesis research projects, and research assistant positions with faculty members. Master''s programs typically have significant research components, especially research-oriented master''s degrees, culminating in an independent research thesis. The university has 19 research priority areas, including brain and cognitive sciences, artificial intelligence, cultural transformation, urban studies, and sustainable prosperity. UvA houses numerous research institutes and centers that welcome student involvement, such as the Institute for Advanced Study, the Amsterdam Institute for Social Science Research, and the Institute for Logic, Language and Computation. The university participates in national and European research funding programs, creating opportunities for students to join larger research initiatives. Close collaboration with other institutions like the Vrije Universiteit Amsterdam, Amsterdam University Medical Centers, and various international university networks expands research possibilities. UvA maintains partnerships with industry, government, and non-profit organizations, creating opportunities for applied research with real-world impact.'),
        (amsterdam_id, 'How difficult is it to find accommodation in Amsterdam?', 'Finding accommodation in Amsterdam is widely considered one of the most challenging aspects of studying at UvA, due to a city-wide housing shortage. The university guarantees housing for certain categories of international students (typically full-degree non-EU students and exchange students) who apply before the housing deadline, but this accommodation is limited. Applications for university-arranged housing must be made early, usually immediately after acceptance to a program. The private housing market in Amsterdam is highly competitive, with high demand, limited supply, and relatively high rental prices compared to other Dutch cities. Students seeking private accommodation should begin their search months in advance of their arrival. Shared accommodations are the most common and affordable option for students, with monthly rents typically ranging from €500-€900 for a room in a shared apartment. Purpose-built student housing exists but is limited and often quickly filled. Some students choose to live in neighboring cities like Diemen, Amstelveen, or Haarlem, which offer more affordable options with reasonable commuting times to Amsterdam. Students should be cautious of rental scams targeting international newcomers and use official channels or reputable agencies when searching for accommodation. UvA''s housing office provides guidance and resources for students navigating the private market, but cannot guarantee placement for all students.');
        
        -- Delete any existing testimonials for University of Amsterdam
        DELETE FROM testimonials 
        WHERE university_id = amsterdam_id;
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (amsterdam_id, 'Julia Hernandez', 'https://randomuser.me/api/portraits/women/44.jpg', 'Studying Psychology at the University of Amsterdam has been an intellectually stimulating journey that has exceeded my expectations. The program''s research-focused approach has given me strong methodological skills and critical thinking abilities that I know will serve me well in my future career. What makes UvA special is the international environment - in my courses, I regularly collaborate with students from across Europe and beyond, each bringing unique perspectives to our discussions. The professors are not only experts in their fields but also accessible and genuinely interested in student development. Amsterdam itself is the perfect student city - vibrant, diverse, and brimming with culture. Cycling along the canals to class never gets old! While finding housing was initially challenging, the university''s housing office provided valuable guidance. The Dutch directness took some getting used to, but I''ve come to appreciate the straightforward communication style both in academic and social settings. The work-life balance here is excellent, allowing me to excel academically while still enjoying everything Amsterdam has to offer.', 5, true);
    END IF;
END $$; 
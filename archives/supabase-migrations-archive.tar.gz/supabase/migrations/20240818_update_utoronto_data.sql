-- Find the University of Toronto university ID (assuming it already exists)
DO $$
DECLARE
    utoronto_id uuid;
BEGIN
    -- Get the ID of University of Toronto
    SELECT id INTO utoronto_id FROM universities WHERE name = 'University of Toronto';
    
    -- If University of Toronto doesn't exist, we don't update anything
    IF utoronto_id IS NOT NULL THEN
        -- Update University of Toronto with enhanced data
        UPDATE universities
        SET 
            founding_year = 1827,
            campus_image_url = 'https://images.unsplash.com/photo-1541443458363-6597b2b64122?q=80&w=1200',
            student_population = 93000,
            international_student_percentage = 25,
            ranking_the = 18,
            ranking_arwu = 22,
            tuition_fee_domestic = 'CAD 6,100 - CAD 14,180 per year',
            tuition_fee_international = 'CAD 57,020 - CAD 64,950 per year',
            application_fee = 'CAD 180',
            other_fees = 'Incidental fees: CAD 1,500 - CAD 1,800 per year',
            health_insurance = 'University Health Insurance Plan (UHIP): CAD 720 per year for international students',
            living_expense_accommodation = 'CAD 8,000 - CAD 20,000 per year',
            living_expense_food = 'CAD 4,000 - CAD 6,000 per year',
            living_expense_transportation = 'CAD 1,000 - CAD 2,000 per year',
            living_expense_other = 'CAD 2,000 - CAD 4,000 per year',
            housing_info = 'UofT has residence options across its three campuses, with guaranteed housing for first-year students who meet application deadlines. Residences vary from traditional dormitories to apartment-style units, with a mix of meal plan options. The Student Housing Service assists students in finding off-campus housing in Toronto, which has a competitive rental market.',
            campus_facilities = ARRAY['Libraries', 'Research Centers', 'Athletic Facilities', 'Student Centers', 'Health Services', 'Career Centers', 'Study Spaces'],
            international_support = 'The Centre for International Experience provides comprehensive support including immigration advising, orientation programs, transition support, and cultural adjustment. Specialized advisors assist with study permits, work regulations, and health insurance.',
            clubs_info = 'UofT has over 1,000 student organizations across its three campuses, ranging from academic associations to cultural groups, athletic teams, and special interest clubs. The universities'' student unions organize events, advocate for student interests, and provide various services.',
            admission_success_rate = '43%',
            students_placed = 850
        WHERE id = utoronto_id;
        
        -- Clear any existing programs for University of Toronto and add new ones
        DELETE FROM university_programs 
        WHERE university_id = utoronto_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (utoronto_id, 'Computer Science', 'Bachelor', 'Technology', 'English', '4 years', 'A comprehensive program exploring theoretical foundations and practical applications of computing with specializations in artificial intelligence, game design, web development, and more.', 'CAD 6,100 (Domestic) / CAD 61,000 (International) per year', 'January 15', true),
        (utoronto_id, 'Rotman Commerce', 'Bachelor', 'Business', 'English', '4 years', 'A prestigious business program combining a Bachelor of Commerce with a focus in management, accounting, or finance, integrated with liberal arts education.', 'CAD 14,180 (Domestic) / CAD 64,950 (International) per year', 'January 15', true),
        (utoronto_id, 'Master of Science in Applied Computing', 'Master', 'Technology', 'English', '16 months', 'An innovative program combining advanced computing courses with an 8-month industrial internship at leading technology companies.', 'CAD 13,580 (Domestic) / CAD 59,320 (International) per year', 'December 15', true),
        (utoronto_id, 'Life Sciences', 'Bachelor', 'Science', 'English', '4 years', 'A multidisciplinary program exploring biological systems from molecules to ecosystems, with pathways in human biology, neuroscience, cell biology, and more.', 'CAD 6,100 (Domestic) / CAD 61,000 (International) per year', 'January 15', false);
        
        -- Clear any existing admission requirements for University of Toronto and add new ones
        DELETE FROM admission_requirements 
        WHERE university_id = utoronto_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (utoronto_id, 'Academic', 'Strong academic performance in secondary school with emphasis on prerequisites for chosen program. Canadian high school students need competitive grades in required 12U/M courses. International students need strong performance in equivalent qualifications.', 'UofT values consistent academic performance over a dramatic upward trend. Focus on maintaining strong grades in prerequisite subjects for your desired program, as these are weighted more heavily in the admission decision.'),
        (utoronto_id, 'Language', 'Non-native English speakers need TOEFL (minimum 100 with at least 22 in writing), IELTS (minimum 6.5 with no band below 6.0), or other approved English proficiency tests.', 'UofT''s programs involve substantial reading and writing. Consider taking additional English preparation beyond the minimum requirements, particularly for programs in humanities or social sciences.'),
        (utoronto_id, 'Documents', 'Online application, official transcripts, English proficiency test scores if applicable, supplementary applications for specific programs.', 'The Student Profile is your opportunity to showcase extracurricular activities and explain any circumstances affecting your academic performance. Be specific about leadership roles and the impact of your involvement rather than just listing activities.'),
        (utoronto_id, 'Additional Requirements', 'Some programs require supplementary applications, portfolios, auditions, or interviews. Engineering, architecture, music, and visual arts have specific additional requirements.', 'Competitive programs like Rotman Commerce and Computer Science require not only outstanding grades but also strong supplementary applications. Begin preparing these well in advance and highlight what makes you unique beyond academic achievements.');
        
        -- Clear any existing scholarships for University of Toronto and add new ones
        DELETE FROM scholarships 
        WHERE university_id = utoronto_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (utoronto_id, 'Lester B. Pearson International Scholarship', 'University', 'Full tuition, books, incidental fees, and residence for four years (valued at approximately CAD 250,000)', 'Prestigious international scholarship recognizing exceptional academic achievement, creativity, leadership, and community involvement.', 'International students completing high school who demonstrate academic excellence, leadership, and creativity. Must be nominated by their school.', 'Students must be nominated by their school and then complete the scholarship application if nominated.', 'November (school nomination) / January (student application)', '2%'),
        (utoronto_id, 'University of Toronto Scholars Program', 'University', 'CAD 7,500', 'Recognition for outstanding students entering first year of undergraduate studies.', 'Domestic and international students with exceptional academic achievement.', 'Automatically considered based on admission application.', 'Same as admission application', '10%'),
        (utoronto_id, 'Graduate Funding Package', 'University', 'Minimum CAD 18,000 plus tuition for doctoral students', 'Base funding package for graduate students in doctoral programs and some research master''s programs.', 'Students admitted to doctoral programs and research-stream master''s programs.', 'Automatically considered upon admission to eligible programs.', 'Same as program application', '90%');
        
        -- Clear any existing FAQs for University of Toronto and add new ones
        DELETE FROM university_faqs 
        WHERE university_id = utoronto_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (utoronto_id, 'What are the three campuses of the University of Toronto?', 'UofT has three distinct campuses: 1) St. George, the historic downtown campus in the heart of Toronto; 2) UTM (University of Toronto Mississauga), located in the western suburb of Mississauga with a beautiful campus on 225 acres of protected greenbelt; and 3) UTSC (University of Toronto Scarborough), located in the eastern suburb of Scarborough, known for its co-op programs and multicultural environment. Each campus has its own unique character, facilities, and specialized programs, though they all uphold the same academic standards and grant University of Toronto degrees.'),
        (utoronto_id, 'How does the college system work at UofT?', 'At the St. George campus, undergraduate students in the Faculty of Arts & Science are affiliated with one of seven colleges: Innis, New, St. Michael''s, Trinity, University, Victoria, or Woodsworth. Your college is your academic and social home base, providing services like academic advising, registrarial services, scholarships, and residence. Each college has distinct traditions, architecture, and community. College affiliation doesn''t limit your course or program choices - you can take courses and major in any subject regardless of your college membership. Students in professional faculties like Engineering or Music are not affiliated with colleges.'),
        (utoronto_id, 'What is the POSt system at UofT?', 'POSt stands for "Program of Study" and refers to UofT''s unique admission system, particularly in the Faculty of Arts & Science. Students typically apply to a general admission category and then, after completing their first year, apply to specific programs (POSts) like Computer Science, Economics, or Psychology. Admission to some competitive POSts is based on performance in prerequisite first-year courses. This system allows students to explore different subjects before committing to a specialization, but it also means that admission to popular programs can be competitive even after you''ve been admitted to the university.'),
        (utoronto_id, 'What research opportunities are available for undergraduate students?', 'UofT offers numerous research opportunities for undergraduates across all disciplines. The Research Opportunity Program (ROP) allows second and third-year students to work on faculty research projects for course credit. The Research Excursions Program (REP) provides opportunities for research or creative activities away from campus. Many departments offer independent research courses, and summer research programs like NSERC USRA provide paid research positions. The university also hosts undergraduate research conferences and journals where students can present and publish their work.'),
        (utoronto_id, 'What career services does UofT offer?', 'UofT provides comprehensive career services through the Career Exploration & Education center and faculty-specific career offices. Services include one-on-one career counseling, resume and interview workshops, career assessment tools, and job search strategy development. The university hosts multiple career fairs and employer events throughout the year. The Ten Thousand Coffees@UofT program connects students with alumni for networking. Many programs offer co-op options, internships, or professional experience years (PEY Co-op). The vast alumni network of over 600,000 graduates worldwide provides valuable connections for students entering the job market.');
        
        -- Delete any existing testimonials for University of Toronto
        DELETE FROM testimonials 
        WHERE university_id = utoronto_id;
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (utoronto_id, 'Michael Zhang', 'https://randomuser.me/api/portraits/men/75.jpg', 'Studying Computer Science at UofT has been both challenging and incredibly rewarding. The program is rigorous, with professors who are leading researchers in their fields pushing us to excel. What I value most is the vibrant tech ecosystem around the university - from hackathons to startup incubators and industry partnerships. I''ve had opportunities to work on research projects and complete an internship at a major tech company through the PEY Co-op program. While the workload is demanding, the supportive community of fellow students and the endless opportunities in Toronto make it worthwhile.', 5, true);
    END IF;
END $$; 
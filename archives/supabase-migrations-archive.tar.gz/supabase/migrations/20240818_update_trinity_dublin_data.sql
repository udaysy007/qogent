-- Find the Trinity College Dublin university ID (assuming it already exists)
DO $$
DECLARE
    trinity_id uuid;
BEGIN
    -- Get the ID of Trinity College Dublin
    SELECT id INTO trinity_id FROM universities WHERE name = 'Trinity College Dublin';
    
    -- If Trinity College Dublin doesn't exist, we don't update anything
    IF trinity_id IS NOT NULL THEN
        -- Update Trinity College Dublin with enhanced data
        UPDATE universities
        SET 
            founding_year = 1592,
            campus_image_url = 'https://images.unsplash.com/photo-1565224516947-e08f0390baac?q=80&w=1200',
            student_population = 18000,
            international_student_percentage = 26,
            ranking_the = 155,
            ranking_arwu = 151,
            tuition_fee_domestic = '€8,000 per year',
            tuition_fee_international = '€18,860 - €25,950 per year',
            application_fee = '€55',
            other_fees = 'Student contribution: €3,000 per year; Student services charge: €191 per year',
            health_insurance = 'Non-EU students must have health insurance. Cost ranges from €100-€650 depending on coverage.',
            living_expense_accommodation = '€7,000 - €14,000 per year',
            living_expense_food = '€3,000 - €4,000 per year',
            living_expense_transportation = '€500 - €1,000 per year',
            living_expense_other = '€2,000 - €3,000 per year',
            housing_info = 'Trinity offers limited on-campus housing which is primarily allocated to first-year and international students. Most students live in private accommodations or purpose-built student housing in Dublin city. Trinity''s Accommodation Office assists students in finding suitable housing options.',
            campus_facilities = ARRAY['Libraries', 'Science Gallery', 'Sports Centre', 'Research Facilities', 'Student Union', 'Historic Buildings', 'Dining Halls'],
            international_support = 'Trinity''s Global Room is a hub for international student support and intercultural activities. The International Student Experience team offers orientation programs, immigration advice, and cultural adaptation support.',
            clubs_info = 'Trinity has over 170 clubs and societies, covering sports, arts, politics, volunteering, and cultural interests. Prominent groups include the Historical Society, the oldest student society in the world, and the Philosophical Society.',
            admission_success_rate = '29%',
            students_placed = 520
        WHERE id = trinity_id;
        
        -- Clear any existing programs for Trinity College Dublin and add new ones
        DELETE FROM university_programs 
        WHERE university_id = trinity_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (trinity_id, 'Computer Science', 'Bachelor', 'Technology', 'English', '4 years', 'A comprehensive program covering software development, algorithms, artificial intelligence, and data science with strong industry connections.', '€8,000 (EU) / €25,950 (Non-EU) per year', 'February 1 (EU) / June 30 (Non-EU)', true),
        (trinity_id, 'Business, Economic and Social Studies (BESS)', 'Bachelor', 'Business', 'English', '4 years', 'Trinity''s flagship business program offering specializations in business, economics, political science, and sociology with flexible pathways.', '€8,000 (EU) / €21,105 (Non-EU) per year', 'February 1 (EU) / June 30 (Non-EU)', true),
        (trinity_id, 'MSc in International Management', 'Master', 'Business', 'English', '1 year', 'A transformative program developing global management skills with international business immersion and corporate partnerships.', '€18,500 (EU) / €24,000 (Non-EU)', 'March 31 (Round 1), June 30 (Round 2)', true),
        (trinity_id, 'Electronic and Computer Engineering', 'Bachelor', 'Engineering', 'English', '5 years', 'An integrated program covering electronics, computer systems, telecommunications, control systems and biomedical engineering, with an optional year in industry.', '€8,000 (EU) / €25,950 (Non-EU) per year', 'February 1 (EU) / June 30 (Non-EU)', false);
        
        -- Clear any existing admission requirements for Trinity College Dublin and add new ones
        DELETE FROM admission_requirements 
        WHERE university_id = trinity_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (trinity_id, 'Academic', 'For EU applicants: Points-based system through the CAO (typically 500+ points needed for competitive courses). For Non-EU: Country-specific requirements, generally equivalent to AAA/AAB at A-Level or 1800+ on SAT with Subject Tests.', 'Trinity weighs academic performance heavily, but also values subject relevance. Focus on excelling in subjects related to your chosen program rather than accumulating points in less relevant subjects.'),
        (trinity_id, 'Language', 'Non-native English speakers need IELTS (minimum 6.5 overall with no band below 6.0), TOEFL (minimum 88 internet-based), or Cambridge Proficiency/Advanced (minimum 180).', 'Trinity''s programs involve substantial reading, writing, and discussion. Consider obtaining a stronger English score than the minimum, particularly for humanities and social science programs.'),
        (trinity_id, 'Documents', 'Application through CAO for EU students or direct application for non-EU students. Academic transcripts, personal statement, reference letters, and CV required.', 'Trinity seeks students who can articulate why they want to study their chosen course at Trinity specifically. Your personal statement should reflect your academic interests and how Trinity''s specific teaching approach and resources align with your goals.'),
        (trinity_id, 'Additional Requirements', 'Some courses have additional requirements such as portfolios (e.g., for arts programs), interviews (e.g., for medicine), or entrance exams.', 'For competitive courses, particularly in medicine, performing arts, or creative fields, prepare thoroughly for supplementary assessments as they can be decisive factors in the admission process.');
        
        -- Clear any existing scholarships for Trinity College Dublin and add new ones
        DELETE FROM scholarships 
        WHERE university_id = trinity_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (trinity_id, 'Foundation Scholarship', 'University', 'Full tuition fees, campus accommodation and meals for up to 5 years', 'Trinity''s most prestigious scholarship awarded to students based on exceptional academic performance in challenging exams.', 'Current first-year or Senior Fresh (second-year) undergraduate students at Trinity.', 'Register for and complete a series of challenging exams in your subject area, usually held in January.', 'December (Registration for exams)', '2%'),
        (trinity_id, 'Global Excellence Postgraduate Scholarship', 'University', '€5,000 - €10,000 reduction in tuition fees', 'Merit-based scholarships for international students applying to postgraduate programs at Trinity.', 'Non-EU international students with outstanding academic achievement applying to taught masters programs.', 'Automatically considered upon application to your chosen program.', 'Same as program application deadline', '5%'),
        (trinity_id, 'Sports Scholarship', 'University', '€500 - €5,000 plus additional benefits', 'Supports high-performing student athletes to balance academic and sporting excellence with financial support and specialized services.', 'Students with exceptional sporting ability at national or international level.', 'Submit application with supporting documentation of sporting achievements.', 'July 1', '10%');
        
        -- Clear any existing FAQs for Trinity College Dublin and add new ones
        DELETE FROM university_faqs 
        WHERE university_id = trinity_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (trinity_id, 'What is Trinity College Dublin known for?', 'Trinity College Dublin, founded in 1592, is Ireland''s oldest and most prestigious university. It''s particularly renowned for its programs in English Literature, History, Politics, Computer Science, and Biomedical Sciences. The university is also famous for its historic campus in the heart of Dublin, the stunning Long Room Library, and the Book of Kells exhibition. Trinity has produced notable alumni including Oscar Wilde, Samuel Beckett, and Mary Robinson.'),
        (trinity_id, 'How does the Irish higher education system work?', 'The Irish university system uses the European Credit Transfer System (ECTS), with undergraduate degrees typically taking 3-4 years and master''s degrees 1-2 years. Irish universities operate on a two-semester academic year (September-December and January-May). For EU students, applications are processed through the Central Applications Office (CAO), while non-EU students apply directly to the university. Ireland uses a points-based system for undergraduate admissions, based on performance in the Leaving Certificate or equivalent qualifications.'),
        (trinity_id, 'What is student life like at Trinity College Dublin?', 'Trinity offers a vibrant student experience in the center of Dublin. The university has over 170 clubs and societies, ranging from sports to politics, arts, and special interests. Trinity Ball is Europe''s largest private party, held annually on campus. The Student Union represents students and organizes events and services. While Trinity doesn''t have a traditional campus outside the city, its historic city-center location puts students in the heart of Dublin''s cultural scene, with museums, theaters, shops, and restaurants all within walking distance.'),
        (trinity_id, 'What career services does Trinity offer?', 'Trinity''s Careers Service provides comprehensive support including career counseling, CV workshops, interview preparation, career fairs, and industry networking events. The service maintains strong connections with employers and offers a jobs portal for students and recent graduates. Many programs include internship opportunities or professional placements, and Trinity has a strong track record of graduate employability, with 93% of graduates either employed or in further study within six months of graduation.'),
        (trinity_id, 'What support services are available for international students?', 'Trinity''s Global Room serves as a hub for international student support, offering orientation programs, cultural events, and practical assistance. The International Student Experience team provides guidance on immigration, accommodation, health insurance, and cultural adjustment. Trinity Welcome Programme helps new international students settle in before term starts. Peer mentoring pairs new international students with current students for personalized support. English language support is available through free in-session courses and workshops.');
        
        -- Delete any existing testimonials for Trinity College Dublin
        DELETE FROM testimonials 
        WHERE university_id = trinity_id;
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (trinity_id, 'Ryan McCarthy', 'https://randomuser.me/api/portraits/men/45.jpg', 'Studying Computer Science at Trinity has been transformative. The program strikes a perfect balance between theoretical foundations and practical applications. What makes Trinity special is the combination of a historic setting with cutting-edge research. The professors are truly world-class and approachable, and Dublin provides an ideal environment for both academic and personal growth. The tech industry connections here have opened doors to internships and job opportunities I wouldn''t have found elsewhere.', 5, true);
    END IF;
END $$; 
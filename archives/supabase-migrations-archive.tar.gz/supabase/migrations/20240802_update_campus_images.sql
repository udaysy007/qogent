-- Update campus images for all universities
-- This ensures that campus images are consistent and use local files

-- Technical University of Munich (already has a value but let's make it consistent)
UPDATE universities 
SET campus_image_url = '/images/universities/tum-campus.jpg'
WHERE slug = 'technical-university-of-munich';

-- Trinity College Dublin
UPDATE universities 
SET campus_image_url = '/images/universities/tcd-campus.jpg'
WHERE slug = 'trinity-college-dublin';

-- University of Toronto
UPDATE universities 
SET campus_image_url = '/images/universities/uoft-campus.jpg'
WHERE slug = 'university-of-toronto';

-- Harvard University
UPDATE universities 
SET campus_image_url = '/images/universities/harvard-campus.jpg'
WHERE slug = 'harvard-university';

-- Stanford University
UPDATE universities 
SET campus_image_url = '/images/universities/stanford-campus.jpg'
WHERE slug = 'stanford-university';

-- MIT
UPDATE universities 
SET campus_image_url = '/images/universities/mit-campus.jpg'
WHERE slug = 'mit';

-- University of Cambridge
UPDATE universities 
SET campus_image_url = '/images/universities/cambridge-campus.jpg'
WHERE slug = 'university-cambridge';

-- University of Oxford
UPDATE universities 
SET campus_image_url = '/images/universities/oxford-campus.jpg'
WHERE slug = 'university-oxford';

-- Imperial College London
UPDATE universities 
SET campus_image_url = '/images/universities/imperial-campus.jpg'
WHERE slug = 'imperial-college-london';

-- Nanyang Technological University
UPDATE universities 
SET campus_image_url = '/images/universities/ntu-campus.jpg'
WHERE slug = 'nanyang-technological-university';

-- National University of Singapore
UPDATE universities 
SET campus_image_url = '/images/universities/nus-campus.jpg'
WHERE slug = 'national-university-singapore';

-- Singapore Management University
UPDATE universities 
SET campus_image_url = '/images/universities/smu-campus.jpg'
WHERE slug = 'singapore-management-university';

-- Jagiellonian University
UPDATE universities 
SET campus_image_url = '/images/universities/jagiellonian-campus.jpg'
WHERE slug = 'jagiellonian-university';

-- Warsaw University of Technology
UPDATE universities 
SET campus_image_url = '/images/universities/wut-campus.jpg'
WHERE slug = 'warsaw-university-technology';

-- University of Warsaw
UPDATE universities 
SET campus_image_url = '/images/universities/warsaw-campus.jpg'
WHERE slug = 'university-warsaw';

-- Utrecht University
UPDATE universities 
SET campus_image_url = '/images/universities/utrecht-campus.jpg'
WHERE slug = 'utrecht-university';

-- University of Amsterdam
UPDATE universities 
SET campus_image_url = '/images/universities/uva-campus.jpg'
WHERE slug = 'university-amsterdam';

-- Delft University of Technology
UPDATE universities 
SET campus_image_url = '/images/universities/tudelft-campus.jpg'
WHERE slug = 'delft-university-technology';

-- Newly downloaded images for universities that were missing campus images
-- Heidelberg University
UPDATE universities 
SET campus_image_url = '/images/universities/heidelberg-campus.jpg'
WHERE slug = 'heidelberg-university';

-- Humboldt University of Berlin
UPDATE universities 
SET campus_image_url = '/images/universities/humboldt-campus.jpg'
WHERE slug = 'humboldt-university-berlin';

-- McGill University
UPDATE universities 
SET campus_image_url = '/images/universities/mcgill-campus.jpg'
WHERE slug = 'mcgill-university';

-- National University of Ireland Galway
UPDATE universities 
SET campus_image_url = '/images/universities/nuig-campus.jpg'
WHERE slug = 'national-university-ireland-galway';

-- University College Dublin
UPDATE universities 
SET campus_image_url = '/images/universities/ucd-campus.jpg'
WHERE slug = 'university-college-dublin';

-- University of British Columbia
UPDATE universities 
SET campus_image_url = '/images/universities/ubc-campus.jpg'
WHERE slug = 'university-british-columbia'; 
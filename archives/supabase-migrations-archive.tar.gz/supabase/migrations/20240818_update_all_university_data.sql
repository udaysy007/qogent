-- Main migration file to update all university data
-- This file imports all individual university data migrations

-- Import MIT data
\i 'supabase/migrations/20240818_update_mit_data.sql'

-- Import Harvard data
\i 'supabase/migrations/20240818_update_harvard_data.sql'

-- Import Stanford data
\i 'supabase/migrations/20240818_update_stanford_data.sql'

-- Import Oxford data
\i 'supabase/migrations/20240818_update_oxford_data.sql'

-- Import Trinity College Dublin data
\i 'supabase/migrations/20240818_update_trinity_dublin_data.sql'

-- Import University College Dublin data
\i 'supabase/migrations/20240818_update_ucd_data.sql'

-- Import Cambridge data
\i 'supabase/migrations/20240818_update_cambridge_data.sql'

-- Import Imperial College London data
\i 'supabase/migrations/20240818_update_imperial_data.sql'

-- Import University of Toronto data
\i 'supabase/migrations/20240818_update_utoronto_data.sql'

-- Import Delft University of Technology data
\i 'supabase/migrations/20240818_update_delft_data.sql'

-- Import Heidelberg University data
\i 'supabase/migrations/20240818_update_heidelberg_data.sql'

-- Import Humboldt University of Berlin data
\i 'supabase/migrations/20240818_update_humboldt_data.sql'

-- Import Jagiellonian University data
\i 'supabase/migrations/20240818_update_jagiellonian_data.sql'

-- Import McGill University data
\i 'supabase/migrations/20240818_update_mcgill_data.sql'

-- Import Nanyang Technological University data
\i 'supabase/migrations/20240818_update_ntu_data.sql'

-- Import National University of Ireland Galway data
\i 'supabase/migrations/20240818_update_nuig_data.sql'

-- Import National University of Singapore data
\i 'supabase/migrations/20240818_update_nus_data.sql'

-- Import University of British Columbia data
\i 'supabase/migrations/20240818_update_ubc_data.sql'

-- Import University of Amsterdam data
\i 'supabase/migrations/20240818_update_amsterdam_data.sql'

-- Import Utrecht University data
\i 'supabase/migrations/20240818_update_utrecht_data.sql'

-- Import University of Warsaw data
\i 'supabase/migrations/20240818_update_warsaw_uni_data.sql'

-- Import Warsaw University of Technology data
\i 'supabase/migrations/20240818_update_warsaw_tech_data.sql'

-- Import Singapore Management University data
\i 'supabase/migrations/20240818_update_smu_data.sql'

-- Technical University of Munich was already updated in a separate migration
-- See: supabase/migrations/20240716_populate_tum_data.sql

-- All 24 universities now have migration files
-- This completes the university data update 
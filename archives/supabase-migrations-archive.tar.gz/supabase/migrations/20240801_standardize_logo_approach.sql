-- Standardize university logo approach by removing logo_url from the schema
-- Since we're using generated placeholders with abbreviations, we don't need to store logo URLs

-- First, set all logo_url to NULL to ensure no old references remain
UPDATE universities SET logo_url = NULL;

-- Comment out the logo_url column but keep it for backward compatibility
-- We're not dropping it to avoid breaking existing code or potential edge cases
COMMENT ON COLUMN universities.logo_url IS 'DEPRECATED: No longer used. University logos are now generated using abbreviations via placehold.co'; 
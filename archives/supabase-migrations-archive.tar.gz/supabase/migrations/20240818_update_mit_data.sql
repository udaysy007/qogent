-- Find the MIT university ID (assuming it already exists)
DO $$
DECLARE
    mit_id uuid;
BEGIN
    -- Get the ID of MIT
    SELECT id INTO mit_id FROM universities WHERE name = 'Massachusetts Institute of Technology';
    
    -- If MIT doesn't exist, we don't update anything
    IF mit_id IS NOT NULL THEN
        -- Update MIT with enhanced data
        UPDATE universities
        SET 
            founding_year = 1861,
            campus_image_url = 'https://images.unsplash.com/photo-1564504412109-e97b1c84459c?q=80&w=1200',
            student_population = 11520,
            international_student_percentage = 29,
            ranking_the = 4,
            ranking_arwu = 3,
            tuition_fee_domestic = '$55,510 per year',
            tuition_fee_international = '$55,510 per year',
            application_fee = '$75',
            other_fees = 'Student life fee: $380',
            health_insurance = 'Approximately $3,300 per year',
            living_expense_accommodation = '$11,800 - $18,000 per year',
            living_expense_food = '$6,000 - $7,000 per year',
            living_expense_transportation = '$2,000 - $3,000 per year',
            living_expense_other = '$2,500 - $3,500 per year',
            housing_info = 'MIT guarantees housing for all four years of undergraduate study. Graduate housing is available on and off-campus through MIT. First-year undergraduates are required to live on campus.',
            campus_facilities = ARRAY['Libraries', 'Research Labs', 'Art & Media Centers', 'Sports Facilities', 'Student Center', 'Makerspaces', 'Innovation Hub'],
            international_support = 'The International Students Office provides comprehensive support services including orientation, immigration assistance, and cultural programming.',
            clubs_info = 'MIT offers over 500 student organizations, including cultural groups, academic clubs, performing arts, and athletics.',
            admission_success_rate = '45%',
            students_placed = 420
        WHERE id = mit_id;
        
        -- Clear any existing programs for MIT and add new ones
        DELETE FROM university_programs 
        WHERE university_id = mit_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (mit_id, 'Computer Science and Engineering', 'Bachelor', 'Engineering', 'English', '4 years', 'The program focuses on the fundamentals of computer science and electrical engineering, emphasizing the design of computing systems in a variety of contexts.', '$55,510 per year', 'Regular Action: January 1, Early Action: November 1', true),
        (mit_id, 'Electrical Engineering and Computer Science', 'Master', 'Engineering', 'English', '1-2 years', 'This program provides in-depth knowledge of electrical engineering, computer science, and the intersection of the two fields.', '$55,510 per year', 'December 15', true),
        (mit_id, 'Mechanical Engineering', 'Master', 'Engineering', 'English', '1-2 years', 'The program focuses on advanced mechanical design, robotics, manufacturing, and computational engineering.', '$55,510 per year', 'December 15', false),
        (mit_id, 'Business Analytics', 'Master', 'Business', 'English', '1 year', 'This program equips students with data science skills for business decision-making through machine learning, optimization, and analytics.', '$55,510 per year', 'January 8', true);
        
        -- Clear any existing admission requirements for MIT and add new ones
        DELETE FROM admission_requirements 
        WHERE university_id = mit_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (mit_id, 'Academic', 'Exceptional academic performance with high GPA. SAT or ACT scores (optional but recommended). Advanced Placement (AP) or International Baccalaureate (IB) coursework is highly regarded.', 'MIT values creative problem-solving skills over perfect GPAs. Demonstrate your innovative thinking through projects and research experiences.'),
        (mit_id, 'Language', 'For international students: TOEFL (Minimum 90) or IELTS (Minimum 7.0) scores are required.', 'Beyond meeting the minimum requirements, strong communication skills are essential at MIT. Consider highlighting your English language experience in collaborative settings.'),
        (mit_id, 'Documents', 'Common App or Coalition App, personal essays, activity list, recommendation letters (2 from teachers, 1 from counselor), transcript, and standardized test scores if available.', 'MIT reads applications holistically. Your essays should highlight your passion for learning, collaborative spirit, and how you''ve made an impact in your community.');
        
        -- Clear any existing scholarships for MIT and add new ones
        DELETE FROM scholarships 
        WHERE university_id = mit_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (mit_id, 'MIT Scholarship', 'University', 'Average award: $50,000 per year', 'MIT meets 100% of demonstrated financial need for all admitted students through a combination of scholarships, grants, and work-study.', 'Based on financial need as determined by the CSS Profile and FAFSA.', 'Submit CSS Profile and FAFSA along with admission application.', 'February 15', '65%'),
        (mit_id, 'Fulbright Program', 'Government', 'Full tuition and stipend', 'The Fulbright Program provides grants for U.S. and international students for study/research.', 'International students with outstanding academic achievements and leadership potential.', 'Apply through the Fulbright commission in your home country.', 'Varies by country, typically early spring', '10%'),
        (mit_id, 'MIT Presidential Fellowship', 'University', 'Full tuition + $4,000 monthly stipend', 'Prestigious fellowship for exceptional first-year doctoral students demonstrating outstanding research potential.', 'Incoming PhD students with exceptional academic records and research experience.', 'Nominated by academic departments during the admission process.', 'Same as PhD application deadline', '5%');
        
        -- Clear any existing FAQs for MIT and add new ones
        DELETE FROM university_faqs 
        WHERE university_id = mit_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (mit_id, 'How selective is MIT?', 'MIT is extremely selective with an acceptance rate of approximately 4-7%. The university looks for students who demonstrate academic excellence, innovation, collaborative spirit, and alignment with MIT''s mission.'),
        (mit_id, 'Does MIT offer financial aid to international students?', 'Yes, MIT is one of the few US universities that offers need-blind admissions for all applicants, including international students. Financial aid packages are designed to meet 100% of demonstrated need.'),
        (mit_id, 'What is special about MIT''s educational approach?', 'MIT emphasizes hands-on problem-solving, interdisciplinary collaboration, and learning-by-doing. The curriculum balances theoretical concepts with practical application through labs, research opportunities, and project-based learning.'),
        (mit_id, 'What is the "Mens et Manus" philosophy?', 'MIT''s motto "Mens et Manus" (mind and hand) reflects the university''s emphasis on both theoretical knowledge and practical application. Students are encouraged to apply classroom learning to real-world problems.'),
        (mit_id, 'What career support does MIT offer?', 'MIT provides extensive career resources through the Career Advising & Professional Development office, including career counseling, resume reviews, mock interviews, networking events, career fairs, and connections to MIT''s powerful alumni network.');
        
        -- Delete any existing testimonials for MIT and add new ones
        DELETE FROM testimonials 
        WHERE university_id = mit_id;
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (mit_id, 'David Chen', 'https://randomuser.me/api/portraits/men/32.jpg', 'Studying at MIT pushed me beyond what I thought was possible. The collaborative culture and access to cutting-edge research facilities helped me develop both technically and personally. The connections I made here opened doors I never imagined.', 5, true);
    END IF;
END $$; 
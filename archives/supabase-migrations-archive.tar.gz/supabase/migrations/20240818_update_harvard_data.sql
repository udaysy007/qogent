-- Find the Harvard university ID (assuming it already exists)
DO $$
DECLARE
    harvard_id uuid;
BEGIN
    -- Get the ID of Harvard
    SELECT id INTO harvard_id FROM universities WHERE name = 'Harvard University';
    
    -- If Harvard doesn't exist, we don't update anything
    IF harvard_id IS NOT NULL THEN
        -- Update Harvard with enhanced data
        UPDATE universities
        SET 
            founding_year = 1636,
            campus_image_url = 'https://images.unsplash.com/photo-1580328355429-5204b5482528?q=80&w=1200',
            student_population = 23731,
            international_student_percentage = 24,
            ranking_the = 2,
            ranking_arwu = 1,
            tuition_fee_domestic = '$52,659 per year',
            tuition_fee_international = '$52,659 per year',
            application_fee = '$75',
            other_fees = 'Student services fee: $3,109 per year',
            health_insurance = 'Approximately $4,080 per year',
            living_expense_accommodation = '$12,000 - $21,130 per year',
            living_expense_food = '$7,200 per year',
            living_expense_transportation = '$1,000 - $2,000 per year',
            living_expense_other = '$3,000 - $4,000 per year',
            housing_info = 'Harvard guarantees housing for all four years of undergraduate study in the historic Harvard Yard for first-years and in 12 upperclass Houses for sophomores through seniors. Graduate student housing is available but not guaranteed.',
            campus_facilities = ARRAY['Libraries', 'Museums', 'Research Centers', 'Athletic Facilities', 'Arts Venues', 'Dining Halls', 'Innovation Labs'],
            international_support = 'The Harvard International Office assists international students with visa issues, work permits, cultural adjustment, and provides programs for integration into campus life.',
            clubs_info = 'Harvard offers over 450 official student organizations covering interests from academic and pre-professional groups to cultural organizations, publications, performing arts, and recreational clubs.',
            admission_success_rate = '39%',
            students_placed = 830
        WHERE id = harvard_id;
        
        -- Clear any existing programs for Harvard and add new ones
        DELETE FROM university_programs 
        WHERE university_id = harvard_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (harvard_id, 'Computer Science', 'Bachelor', 'Technology', 'English', '4 years', 'The program provides a foundation in computer science, systems, theory, and mathematics, with opportunities for interdisciplinary study.', '$52,659 per year', 'Regular Decision: January 1, Early Action: November 1', true),
        (harvard_id, 'MBA', 'Master', 'Business', 'English', '2 years', 'Harvard Business School''s MBA program prepares students for leadership challenges through case-based learning and field experiences.', '$73,440 per year', 'Round 1: September, Round 2: January, Round 3: April', true),
        (harvard_id, 'Master in Public Policy', 'Master', 'Government', 'English', '2 years', 'The Kennedy School''s MPP program develops leaders in public service through rigorous analytical training and practical policy applications.', '$53,166 per year', 'Early December', false),
        (harvard_id, 'Environmental Science and Engineering', 'Bachelor', 'Engineering', 'English', '4 years', 'Students learn to address environmental challenges through the application of engineering, scientific, and technological principles.', '$52,659 per year', 'Regular Decision: January 1, Early Action: November 1', true);
        
        -- Clear any existing admission requirements for Harvard and add new ones
        DELETE FROM admission_requirements 
        WHERE university_id = harvard_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (harvard_id, 'Academic', 'Strong academic record with challenging coursework. No minimum GPA requirement, but admitted students typically rank at the top of their class. SAT/ACT scores are optional but can strengthen an application.', 'Harvard seeks students who have maximized their academic opportunities. Show intellectual curiosity by pursuing advanced courses in areas of interest beyond minimum requirements.'),
        (harvard_id, 'Language', 'For international students: TOEFL (minimum 100), IELTS (minimum 7.0), or Duolingo English Test (minimum 125) required.', 'Harvard''s discussion-based classes require strong communication skills. Consider highlighting leadership experiences that demonstrate your ability to articulate ideas clearly in English.'),
        (harvard_id, 'Documents', 'Common Application or Coalition Application, Harvard College Questions, SAT/ACT scores (optional), School Report and transcripts, Teacher Reports (2), Mid-Year School Report, Final School Report.', 'Harvard''s holistic review process considers the whole person. Use your personal essay to reveal aspects of your character and experiences not evident elsewhere in your application.'),
        (harvard_id, 'Additional Requirements', 'Arts supplement (optional) for students with exceptional talent in arts. Interview with Harvard alumnus/a (when available).', 'If you excel in arts, music, or other creative pursuits, submitting the Arts Supplement can significantly strengthen your application. Prepare thoroughly for alumni interviews by reflecting on your goals and motivations.');
        
        -- Clear any existing scholarships for Harvard and add new ones
        DELETE FROM scholarships 
        WHERE university_id = harvard_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (harvard_id, 'Harvard Financial Aid', 'University', 'Average award: $53,000 per year', 'Harvard''s need-based financial aid program meets 100% of demonstrated financial need for all admitted students. Families earning less than $85,000 pay nothing, and those earning $85,000-$150,000 typically contribute 0-10% of their income.', 'Based on financial need as determined by the CSS Profile and FAFSA. Available to both domestic and international students.', 'Submit CSS Profile, FAFSA (US students), and required tax documents.', 'November (Early Action) / February (Regular Decision)', '70%'),
        (harvard_id, 'Herchel Smith Scholarship', 'University', 'Full tuition and living expenses', 'Prestigious scholarship for Harvard undergraduates to pursue graduate studies at Cambridge University.', 'Harvard seniors with exceptional academic achievement and research potential.', 'Apply through Harvard''s Office of Undergraduate Research and Fellowships.', 'February', '3%'),
        (harvard_id, 'Harvard Graduate School Scholarships', 'University', 'Varies by program and school', 'Merit and need-based scholarships available across Harvard''s graduate and professional schools.', 'Varies by program. May consider academic excellence, leadership potential, and financial need.', 'Apply through individual graduate school applications.', 'Varies by program', '15%');
        
        -- Clear any existing FAQs for Harvard and add new ones
        DELETE FROM university_faqs 
        WHERE university_id = harvard_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (harvard_id, 'What is the Harvard House System?', 'The House System is central to Harvard''s undergraduate experience. After freshman year in Harvard Yard, students live in one of 12 residential Houses for their remaining three years. Each House has its own dining hall, common spaces, faculty deans, and unique traditions, creating smaller communities within the larger university.'),
        (harvard_id, 'How does Harvard''s financial aid work?', 'Harvard offers need-blind admissions and meets 100% of demonstrated financial need for all admitted students, regardless of citizenship. Families with incomes below $85,000 pay nothing for their child to attend, while those with incomes between $85,000 and $150,000 typically pay 0-10% of their income. About 55% of students receive need-based scholarship aid.'),
        (harvard_id, 'What is Harvard''s General Education program?', 'Harvard''s Gen Ed program requires students to take courses in four categories: Aesthetics & Culture; Ethics & Civics; Histories, Societies, Individuals; and Science & Technology in Society. These courses help students connect their studies to important issues beyond their concentration.'),
        (harvard_id, 'What research opportunities are available for undergraduates?', 'Harvard provides extensive research opportunities for undergraduates through programs like PRISE (Program for Research in Science and Engineering), BLISS (Behavioral Laboratory in the Social Sciences), and SHARP (Summer Humanities and Arts Research Program). Students can also receive funding for independent research projects.'),
        (harvard_id, 'What makes Harvard''s teaching approach unique?', 'Harvard combines traditional lectures with smaller seminars and tutorials. The university emphasizes critical thinking, interdisciplinary learning, and hands-on research experiences. Faculty members are leaders in their fields who bring cutting-edge research into the classroom.');
        
        -- Delete any existing testimonials for Harvard
        DELETE FROM testimonials 
        WHERE university_id = harvard_id;
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (harvard_id, 'Jennifer Park', 'https://randomuser.me/api/portraits/women/45.jpg', 'My time at Harvard has been transformative in ways I never expected. Beyond the academic rigor and brilliant professors, the House system created a supportive community that became my home. The diversity of interests, backgrounds, and perspectives among my peers has broadened my worldview and challenged me to grow in new directions.', 5, true);
    END IF;
END $$; 
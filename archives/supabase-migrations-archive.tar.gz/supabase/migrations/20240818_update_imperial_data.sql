-- Find the Imperial College London university ID (assuming it already exists)
DO $$
DECLARE
    imperial_id uuid;
BEGIN
    -- Get the ID of Imperial College London
    SELECT id INTO imperial_id FROM universities WHERE name = 'Imperial College London';
    
    -- If Imperial College London doesn't exist, we don't update anything
    IF imperial_id IS NOT NULL THEN
        -- Update Imperial College London with enhanced data
        UPDATE universities
        SET 
            founding_year = 1907,
            campus_image_url = 'https://images.unsplash.com/photo-1544019682-c0c7956828e1?q=80&w=1200',
            student_population = 22000,
            international_student_percentage = 60,
            ranking_the = 10,
            ranking_arwu = 25,
            tuition_fee_domestic = '£9,250 per year',
            tuition_fee_international = '£29,500 - £45,300 per year',
            application_fee = '£80',
            other_fees = 'College fees: Varies by program',
            health_insurance = 'Immigration Health Surcharge for visa holders: £624 per year',
            living_expense_accommodation = '£8,000 - £15,000 per year',
            living_expense_food = '£3,600 - £5,400 per year',
            living_expense_transportation = '£800 - £1,500 per year',
            living_expense_other = '£2,000 - £3,500 per year',
            housing_info = 'Imperial has a range of halls of residence across several locations in London. First-year undergraduates are guaranteed accommodation if they meet application deadlines. Most halls offer single rooms with shared facilities, though some en-suite and studio options are available. The Student Hub assists students in finding private accommodation after their first year.',
            campus_facilities = ARRAY['Research Laboratories', 'Libraries', 'Students'' Union', 'Sports Facilities', 'Performance Spaces', 'Innovation Spaces', 'Student Wellbeing Support'],
            international_support = 'The International Student Support team provides comprehensive services including visa and immigration advice, cultural adjustment support, orientation programs, and English language support courses for both academic and everyday communication.',
            clubs_info = 'Imperial College Union supports over 380 clubs and societies covering academic interests, culture, arts, and sports. The Union also runs bars, cafes, and organizes regular social events throughout the year. Students can join existing groups or create new ones for special interests.',
            admission_success_rate = '14%',
            students_placed = 580
        WHERE id = imperial_id;
        
        -- Clear any existing programs for Imperial College London and add new ones
        DELETE FROM university_programs 
        WHERE university_id = imperial_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (imperial_id, 'Computing', 'Bachelor', 'Technology', 'English', '3-4 years', 'A comprehensive program covering core computing principles, software engineering, artificial intelligence, and machine learning with strong industry connections and research opportunities.', '£9,250 (UK) / £36,200 (International) per year', 'January 15 (UCAS)', true),
        (imperial_id, 'Mechanical Engineering', 'Bachelor', 'Engineering', 'English', '4 years', 'An accredited program blending mechanical engineering fundamentals with cutting-edge technologies in robotics, sustainable energy, and advanced manufacturing.', '£9,250 (UK) / £38,600 (International) per year', 'January 15 (UCAS)', true),
        (imperial_id, 'MSc in Machine Learning', 'Master', 'Technology', 'English', '1 year', 'A pioneering program offering advanced study in machine learning, computational statistics, and artificial intelligence applications across various sectors.', '£38,500 (all students)', 'January 31', true),
        (imperial_id, 'Medicine', 'Bachelor', 'Medicine', 'English', '6 years', 'An innovative medical curriculum integrating basic medical sciences with clinical practice in London''s leading teaching hospitals, emphasizing research skills and evidence-based medicine.', '£9,250 (UK) / £45,300 (International) per year', 'October 15 (UCAS)', false);
        
        -- Clear any existing admission requirements for Imperial College London and add new ones
        DELETE FROM admission_requirements 
        WHERE university_id = imperial_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (imperial_id, 'Academic', 'Exceptionally strong academic record with emphasis on mathematics and sciences. For UK students: A*A*A or A*AA at A-level with specific subject requirements depending on the course. International qualifications assessed for equivalence.', 'Imperial places exceptional weight on mathematical and scientific ability. Even for subjects like business or medicine, strong performance in mathematics is highly valued and often required.'),
        (imperial_id, 'Language', 'For non-native English speakers: IELTS (minimum 6.5-7.0 overall depending on program, with no component below 6.0), TOEFL (minimum 92-100 depending on program), or equivalent certification.', 'Due to the technical nature of most Imperial programs and collaborative project work, strong command of English is essential. Consider preparing by engaging with technical literature in your field in English.'),
        (imperial_id, 'Documents', 'UCAS application for undergraduate programs or direct application for postgraduate programs, personal statement, academic transcripts, reference letters, and CV for some programs.', 'Your personal statement should demonstrate both academic excellence and extracurricular engagement, particularly in areas related to your field. For Imperial, highlight research experience, technical projects, or relevant work experience.'),
        (imperial_id, 'Additional Requirements', 'Many programs require interviews, and some require additional admissions tests (e.g., BMAT for Medicine). Portfolio reviews for design-related courses.', 'Imperial''s interviews often involve technical questions and problem-solving scenarios. Practice explaining your thought process while solving technical or scientific problems, as this skill is highly valued during interviews.');
        
        -- Clear any existing scholarships for Imperial College London and add new ones
        DELETE FROM scholarships 
        WHERE university_id = imperial_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (imperial_id, 'President''s Undergraduate Scholarships', 'University', '£1,000 per year for duration of course', 'Prestigious scholarships awarded to undergraduate students demonstrating outstanding academic achievement and potential.', 'Exceptional academic achievers nominated by their department after admission.', 'No separate application required; departments nominate candidates from admitted students.', 'Nominations by July', '5%'),
        (imperial_id, 'Imperial College London Scholarships', 'University', 'Full or partial tuition fees depending on specific scholarship', 'Range of scholarships for international students based on academic merit, financial need, and nationality.', 'International students with outstanding academic records applying to specific courses. Some scholarships are country-specific.', 'Varies by scholarship; most require a separate application after admission.', 'January 31 for most scholarships', '10%'),
        (imperial_id, 'Undergraduate Bursary', 'University', 'Up to £5,000 per year', 'Means-tested support for UK students from lower-income households to assist with living costs.', 'UK undergraduate students with household income below £60,000, with higher awards for lower incomes.', 'Students are automatically assessed based on information provided to Student Finance England.', 'Same as student finance application', '40%');
        
        -- Clear any existing FAQs for Imperial College London and add new ones
        DELETE FROM university_faqs 
        WHERE university_id = imperial_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (imperial_id, 'What is Imperial College London known for?', 'Imperial College London is world-renowned for its excellence in science, engineering, medicine, and business. It consistently ranks among the top universities globally, particularly in engineering and technology disciplines. The university has a strong focus on innovation and entrepreneurship, with numerous startups emerging from its research and student projects. Imperial has particular strengths in fields like artificial intelligence, bioengineering, climate science, and medical technology.'),
        (imperial_id, 'What is student life like at Imperial?', 'Student life at Imperial is vibrant and intellectually stimulating. The main South Kensington campus is located in one of London''s most cultural areas, surrounded by museums, parks, and landmarks. Students have access to over 380 clubs and societies through Imperial College Union, covering everything from academic interests to sports and the arts. While academics are rigorous and demanding, there''s a strong collaborative culture among students. London itself provides endless opportunities for social activities, cultural experiences, and professional networking.'),
        (imperial_id, 'How does Imperial support research and innovation?', 'Imperial provides extensive support for research and innovation through specialized facilities, funding opportunities, and industry partnerships. The Enterprise Lab helps students develop entrepreneurial ideas, while the Advanced Hackspace provides tools and workspace for prototyping. The college actively facilitates collaboration with industry through its Corporate Partnerships team. For researchers, Imperial offers substantial internal funding and support for grant applications. The Innovation Hub connects researchers with businesses to commercialize discoveries, and the college maintains one of the largest technology transfer offices in the UK.'),
        (imperial_id, 'What career support does Imperial offer?', 'Imperial''s Careers Service provides comprehensive support throughout students'' academic journey and beyond graduation. Services include one-to-one career consultations, CV and application reviews, interview preparation, and career assessment tools. The college hosts numerous employer events, career fairs, and networking opportunities with leading companies that actively recruit Imperial graduates. Many courses include industrial placements or projects with industry partners. Imperial maintains an extensive alumni network that offers mentoring and professional connections. The college''s graduates are highly sought after, with consistently high employment rates in their fields.'),
        (imperial_id, 'What is Imperial''s approach to teaching and learning?', 'Imperial employs a multi-faceted approach to teaching and learning, combining traditional lectures with interactive tutorials, laboratory work, and project-based learning. Many programs incorporate a significant research component, with undergraduates often participating in authentic research projects. The college emphasizes digital learning, with most courses having online components to support flexible study. Problem-solving and practical application of knowledge are central to the Imperial educational philosophy. Group work and interdisciplinary collaboration are common features across programs, preparing students for real-world professional environments. Imperial regularly reviews and updates its curriculum to incorporate the latest developments in each field.');
        
        -- Delete any existing testimonials for Imperial College London
        DELETE FROM testimonials 
        WHERE university_id = imperial_id;
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (imperial_id, 'Priya Sharma', 'https://randomuser.me/api/portraits/women/41.jpg', 'Studying Bioengineering at Imperial has been challenging but incredibly rewarding. The faculty are leaders in their fields and truly passionate about their research, which inspires us to push boundaries. What sets Imperial apart is the hands-on experience - from my first year, I''ve been working on real research problems and industry projects. The diversity of the student body brings so many perspectives to group work, and despite the intensive workload, there''s a strong sense of community. Living in London has also provided amazing opportunities for internships and networking that wouldn''t be possible elsewhere.', 5, true);
    END IF;
END $$; 
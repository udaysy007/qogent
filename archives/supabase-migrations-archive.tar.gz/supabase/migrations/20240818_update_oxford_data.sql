-- Find the Oxford university ID (assuming it already exists)
DO $$
DECLARE
    oxford_id uuid;
BEGIN
    -- Get the ID of Oxford
    SELECT id INTO oxford_id FROM universities WHERE name = 'University of Oxford';
    
    -- If Oxford doesn't exist, we don't update anything
    IF oxford_id IS NOT NULL THEN
        -- Update Oxford with enhanced data
        UPDATE universities
        SET 
            founding_year = 1096,
            campus_image_url = 'https://images.unsplash.com/photo-1580301762395-83dcf0c04c2e?q=80&w=1200',
            student_population = 24515,
            international_student_percentage = 41,
            ranking_the = 1,
            ranking_arwu = 7,
            tuition_fee_domestic = '£9,250 per year',
            tuition_fee_international = '£26,770 - £39,010 per year',
            application_fee = '£75',
            other_fees = 'College fees: £7,570 - £9,445 per year',
            health_insurance = 'NHS available to students on visas longer than 6 months; private insurance options available.',
            living_expense_accommodation = '£7,200 - £9,200 per year',
            living_expense_food = '£3,600 - £5,400 per year',
            living_expense_transportation = '£400 - £1,000 per year',
            living_expense_other = '£1,800 - £3,000 per year',
            housing_info = 'Oxford operates a collegiate system where first-year undergraduates are guaranteed college accommodation. Many colleges also offer accommodation for subsequent years. Graduate accommodation options include college housing and university-owned graduate accommodation.',
            campus_facilities = ARRAY['Libraries', 'Museums', 'Laboratories', 'Sports Complexes', 'Performance Venues', 'Gardens', 'Historic Buildings'],
            international_support = 'Oxford''s Student Information and Immigration Service assists international students with visa requirements, offers orientation programs, and provides ongoing support throughout their studies.',
            clubs_info = 'Oxford has over 400 clubs and societies through the Oxford University Student Union and its colleges, covering sports, politics, culture, arts, media, religion, and special interests.',
            admission_success_rate = '21%',
            students_placed = 690
        WHERE id = oxford_id;
        
        -- Clear any existing programs for Oxford and add new ones
        DELETE FROM university_programs 
        WHERE university_id = oxford_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (oxford_id, 'Philosophy, Politics and Economics (PPE)', 'Bachelor', 'Interdisciplinary', 'English', '3 years', 'Oxford''s renowned PPE program provides a rigorous interdisciplinary education that has educated prime ministers, presidents, and global leaders.', '£9,250 (UK) / £29,700 (International) per year', 'October 15', true),
        (oxford_id, 'Computer Science', 'Bachelor', 'Technology', 'English', '3-4 years', 'Combines theoretical foundations with practical applications in areas like artificial intelligence, machine learning, and systems.', '£9,250 (UK) / £37,910 (International) per year', 'October 15', true),
        (oxford_id, 'MBA', 'Master', 'Business', 'English', '1 year', 'Oxford''s one-year MBA program integrates rigorous academic training with practical business application and leadership development.', '£63,000', 'January (Round 2), April (Round 3), September (Round 4)', true),
        (oxford_id, 'MSc in Mathematical and Computational Finance', 'Master', 'Finance', 'English', '10-12 months', 'Elite program training students in mathematical theory and computational techniques for finance and risk management careers.', '£35,380 per year', 'January (preferred deadline)', false);
        
        -- Clear any existing admission requirements for Oxford and add new ones
        DELETE FROM admission_requirements 
        WHERE university_id = oxford_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (oxford_id, 'Academic', 'Exceptional academic achievement with top grades in relevant subjects. For UK students, typically AAA at A-Level. International qualifications are assessed for equivalence.', 'Oxford values depth over breadth. Focus on achieving excellence in subjects directly relevant to your intended course of study rather than pursuing a wide range of subjects.'),
        (oxford_id, 'Language', 'For non-native English speakers: IELTS (minimum 7.0 overall, no less than 6.5 in any component), TOEFL (minimum 100), or Cambridge C1 Advanced/C2 Proficiency (minimum 185).', 'Oxford tutorials require articulate expression of complex ideas. Consider preparing by engaging in academic debates or discussions in English beyond what''s required for standard proficiency tests.'),
        (oxford_id, 'Documents', 'UCAS application, personal statement, academic transcripts, teacher/academic references. Some courses require submission of written work.', 'Your personal statement should demonstrate deep engagement with your subject beyond the school curriculum. Discuss specific texts, theories, or problems that have fascinated you.'),
        (oxford_id, 'Additional Requirements', 'Most courses require a subject-specific admissions test. Many courses also require an interview. Specific requirements vary by course.', 'The Oxford interview assesses how you think, not just what you know. Practice discussing your subject, working through unfamiliar problems aloud, and responding to challenging questions that test your intellectual flexibility.');
        
        -- Clear any existing scholarships for Oxford and add new ones
        DELETE FROM scholarships 
        WHERE university_id = oxford_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (oxford_id, 'Clarendon Scholarships', 'University', 'Full tuition and fees plus annual grant for living expenses', 'Oxford''s flagship graduate scholarship program, supporting approximately 140 scholars each year across all subject areas.', 'All graduate applicants automatically considered. Awarded based on academic excellence and potential.', 'No separate application required; considered automatically when applying to graduate programs.', 'January (varies by course)', '5%'),
        (oxford_id, 'Rhodes Scholarship', 'Rhodes Trust', 'Full tuition and fees plus annual stipend of £15,900', 'One of the world''s most prestigious international scholarships, supporting outstanding students from selected countries to pursue graduate study at Oxford.', 'Varies by constituency. Generally requires academic excellence, leadership potential, and commitment to service.', 'Apply through Rhodes constituency. Process includes written application, recommendation letters, and interviews.', 'Varies by country (typically August-October)', '2%'),
        (oxford_id, 'Oxford-Weidenfeld and Hoffmann Scholarships', 'University', 'Full tuition and fees plus living expenses', 'Supports graduate students from developing and emerging economies to study subjects that will benefit their home countries.', 'Graduate applicants from specific countries in Africa, Asia, Latin America, and Eastern Europe.', 'Complete the standard scholarship application when applying for graduate admission.', 'January (varies by course)', '7%');
        
        -- Clear any existing FAQs for Oxford and add new ones
        DELETE FROM university_faqs 
        WHERE university_id = oxford_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (oxford_id, 'What is the Oxford collegiate system?', 'Oxford comprises 39 self-governing colleges and permanent private halls that form the core of the university experience. When you apply to Oxford, you apply to a specific college or can make an open application. Your college provides accommodation, dining facilities, social activities, pastoral support, and tutorials. Each college has its own character, traditions, and facilities, while the central university provides lectures, labs, libraries, and examinations.'),
        (oxford_id, 'What is the Oxford tutorial system?', 'The tutorial is Oxford''s distinctive teaching method where students meet weekly in very small groups (typically 1-3 students) with a tutor who is a specialist in their subject. Students prepare work in advance, such as an essay or problem sheet, which they discuss with their tutor. This intensive method develops critical thinking, argumentation skills, and deep subject knowledge through personalized feedback and challenging discussions.'),
        (oxford_id, 'How does the Oxford academic year work?', 'The Oxford academic year consists of three 8-week terms: Michaelmas (October-December), Hilary (January-March), and Trinity (April-June). Terms are intense periods of teaching, learning and assessment, while vacations are considered part of the academic year and are used for independent study, reading, research, and preparation.'),
        (oxford_id, 'How competitive is admission to Oxford?', 'Oxford is highly competitive, with an overall acceptance rate of around 17-20%, though this varies significantly by course and college. For the most competitive courses like Economics & Management, Medicine, and Law, acceptance rates can be below 10%. International applicants face particularly competitive odds in many programs.'),
        (oxford_id, 'Are there part-time work opportunities for students?', 'During term time, the intensive nature of Oxford''s programs makes substantial part-time work difficult. The university recommends no more than 8 hours of work per week during term. However, many students find work opportunities during vacations, and there are some casual positions available within colleges and departments.');
        
        -- Delete any existing testimonials for Oxford
        DELETE FROM testimonials 
        WHERE university_id = oxford_id;
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (oxford_id, 'Sophia Williams', 'https://randomuser.me/api/portraits/women/33.jpg', 'The tutorial system at Oxford truly transformed how I approach learning. Having to defend my ideas every week to world-class academics pushed me to levels of intellectual rigor I never thought possible. Beyond academics, the collegiate system created a supportive community where I formed deep friendships with people from around the world. The city itself, with its blend of ancient traditions and cutting-edge research, provides a magical environment for learning.', 5, true);
    END IF;
END $$; 
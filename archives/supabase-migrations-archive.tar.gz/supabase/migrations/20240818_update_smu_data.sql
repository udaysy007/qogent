-- Find the Singapore Management University university ID (assuming it already exists)
DO $$
DECLARE
    smu_id uuid;
BEGIN
    -- Get the ID of Singapore Management University
    SELECT id INTO smu_id FROM universities WHERE name = 'Singapore Management University';
    
    -- If Singapore Management University doesn't exist, we don't update anything
    IF smu_id IS NOT NULL THEN
        -- Update Singapore Management University with enhanced data
        UPDATE universities
        SET 
            founding_year = 2000,
            campus_image_url = 'https://images.unsplash.com/photo-1599687266725-0d152e88f168?q=80&w=1200',
            student_population = 10000,
            international_student_percentage = 20,
            ranking_the = 801,
            ranking_arwu = 901,
            tuition_fee_domestic = 'SGD 11,450 - SGD 13,950 per year (subsidized for Singaporeans)',
            tuition_fee_international = 'SGD 25,920 - SGD 31,970 per year',
            application_fee = 'SGD 15 - SGD 30',
            other_fees = 'Student services fee: SGD 350 per year',
            health_insurance = 'Mandatory for all students: SGD 250 per year',
            living_expense_accommodation = 'SGD 7,200 - SGD 14,400 per year',
            living_expense_food = 'SGD 3,600 - SGD 7,200 per year',
            living_expense_transportation = 'SGD 1,000 - SGD 1,500 per year',
            living_expense_other = 'SGD 2,000 - SGD 3,000 per year',
            housing_info = 'SMU does not have on-campus dormitories, but offers student housing through partnerships with private providers near campus. SMU Student Housing offers accommodations at Prinsep Street Residences (PSR) which is a short walk from campus. The university''s Office of Campus Development assists students in finding suitable private housing options in Singapore. Many international students choose to rent private apartments or join shared housing arrangements in areas like Chinatown, Little India, and Bugis, all of which are close to SMU''s city campus.',
            campus_facilities = ARRAY['Libraries', 'Study Lounges', 'Sports Facilities', 'Campus Green', 'Seminar Rooms', 'Collaboration Spaces', 'Innovation Labs'],
            international_support = 'The International Student Experience team provides comprehensive support including pre-arrival guidance, orientation programs, visa assistance, and cultural integration activities. SMU also offers buddy programs pairing international students with local students, and organizes cultural events and excursions throughout the year.',
            clubs_info = 'SMU has over 120 student clubs and organizations spanning academic, professional, sports, arts, and special interest domains. The Office of Student Life coordinates campus-wide events and supports student initiatives. Each school also has its own student association organizing discipline-specific activities and networking events.',
            admission_success_rate = '42%',
            students_placed = 650
        WHERE id = smu_id;
        
        -- Clear any existing programs for Singapore Management University and add new ones
        DELETE FROM university_programs 
        WHERE university_id = smu_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (smu_id, 'Bachelor of Business Management', 'Bachelor', 'Business', 'English', '4 years', 'A comprehensive business program with specializations in finance, marketing, operations, and entrepreneurship, featuring interactive seminars, overseas exchanges, and industry internships.', 'SGD 12,650 (Subsidized) / SGD 28,890 (International) per year', 'March 19', true),
        (smu_id, 'Bachelor of Science in Information Systems', 'Bachelor', 'Technology', 'English', '4 years', 'A technology-focused program combining IT knowledge with business applications, featuring specializations in AI, fintech, cybersecurity, and digital transformation with mandatory internships.', 'SGD 13,950 (Subsidized) / SGD 31,970 (International) per year', 'March 19', true),
        (smu_id, 'Master of Business Administration', 'Master', 'Business', 'English', '12-18 months', 'A globally recognized MBA program focusing on Asian business perspectives, leadership development, and innovation with emphasis on real-world applications and industry connections.', 'SGD 79,500 (all students)', 'October 31 (Round 1) / January 31 (Round 2) / March 31 (Round 3)', true),
        (smu_id, 'Master of IT in Business (MITB)', 'Master', 'Technology', 'English', '1-2 years', 'An innovative program developing expertise in fintech, analytics, and digital solutions with industry projects and specialization tracks in financial technology, analytics, and artificial intelligence.', 'SGD 42,800 (all students)', 'June 15', false);
        
        -- Clear any existing admission requirements for Singapore Management University and add new ones
        DELETE FROM admission_requirements 
        WHERE university_id = smu_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (smu_id, 'Academic', 'For Bachelor''s programs: Strong high school qualification equivalent to Singapore-Cambridge GCE ''A'' Levels, International Baccalaureate (IB), or other recognized qualifications. For graduate programs: Bachelor''s degree with good standing from a recognized university.', 'SMU places significant emphasis on holistic assessment beyond just academic grades. While strong academics are important, the university highly values leadership experiences, community service, and extracurricular achievements. For undergraduate admissions, prepare for the SMU Admission Exercise, which includes written assessments and interviews to evaluate critical thinking and communication skills.'),
        (smu_id, 'Language', 'For all programs: TOEFL (minimum 90 internet-based), IELTS (minimum 6.5 overall), or other approved tests. Exemptions for those from English-medium institutions.', 'While meeting minimum language requirements is sufficient for admission, stronger English proficiency will significantly benefit your academic performance at SMU. The university''s seminar-style teaching approach requires active participation in discussions and frequent presentation of ideas, making strong verbal communication skills particularly important.'),
        (smu_id, 'Documents', 'Online application, academic transcripts, personal statement, CV, recommendation letters, and standardized test scores (if applicable).', 'In your personal statement and interview, emphasize experiences that demonstrate SMU''s core values of being transformative, collaborative, and catalytic. The university seeks students who can articulate how they will contribute to SMU''s interactive learning environment and leverage the university''s city location and industry connections.'),
        (smu_id, 'Additional Requirements', 'Undergraduate programs require the SMU Admission Exercise (written test and interview). Some specialized programs have additional requirements. MBA and some graduate programs require GMAT/GRE scores.', 'The SMU interview process evaluates your ability to think on your feet and communicate clearly. Prepare by practicing how to articulate your thoughts concisely and support your opinions with evidence. For business and law programs especially, stay current with industry trends and be ready to discuss current events relevant to your field of study.');
        
        -- Clear any existing scholarships for Singapore Management University and add new ones
        DELETE FROM scholarships 
        WHERE university_id = smu_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (smu_id, 'SMU Global Impact Scholarship', 'University', 'Full tuition plus SGD 5,000 annual living allowance and other benefits', 'Prestigious scholarship for outstanding undergraduates demonstrating academic excellence, leadership, and community engagement.', 'Outstanding undergraduate applicants (all nationalities) with exceptional academic achievements and demonstrated leadership potential.', 'Shortlisted candidates from undergraduate applications invited for scholarship selection process including interviews.', 'Same as admission application', '3%'),
        (smu_id, 'ASEAN Undergraduate Scholarship', 'University', 'Full tuition for 4 years', 'Merit-based scholarships for outstanding students from ASEAN countries.', 'Citizens of ASEAN countries (except Singapore) with excellent academic records and strong co-curricular achievements.', 'Apply through the online application portal after receiving admission offer.', 'Same as admission deadline', '10%'),
        (smu_id, 'SMU Asian MBA Scholarship', 'University', 'SGD 20,000 tuition fee waiver', 'Partial scholarships for outstanding MBA candidates with demonstrated leadership potential.', 'MBA applicants with excellent academic and professional records, strong leadership skills, and interest in Asian business.', 'Apply through the MBA admissions portal with supplementary scholarship essay.', 'Same as MBA application deadline', '20%');
        
        -- Clear any existing FAQs for Singapore Management University and add new ones
        DELETE FROM university_faqs 
        WHERE university_id = smu_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (smu_id, 'What makes SMU different from other universities?', 'Singapore Management University (SMU) stands out with its interactive, seminar-style teaching approach that contrasts with the traditional lecture-based education at many Asian universities. Classes are kept small (maximum 45 students) to facilitate discussion and participation. SMU is uniquely located in the heart of Singapore''s business district, providing unparalleled access to industry connections and internship opportunities. The university follows an American-style curriculum with broad-based education and flexibility in course selection. SMU places strong emphasis on global exposure, with over 86% of undergraduates participating in international experiences before graduation. The university is particularly known for its strengths in business, law, information systems, and social sciences, with a focus on interdisciplinary learning. SMU''s pedagogy emphasizes project-based learning, case studies, and presentations to develop both technical knowledge and soft skills valued by employers.'),
        (smu_id, 'What is the SMU teaching approach?', 'SMU employs a distinctive interactive, seminar-style teaching methodology that encouragages active participation and discussion rather than passive listening. Classes are conducted in seminar rooms rather than lecture halls, with a maximum of 45 students per class to ensure everyone can participate. The curriculum emphasizes critical thinking, problem-solving, and communication skills through case discussions, group projects, and presentations. Class participation typically forms a significant portion of the grade (often 20-30%), encouraging students to actively contribute to discussions. Faculty members serve as facilitators of learning rather than merely transmitters of knowledge. Students are expected to prepare for classes by completing assigned readings and case studies beforehand. The teaching approach is designed to develop confidence, articulation skills, and the ability to think on your feet – qualities highly valued in the professional world. This interactive approach prepares students for the workplace by simulating professional environments where collaboration, presentation, and quick thinking are essential.'),
        (smu_id, 'What are the career prospects for SMU graduates?', 'SMU graduates enjoy strong employment prospects, with over 94% securing employment within six months of graduation, and many receiving job offers before graduation. The university''s Dato'' Kho Hui Meng Career Centre provides comprehensive career services including counseling, resume workshops, mock interviews, and career fairs featuring hundreds of employers. SMU''s city campus location in Singapore''s business district creates natural networking opportunities and visibility with potential employers. All undergraduate students complete a mandatory internship (minimum 10 weeks), with many completing multiple internships before graduation. The university maintains strong connections with industry through its Industry Engagement strategy, with many courses featuring industry projects or guest speakers. SMU''s focus on developing communication and critical thinking skills alongside technical knowledge produces graduates who are highly sought after by employers. The university has a strong alumni network of over 36,000 graduates across various industries, providing valuable professional connections. Singapore''s position as a business hub for Asia Pacific offers diverse career opportunities with both local and multinational companies.'),
        (smu_id, 'What international opportunities are available at SMU?', 'SMU offers extensive international exposure opportunities, with over 86% of undergraduates participating in some form of global experience before graduation. The university has exchange partnerships with more than 300 universities across 50 countries, allowing students to spend a semester or full academic year abroad. Short-term study missions (typically 1-2 weeks) focus on specific industries or themes in different countries, combining academic learning with company visits and cultural experiences. International internships can be arranged through SMU''s global career services, particularly in major cities across Asia, Europe, and North America. SMU''s International Office facilitates overseas community service projects where students volunteer in developing countries. The university attracts a diverse student population from over 40 countries, creating an international learning environment on campus. Many courses incorporate global content and perspectives, preparing students for careers in an increasingly internationalized business environment. SMU''s Business Study Mission program takes students to different countries to study business practices and market dynamics firsthand.'),
        (smu_id, 'What is student life like at SMU and in Singapore?', 'Student life at SMU is vibrant and dynamic, with a strong emphasis on student involvement beyond academics. The city campus location provides a unique urban university experience integrated into Singapore''s business district. Student organizations are highly active, with over 120 clubs covering interests from professional development to sports, arts, and community service. Campus events include student-organized competitions, performances, career networking sessions, and social gatherings. SMU''s student body is diverse, with international students comprising about 20% of the population, creating a multicultural campus environment. Singapore itself offers exceptional quality of life with its safety, cleanliness, efficient transportation, and vibrant cultural scene. The city-state''s strategic location makes it an ideal base for traveling throughout Southeast Asia during academic breaks. Singapore''s cultural diversity is reflected in its neighborhoods, festivals, and especially its renowned food scene, from hawker centers to fine dining. While Singapore has a reputation for being expensive, student life can be affordable with careful budgeting, especially with the many reasonably-priced food options available across the city.');
        
        -- Delete any existing testimonials for Singapore Management University
        DELETE FROM testimonials 
        WHERE university_id = smu_id;
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (smu_id, 'Lin Wei Chen', 'https://randomuser.me/api/portraits/women/63.jpg', 'Studying Information Systems at SMU has been a transformative experience that perfectly balanced technical skills with business knowledge. The seminar-style teaching approach was initially challenging, as I had to speak up in every class, but it dramatically improved my communication skills and confidence. What sets SMU apart is its strong industry connections – through the mandatory internship program, I secured a position at a leading technology company that later extended a full-time offer. The city campus location meant I could attend industry events and networking sessions easily, often meeting professionals who became mentors. The curriculum''s project-based approach meant we were constantly solving real business problems, not just learning theory. My overseas exchange semester in South Korea broadened my perspectives, while SMU''s diverse student body created a truly global classroom environment. The rigorous program definitely keeps you busy, but the career opportunities and professional growth make every challenge worthwhile.', 5, true);
    END IF;
END $$; 
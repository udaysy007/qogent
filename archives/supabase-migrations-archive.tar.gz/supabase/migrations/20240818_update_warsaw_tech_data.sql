-- Find the Warsaw University of Technology ID (assuming it already exists)
DO $$
DECLARE
    wut_id uuid;
BEGIN
    -- Get the ID of Warsaw University of Technology
    SELECT id INTO wut_id FROM universities WHERE name = 'Warsaw University of Technology';
    
    -- If Warsaw University of Technology doesn't exist, we don't update anything
    IF wut_id IS NOT NULL THEN
        -- Update Warsaw University of Technology with enhanced data
        UPDATE universities
        SET 
            founding_year = 1826,
            campus_image_url = 'https://images.unsplash.com/photo-1600280293382-38a283366464?q=80&w=1200',
            student_population = 31000,
            international_student_percentage = 12,
            ranking_the = 801,
            ranking_arwu = 701,
            tuition_fee_domestic = 'Free',
            tuition_fee_international = '€2,000 - €3,000 per year',
            application_fee = '€20',
            other_fees = 'Registration fee: €100 per semester',
            health_insurance = 'EU students: EHIC card, Non-EU: €60 per month',
            living_expense_accommodation = '€200 - €450 per month',
            living_expense_food = '€200 - €300 per month',
            living_expense_transportation = '€15 - €30 per month (with student discount)',
            living_expense_other = '€100 - €200 per month',
            housing_info = 'University dormitories available for around €100-€250 per month. Private flats available from €300-€600 per month depending on location and number of roommates.',
            campus_facilities = ARRAY['Libraries', 'Computer Labs', 'Sports Centers', 'Student Clubs', 'Research Centers', 'Technology Labs'],
            international_support = 'The International Students Office provides assistance with visa procedures, accommodation, and offers orientation programs for international students.',
            clubs_info = 'Over 100 student organizations including scientific circles, cultural groups, and sports teams. Strong focus on engineering and technology clubs.',
            admission_success_rate = '48%',
            students_placed = 530
        WHERE id = wut_id;
        
        -- Clear any existing programs for Warsaw University of Technology and add new ones
        DELETE FROM university_programs 
        WHERE university_id = wut_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (wut_id, 'Computer Science', 'Bachelor', 'Engineering', 'English', '3.5 years', 'This comprehensive program covers algorithms, software development, computer networks, and artificial intelligence with a strong emphasis on practical applications.', '€2,500 per year', 'July 15', true),
        (wut_id, 'Mechanical Engineering', 'Master', 'Engineering', 'English', '1.5 years', 'Advanced studies in mechanical engineering with specializations in robotics, mechatronics, and aerospace engineering.', '€3,000 per year', 'June 30', true),
        (wut_id, 'Civil Engineering', 'Bachelor', 'Engineering', 'English', '3.5 years', 'Program focusing on structural design, construction management, and sustainable building technologies.', '€2,500 per year', 'July 15', false),
        (wut_id, 'Management and Production Engineering', 'Master', 'Engineering', 'English', '1.5 years', 'Combines business management principles with production engineering knowledge to prepare leaders for industrial settings.', '€3,000 per year', 'June 30', true);
        
        -- Clear any existing admission requirements for Warsaw University of Technology and add new ones
        DELETE FROM admission_requirements 
        WHERE university_id = wut_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (wut_id, 'Academic', 'Secondary school diploma with good grades in mathematics and physics. Entrance exam may be required for some programs.', 'Strong mathematical skills are essential for success at WUT. Consider taking additional advanced math courses if possible.'),
        (wut_id, 'Language', 'For English-taught programs: B2 level English proficiency (IELTS 6.0, TOEFL iBT 80). Polish programs require Polish language certification.', 'Beyond meeting minimum requirements, strong technical English vocabulary will help you succeed in engineering courses.'),
        (wut_id, 'Documents', 'Application form, secondary school diploma with transcript, ID/passport copy, language certificate, health insurance certificate, medical certificate.', 'Start gathering documents early, especially if they need translation and legalization, which can take several weeks.');
        
        -- Clear any existing scholarships for Warsaw University of Technology and add new ones
        DELETE FROM scholarships 
        WHERE university_id = wut_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (wut_id, 'Rector''s Scholarship for Academic Achievement', 'University', '€100 - €300 per month', 'Merit-based scholarship awarded to students with exceptional academic results.', 'Students with GPA in the top 10% of their program.', 'Automatic consideration based on academic performance after the first year of studies.', 'October 10', '10%'),
        (wut_id, 'Polish National Agency for Academic Exchange Scholarship', 'Government', 'Full tuition + €350 monthly stipend', 'Scholarship for international students pursuing full-degree studies in Poland.', 'International students with excellent academic records.', 'Apply through the NAWA website with required documents.', 'March 31', '15%'),
        (wut_id, 'Erasmus+ Scholarship', 'European Union', '€450 - €600 per month', 'Mobility scholarship for EU students studying at WUT for one or two semesters.', 'EU students enrolled in higher education institutions with Erasmus agreements.', 'Apply through the home university Erasmus office.', 'Varies by university', '30%');
        
        -- Clear any existing FAQs for Warsaw University of Technology and add new ones
        DELETE FROM university_faqs 
        WHERE university_id = wut_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (wut_id, 'What is the teaching language at Warsaw University of Technology?', 'Most programs are taught in Polish, but WUT offers a growing number of programs fully taught in English, particularly at the Master''s level and in engineering fields.'),
        (wut_id, 'Are there Polish language courses available for international students?', 'Yes, WUT offers Polish language courses at various levels for international students. Intensive courses are available before the academic year, and regular courses continue throughout the year.'),
        (wut_id, 'What accommodation options are available for students?', 'WUT offers student dormitories that are significantly more affordable than private rentals. Places are limited, so early application is recommended. The International Relations Office can also assist with finding private accommodation.'),
        (wut_id, 'How is the job market for graduates in Warsaw?', 'Warsaw has a strong job market for engineering and technical graduates. Many international companies have operations in Warsaw and regularly recruit WUT graduates. The university has good relationships with industry partners and organizes career fairs.'),
        (wut_id, 'Are there internship opportunities available during studies?', 'Yes, WUT has partnerships with many companies offering internships to students. Most engineering programs include mandatory internships, and the Career Office helps students find relevant opportunities.');
        
        -- Delete any existing testimonials for Warsaw University of Technology and add new ones
        DELETE FROM testimonials 
        WHERE university_id = wut_id;
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (wut_id, 'Marta Kowalczyk', 'https://randomuser.me/api/portraits/women/42.jpg', 'Studying Electrical Engineering at WUT was challenging but immensely rewarding. The professors are experts in their fields and the lab facilities are excellent. The university''s strong connections with industry helped me secure an internship that led to a job offer before graduation.', 5, true);
    END IF;
END $$; 
-- Enhance universities table with all the fields needed for the detail page
ALTER TABLE universities
-- Basic information
ADD COLUMN IF NOT EXISTS founding_year integer,
ADD COLUMN IF NOT EXISTS campus_image_url text,
ADD COLUMN IF NOT EXISTS student_population integer DEFAULT 0,
ADD COLUMN IF NOT EXISTS international_student_percentage integer DEFAULT 0,

-- Rankings
ADD COLUMN IF NOT EXISTS ranking_the integer,
ADD COLUMN IF NOT EXISTS ranking_arwu integer,

-- Costs
ADD COLUMN IF NOT EXISTS tuition_fee_domestic text DEFAULT '',
ADD COLUMN IF NOT EXISTS tuition_fee_international text DEFAULT '',
ADD COLUMN IF NOT EXISTS application_fee text,
ADD COLUMN IF NOT EXISTS other_fees text,
ADD COLUMN IF NOT EXISTS health_insurance text DEFAULT '',
ADD COLUMN IF NOT EXISTS living_expense_accommodation text DEFAULT '',
ADD COLUMN IF NOT EXISTS living_expense_food text DEFAULT '',
ADD COLUMN IF NOT EXISTS living_expense_transportation text DEFAULT '',
ADD COLUMN IF NOT EXISTS living_expense_other text DEFAULT '',

-- Student Life
ADD COLUMN IF NOT EXISTS housing_info text DEFAULT '',
ADD COLUMN IF NOT EXISTS campus_facilities text[] DEFAULT '{}'::text[],
ADD COLUMN IF NOT EXISTS international_support text DEFAULT '',
ADD COLUMN IF NOT EXISTS clubs_info text DEFAULT '',

-- Qogent Metrics
ADD COLUMN IF NOT EXISTS admission_success_rate text DEFAULT '85%',
ADD COLUMN IF NOT EXISTS students_placed integer DEFAULT 0;

-- We need to create separate tables for the complex nested data

-- Creating university_programs table if it doesn't exist
CREATE TABLE IF NOT EXISTS university_programs (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    university_id uuid NOT NULL REFERENCES universities(id) ON DELETE CASCADE,
    name text NOT NULL,
    degree text NOT NULL,
    field text NOT NULL,
    language text NOT NULL,
    duration text NOT NULL,
    description text DEFAULT '',
    tuition_fee text DEFAULT '',
    application_deadlines text DEFAULT '',
    is_popular boolean DEFAULT false,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);

-- Creating admission_requirements table if it doesn't exist
CREATE TABLE IF NOT EXISTS admission_requirements (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    university_id uuid NOT NULL REFERENCES universities(id) ON DELETE CASCADE,
    type text NOT NULL,
    description text NOT NULL,
    qogent_insight text,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);

-- Creating scholarships table if it doesn't exist
CREATE TABLE IF NOT EXISTS scholarships (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    university_id uuid NOT NULL REFERENCES universities(id) ON DELETE CASCADE,
    name text NOT NULL,
    provider text NOT NULL,
    amount text NOT NULL,
    description text DEFAULT '',
    eligibility text DEFAULT '',
    application_process text DEFAULT '',
    deadline text DEFAULT '',
    success_rate text,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);

-- Creating faqs table if it doesn't exist
CREATE TABLE IF NOT EXISTS university_faqs (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    university_id uuid NOT NULL REFERENCES universities(id) ON DELETE CASCADE,
    question text NOT NULL,
    answer text NOT NULL,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);

-- Creating testimonials table if it doesn't exist
CREATE TABLE IF NOT EXISTS testimonials (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    university_id uuid NOT NULL REFERENCES universities(id) ON DELETE CASCADE,
    student_name text NOT NULL,
    student_image text,
    program text NOT NULL,
    year integer NOT NULL,
    quote text NOT NULL,
    rating integer DEFAULT 5,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_university_programs_university_id ON university_programs(university_id);
CREATE INDEX IF NOT EXISTS idx_admission_requirements_university_id ON admission_requirements(university_id);
CREATE INDEX IF NOT EXISTS idx_scholarships_university_id ON scholarships(university_id);
CREATE INDEX IF NOT EXISTS idx_university_faqs_university_id ON university_faqs(university_id);
CREATE INDEX IF NOT EXISTS idx_testimonials_university_id ON testimonials(university_id); 
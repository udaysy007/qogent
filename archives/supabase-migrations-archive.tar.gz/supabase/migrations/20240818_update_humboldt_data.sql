-- Find the Humboldt University of Berlin university ID (assuming it already exists)
DO $$
DECLARE
    humboldt_id uuid;
BEGIN
    -- Get the ID of Humboldt University of Berlin
    SELECT id INTO humboldt_id FROM universities WHERE name = 'Humboldt University of Berlin';
    
    -- If Humboldt University of Berlin doesn't exist, we don't update anything
    IF humboldt_id IS NOT NULL THEN
        -- Update Humboldt University of Berlin with enhanced data
        UPDATE universities
        SET 
            founding_year = 1810,
            campus_image_url = 'https://images.unsplash.com/photo-1609180708848-3962dd5eb32a?q=80&w=1200',
            student_population = 33000,
            international_student_percentage = 17,
            ranking_the = 89,
            ranking_arwu = 101,
            tuition_fee_domestic = 'No tuition fees; semester contribution of €315 per semester',
            tuition_fee_international = 'No tuition fees; semester contribution of €315 per semester',
            application_fee = 'None',
            other_fees = 'Semester fee includes public transportation ticket for Berlin (zones ABC)',
            health_insurance = 'Mandatory health insurance: approximately €110 per month',
            living_expense_accommodation = '€3,600 - €7,200 per year',
            living_expense_food = '€2,400 - €3,600 per year',
            living_expense_transportation = 'Included in semester fee',
            living_expense_other = '€1,800 - €3,000 per year',
            housing_info = 'Humboldt University does not operate its own housing but works with studierendenWERK Berlin, which offers student housing in various locations throughout the city. Competition for these dormitories is high, so early application is recommended. Most students live in private apartments or shared flats (WGs), which are generally more affordable in Berlin than in many other European capitals, though finding accommodation can be challenging due to Berlin''s competitive housing market.',
            campus_facilities = ARRAY['Libraries', 'Computer Labs', 'Cafeterias', 'Sports Centers', 'Language Center', 'Cultural Venues', 'Research Institutes'],
            international_support = 'The International Office provides comprehensive support for international students, including orientation weeks, buddy programs, and assistance with administrative procedures. The university offers German language courses specifically designed for international students to help with academic and social integration.',
            clubs_info = 'Humboldt University has numerous student organizations covering academic interests, cultural activities, political engagement, sports, and social causes. The student parliament (StuPa) and student council (RefRat) actively represent student interests and organize various events throughout the academic year.',
            admission_success_rate = '28%',
            students_placed = 620
        WHERE id = humboldt_id;
        
        -- Clear any existing programs for Humboldt University of Berlin and add new ones
        DELETE FROM university_programs 
        WHERE university_id = humboldt_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (humboldt_id, 'Cultural Studies', 'Bachelor', 'Humanities', 'German', '6 semesters', 'An interdisciplinary program examining cultural phenomena, practices, and theories from historical and contemporary perspectives with Berlin''s rich cultural landscape as a backdrop.', '€315 per semester (semester fee)', 'July 15 (winter) / January 15 (summer)', true),
        (humboldt_id, 'Economics and Management Science', 'Master', 'Business', 'English', '4 semesters', 'A research-oriented program combining economic theory with quantitative methods and providing specialization tracks in areas such as competition policy, public economics, and applied economics.', '€315 per semester (semester fee)', 'May 31', true),
        (humboldt_id, 'Computer Science', 'Bachelor', 'Technology', 'German', '6 semesters', 'A comprehensive program covering theoretical foundations and practical applications of computer science with a strong emphasis on algorithmic thinking and mathematical methods.', '€315 per semester (semester fee)', 'July 15 (winter) / January 15 (summer)', true),
        (humboldt_id, 'International Relations', 'Master', 'Social Sciences', 'English', '4 semesters', 'An interdisciplinary program analyzing global politics, international law, and transnational governance with special focus on European integration and transatlantic relations.', '€315 per semester (semester fee)', 'May 31', false);
        
        -- Clear any existing admission requirements for Humboldt University of Berlin and add new ones
        DELETE FROM admission_requirements 
        WHERE university_id = humboldt_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (humboldt_id, 'Academic', 'For Bachelor''s programs: Secondary school leaving certificate equivalent to German Abitur. For Master''s programs: Relevant Bachelor''s degree with good academic standing (typically 2.5 or better in the German grading system).', 'For international qualifications, Humboldt uses the database of the German Academic Exchange Service (DAAD) to determine equivalence. If your qualification is deemed insufficient, consider applying to a Studienkolleg preparatory course before reapplying to the university.'),
        (humboldt_id, 'Language', 'For German-taught programs: DSH-2 or TestDaF 4 in all sections, or equivalent. For English-taught programs: Typically IELTS (minimum 6.5) or TOEFL (minimum 87 internet-based), but requirements vary by program.', 'Even for English-taught programs, some basic German skills are highly advantageous for daily life in Berlin. Consider taking one of Humboldt''s pre-semester German language courses to help with both academic and social integration.'),
        (humboldt_id, 'Documents', 'Application form, certified copies of academic records with translations if not in German or English, language certificates, CV, and program-specific requirements such as motivation letters or writing samples.', 'International applicants should start the application process early, as document authentication and visa procedures can take considerable time. For some countries, applications must be processed through uni-assist, which has additional processing times.'),
        (humboldt_id, 'Additional Requirements', 'Some programs have entrance examinations, interviews, or require additional materials such as writing samples or research proposals. Master''s programs typically require a specific minimum of credit points in relevant subjects from your Bachelor''s studies.', 'For competitive Master''s programs, particularly in areas like economics or international relations, highlight previous research experience and specific academic interests that align with Humboldt''s research strengths to stand out from other applicants.');
        
        -- Clear any existing scholarships for Humboldt University of Berlin and add new ones
        DELETE FROM scholarships 
        WHERE university_id = humboldt_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (humboldt_id, 'Deutschlandstipendium', 'Federal Government and Private Donors', '€300 per month for at least two semesters', 'Merit-based scholarships for talented and high-achieving students at German universities.', 'Bachelor''s and Master''s students with excellent academic records and demonstrated social engagement or exceptional personal circumstances.', 'Apply through the university''s online portal with academic records, CV, and motivation letter.', 'June 30 for winter semester', '11%'),
        (humboldt_id, 'DAAD Scholarships', 'German Academic Exchange Service', 'Varies (typically covering living expenses and health insurance)', 'Various scholarship programs supporting international students studying in Germany.', 'International students with excellent academic achievement. Specific eligibility criteria vary by program.', 'Apply directly through the DAAD portal with required documents.', 'Varies by program (usually October-December for following academic year)', '15%'),
        (humboldt_id, 'Humboldt Research Track Scholarship', 'University', '€300-€400 per month for 6-12 months', 'Scholarships supporting Master''s students planning to pursue a PhD, enabling them to develop a research project and establish contact with potential supervisors.', 'Master''s students in their final year with excellent academic records and interest in pursuing doctoral studies.', 'Apply with research proposal, academic records, and letter of recommendation from a Humboldt professor.', 'July 31 and January 31', '25%');
        
        -- Clear any existing FAQs for Humboldt University of Berlin and add new ones
        DELETE FROM university_faqs 
        WHERE university_id = humboldt_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (humboldt_id, 'What is Humboldt University of Berlin known for?', 'Humboldt University of Berlin (Humboldt-Universität zu Berlin) is one of Germany''s oldest and most prestigious universities, founded in 1810 based on Wilhelm von Humboldt''s innovative educational concepts emphasizing the unity of research and teaching. It''s renowned for its contributions to the humanities, social sciences, and natural sciences, with notable strengths in philosophy, history, economics, and physics. The university has associations with 55 Nobel Prize winners, including Albert Einstein and Max Planck. Humboldt University played a significant role in Germany''s complex history, from the imperial era through the divisions of the Cold War (when it was located in East Berlin) to reunification, making it a place where educational traditions and contemporary research intersect with Germany''s historical legacy.'),
        (humboldt_id, 'What is student life like in Berlin?', 'Berlin offers one of Europe''s most dynamic student experiences with a unique blend of history, culture, and affordability. As Germany''s capital and largest city, Berlin has a vibrant, diverse atmosphere with countless cultural venues, from world-class museums and galleries to alternative art spaces and underground clubs. The city is known for its relatively low cost of living compared to other European capitals, making it accessible for students on a budget. Berlin''s efficient public transportation system (included in the semester ticket) makes it easy to explore the city''s diverse neighborhoods. Students appreciate the city''s relaxed attitude, creative energy, and international character - Berlin attracts students and young professionals from around the world, creating a cosmopolitan environment. The city''s turbulent history is visible in its architecture and monuments, providing a fascinating backdrop for academic studies, particularly in fields like history, politics, and cultural studies.'),
        (humboldt_id, 'How does the German university system work at Humboldt?', 'Humboldt follows the German university system, which offers considerable academic freedom and self-directed learning. Most programs use the European Credit Transfer System (ECTS), with Bachelor''s programs typically requiring 180 ECTS points (6 semesters) and Master''s programs 120 ECTS points (4 semesters). The academic year is divided into winter semester (October-March) and summer semester (April-September), each with a lecture period and a lecture-free period for exams and independent study. German universities emphasize self-organization - students often create their own study schedules within program requirements. Classes typically include lectures (Vorlesungen), seminars (Seminare), and practical exercises (Übungen). Assessment may involve written exams, oral exams, presentations, papers, or project work, depending on the discipline. Grading uses a 1-5 scale, with 1 being the best and 4 the minimum passing grade. The system emphasizes critical thinking and independent research over memorization or standardized testing.'),
        (humboldt_id, 'What research opportunities are available at Humboldt University?', 'Humboldt University offers extensive research opportunities across all academic levels. The university has several excellence clusters and collaborative research centers, including the Integrative Research Institute for the Sciences (IRIS Adlershof) and the Interdisciplinary Laboratory Image Knowledge Gestaltung. For Bachelor''s students, research opportunities include participation in research projects through seminars or thesis work. Master''s students often engage in research through advanced seminars, independent projects, and thesis research. The university''s Student Research Opportunities Program (StuROPP) specifically connects undergraduate students with faculty research projects. Humboldt also maintains close collaborations with numerous non-university research institutions in Berlin, including Charité - Universitätsmedizin Berlin (medical school shared with Free University), Max Planck Institutes, Leibniz Institutes, and other research centers, creating a rich ecosystem for interdisciplinary research and innovation.'),
        (humboldt_id, 'How difficult is it to get into Humboldt University as an international student?', 'Admission competitiveness varies significantly by program. Some programs have restricted admission (Numerus Clausus) based on grade point average and waiting semesters, making them more competitive. Popular subjects like psychology, law, and business administration typically have higher grade requirements. For international students, admission involves additional requirements including having foreign educational qualifications recognized as equivalent to the German Abitur (through uni-assist) and demonstrating sufficient language proficiency. German-taught programs generally require strong German language skills (typically C1 level), which can be a significant hurdle for non-native speakers. English-taught programs (primarily at the Master''s level) are more accessible for international students but may have more specific academic prerequisites. The university''s International Office provides guidance for international applicants, but the process requires careful planning, especially regarding documentation and deadlines. For particularly competitive programs, even qualified applicants may need to apply multiple times before securing admission.');
        
        -- Delete any existing testimonials for Humboldt University of Berlin
        DELETE FROM testimonials 
        WHERE university_id = humboldt_id;
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (humboldt_id, 'Sophia Müller', 'https://randomuser.me/api/portraits/women/62.jpg', 'Studying Cultural Studies at Humboldt University has been an intellectually transformative experience. The program''s interdisciplinary approach encourages us to think across traditional academic boundaries, which perfectly mirrors Berlin''s dynamic cultural landscape. What makes Humboldt special is how it combines academic tradition with progressive thinking - our seminars might take place in a historic building, but the discussions are cutting-edge. Professors are incredibly knowledgeable and approachable, always willing to engage with students'' ideas. Berlin itself is the perfect classroom, with its museums, theaters, and cultural spaces offering countless opportunities to apply theoretical concepts to real-world contexts. The international atmosphere means I''ve made friends from around the world, enriching discussions with diverse perspectives. While the academic freedom of the German university system was challenging to adjust to initially, it has ultimately taught me valuable skills in self-organization and independent research.', 5, true);
    END IF;
END $$; 
-- Find the Nanyang Technological University university ID (assuming it already exists)
DO $$
DECLARE
    ntu_id uuid;
BEGIN
    -- Get the ID of Nanyang Technological University
    SELECT id INTO ntu_id FROM universities WHERE name = 'Nanyang Technological University';
    
    -- If Nanyang Technological University doesn't exist, we don't update anything
    IF ntu_id IS NOT NULL THEN
        -- Update Nanyang Technological University with enhanced data
        UPDATE universities
        SET 
            founding_year = 1991,
            campus_image_url = 'https://images.unsplash.com/photo-1583748386787-c976c3c3d05f?q=80&w=1200',
            student_population = 33000,
            international_student_percentage = 25,
            ranking_the = 36,
            ranking_arwu = 104,
            tuition_fee_domestic = 'SGD 9,250 - SGD 11,200 per year (subsidized for Singaporeans)',
            tuition_fee_international = 'SGD 17,450 - SGD 38,450 per year',
            application_fee = 'SGD 20 - SGD 100',
            other_fees = 'Student services and amenities fee: SGD 300 per year',
            health_insurance = 'Mandatory health insurance: Approximately SGD 250 per year',
            living_expense_accommodation = 'SGD 3,600 - SGD 9,000 per year',
            living_expense_food = 'SGD 3,600 - SGD 6,000 per year',
            living_expense_transportation = 'SGD 1,000 - SGD 1,500 per year',
            living_expense_other = 'SGD 2,000 - SGD 3,000 per year',
            housing_info = 'NTU offers guaranteed accommodation for international freshmen in one of its 24 residence halls on campus. Each hall has its own unique culture and offers various room types from single to quad sharing. Halls provide amenities like lounges, kitchenettes, laundry facilities, and recreational areas. After the first year, students can continue to stay in halls based on availability or move to off-campus housing with assistance from the NTU Off-Campus Housing Office.',
            campus_facilities = ARRAY['The Hive (Learning Hub)', 'Libraries', 'Research Centers', 'Sports Facilities', 'Food Courts', 'Labs', 'Performance Spaces'],
            international_support = 'The International Student Support team provides comprehensive services including pre-arrival guidance, orientation programs, immigration advice, and cultural adjustment activities. The university organizes cultural excursions and integration events throughout the academic year.',
            clubs_info = 'NTU has over 100 student organizations, from academic and cultural groups to sports teams and interest clubs. The Student Union coordinates campus-wide events and represents student interests. Hall associations organize activities for residence hall communities.',
            admission_success_rate = '36%',
            students_placed = 710
        WHERE id = ntu_id;
        
        -- Clear any existing programs for Nanyang Technological University and add new ones
        DELETE FROM university_programs 
        WHERE university_id = ntu_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (ntu_id, 'Computer Science', 'Bachelor', 'Technology', 'English', '4 years', 'A comprehensive program covering software development, artificial intelligence, data science, and computer systems with strong industry partnerships and internship opportunities.', 'SGD 9,250 (Subsidized) / SGD 21,960 (International) per year', 'End of March', true),
        (ntu_id, 'Mechanical Engineering', 'Bachelor', 'Engineering', 'English', '4 years', 'A rigorous program combining mechanical design, thermodynamics, robotics, and manufacturing with research opportunities and industry collaborations.', 'SGD 9,250 (Subsidized) / SGD 19,440 (International) per year', 'End of March', true),
        (ntu_id, 'Nanyang MBA', 'Master', 'Business', 'English', '1 year (full-time) or 2 years (part-time)', 'A globally recognized MBA program with focus on Asian business practices, leadership development, and entrepreneurship, offering international exchange opportunities.', 'SGD 38,450 per year', 'November 15 (Round 1) / January 31 (Round 2) / March 31 (Round 3)', true),
        (ntu_id, 'MSc in Environmental Engineering', 'Master', 'Engineering', 'English', '1 year (full-time) or 2 years (part-time)', 'An interdisciplinary program addressing environmental challenges through engineering solutions, with specializations in water technologies, waste management, and sustainable development.', 'SGD 31,860 per year', 'End of January', false);
        
        -- Clear any existing admission requirements for Nanyang Technological University and add new ones
        DELETE FROM admission_requirements 
        WHERE university_id = ntu_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (ntu_id, 'Academic', 'For Bachelor''s programs: Strong high school qualification equivalent to Singapore-Cambridge GCE ''A'' Levels, International Baccalaureate (IB), or other recognized qualifications. For Master''s programs: Bachelor''s degree with second upper honors (or equivalent) in a relevant field.', 'NTU places significant emphasis on mathematics and science subjects for engineering and science programs. For competitive programs like Computer Science or Business, aim for top grades in relevant subjects. The university also values consistency in academic performance across multiple years rather than just final exams.'),
        (ntu_id, 'Language', 'For English-taught programs: TOEFL (minimum 90 internet-based), IELTS (minimum 6.5 overall, with no sub-score below 6.0), or other approved tests. Exemptions for those from English-speaking countries or institutions.', 'While meeting minimum language requirements is sufficient for admission, stronger English proficiency will benefit your academic performance and social integration. Consider taking academic writing courses in addition to general English preparation, as NTU programs heavily emphasize written assignments and reports.'),
        (ntu_id, 'Documents', 'Online application, academic transcripts and certificates, personal statement, CV, recommendation letters (for graduate applicants), portfolio (for Art, Design & Media program).', 'In your personal statement, demonstrate how your experiences align with Singapore''s emphasis on innovation and future-oriented thinking. NTU values students who can articulate how they will contribute to both the university community and Singapore''s development goals.'),
        (ntu_id, 'Additional Requirements', 'Some programs require interviews (in person or online). Scholarships typically require additional essays and interviews. Graduate programs may require GRE or GMAT scores.', 'For programs requiring interviews, prepare to discuss not only your academic interests but also your understanding of Singapore''s unique position in the global economy. Showing knowledge of NTU''s research strengths and how they align with your goals can significantly strengthen your application. For creative programs, portfolios should demonstrate both technical skills and conceptual thinking.');
        
        -- Clear any existing scholarships for Nanyang Technological University and add new ones
        DELETE FROM scholarships 
        WHERE university_id = ntu_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (ntu_id, 'ASEAN Undergraduate Scholarship', 'University', 'Full tuition plus SGD 5,800 annual living allowance, SGD 2,000 settling-in allowance, and travel grant', 'Prestigious scholarships for outstanding students from ASEAN countries to pursue undergraduate studies at NTU.', 'Citizens of ASEAN countries (except Singapore) with excellent academic achievements and strong co-curricular activities record.', 'Apply through the NTU online application portal with supporting documents and scholarship essay.', 'Same as admission application', '10%'),
        (ntu_id, 'Nanyang President''s Graduate Scholarship', 'University', 'Full tuition plus monthly stipend of SGD 3,000, conference funding, and research allowance', 'Elite scholarships for exceptional students pursuing PhD studies at NTU.', 'Excellent academic record (top 5% of cohort), strong research proposal, and endorsement from potential NTU supervisor.', 'Apply through the NTU graduate admissions portal with research proposal and recommendation letters.', 'January 31', '5%'),
        (ntu_id, 'Singapore International Graduate Award (SINGA)', 'A*STAR, NTU, NUS, SUTD', 'Full tuition plus monthly stipend of SGD 2,000, one-time settling-in allowance of SGD 1,000, and airfare grant', 'Joint scholarship offered by Singapore''s top research institutions for international students to pursue PhD studies in science and engineering.', 'International students (non-Singaporean/non-PR) with excellent academic record and research potential.', 'Apply through the SINGA online application portal with research proposal and supporting documents.', 'June 1 (December intake) / December 1 (August intake)', '15%');
        
        -- Clear any existing FAQs for Nanyang Technological University and add new ones
        DELETE FROM university_faqs 
        WHERE university_id = ntu_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (ntu_id, 'What is NTU known for?', 'Nanyang Technological University (NTU) is one of Asia''s top universities, particularly renowned for engineering, business, and science programs. Established in 1991, NTU has quickly risen in global rankings and is known for its innovative campus architecture, most notably The Hive (a learning hub with distinctive honeycomb-like structures). The university has strong research capabilities in areas like artificial intelligence, biomedical engineering, clean energy, and autonomous vehicles. NTU has partnerships with leading global companies, including Rolls-Royce, BMW, and Alibaba, providing students with industry exposure. The university is also recognized for its sustainability initiatives, with multiple Green Mark Platinum buildings on campus and a commitment to carbon neutrality.'),
        (ntu_id, 'What is student life like in Singapore?', 'Singapore offers a unique student experience combining Asian and Western influences in a safe, clean, and technologically advanced environment. The city-state is known for its efficient public transportation, making it easy to explore. NTU''s campus is one of the largest and most beautiful in Singapore, with modern facilities amidst lush greenery. The campus has a vibrant residential life with 24 halls of residence, each with its own culture and traditions. Singapore''s tropical climate means warm weather year-round, though most buildings are air-conditioned. The food scene is exceptional, with affordable options at campus canteens and hawker centers throughout the city. Singapore''s strategic location makes it an excellent base for traveling throughout Southeast Asia. While the cost of living is higher than in neighboring countries, it remains more affordable than many Western cities. Singapore''s multicultural environment reflects its Chinese, Malay, Indian, and Western influences, creating a rich cultural landscape.'),
        (ntu_id, 'How does the Singapore education system work?', 'Singapore''s higher education system is modeled primarily after the British system, with some American influences. Most bachelor''s programs take 3-4 years to complete, while master''s programs typically range from 1-2 years. The academic year usually begins in August and consists of two semesters. Universities in Singapore use a combination of continuous assessment and final examinations, with grades typically assigned on a 5.0 GPA scale or using letter grades. Singapore places strong emphasis on STEM education (Science, Technology, Engineering, and Mathematics), though humanities and arts programs are also available. The government heavily subsidizes education for Singaporean citizens, with international students paying higher fees but still benefiting from high-quality education at a cost lower than many Western countries. Instruction is conducted in English across all universities in Singapore, making it accessible to international students. The education system emphasizes practical skills and industry relevance, with many programs incorporating internships or industrial attachments.'),
        (ntu_id, 'What research opportunities are available at NTU?', 'NTU offers extensive research opportunities across all academic levels. The university has over 50 research centers and institutes, including the Earth Observatory of Singapore, the Singapore Centre for Environmental Life Sciences Engineering, and the Centre for Advanced Biomedical Imaging. Undergraduate students can participate in the Undergraduate Research Experience on Campus (URECA) program, allowing them to work on research projects under faculty supervision. The university''s Interdisciplinary Graduate Program allows PhD students to work across traditional disciplinary boundaries. NTU''s close ties with industry partners create opportunities for applied research with real-world impact. The university is part of Singapore''s Research, Innovation and Enterprise 2025 Plan, with significant government funding supporting research in areas like healthcare, sustainability, and digital technologies. NTU also maintains research collaborations with top global universities and research institutions, providing international research exposure.'),
        (ntu_id, 'What career opportunities are available after graduating from NTU?', 'NTU graduates enjoy excellent employment prospects, with over 90% securing employment within six months of graduation. The Career & Attachment Office provides comprehensive support including career counseling, resume workshops, mock interviews, and career fairs featuring local and multinational employers. Many programs include mandatory or optional internships, building valuable industry experience before graduation. Singapore''s strategic position as a business hub for Asia Pacific offers opportunities with multinational corporations across various sectors. For international students, Singapore offers favorable post-graduation work opportunities through the Employment Pass system. The NTU alumni network spans over 200,000 graduates worldwide, providing networking opportunities across various industries. The university''s strong industry partnerships often lead to direct recruitment pathways with companies like Micron, Rolls-Royce, and Alibaba. NTU''s entrepreneurship programs and incubators support students interested in startups and innovation.');
        
        -- Delete any existing testimonials for Nanyang Technological University
        DELETE FROM testimonials 
        WHERE university_id = ntu_id;
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (ntu_id, 'Miguel Sanchez', 'https://randomuser.me/api/portraits/men/72.jpg', 'My experience studying Mechanical Engineering at NTU has been transformative. The curriculum perfectly balances theoretical knowledge with hands-on experience in world-class labs and facilities. What impressed me most is how forward-looking the program is—we''re constantly engaging with emerging technologies like additive manufacturing and robotics. The professors are not only leading researchers but also accessible mentors who genuinely care about student success. Living on campus in the residence halls has been a highlight, allowing me to immerse myself in Singapore''s unique multicultural environment and form friendships with students from across Asia and beyond. The university''s strong connections with industry have given me valuable internship opportunities and a clear path to employment after graduation. Singapore itself has been an incredible place to study—safe, efficient, and offering the perfect blend of cutting-edge modernity and rich cultural traditions.', 5, true);
    END IF;
END $$; 
-- Find the University of British Columbia university ID (assuming it already exists)
DO $$
DECLARE
    ubc_id uuid;
BEGIN
    -- Get the ID of University of British Columbia
    SELECT id INTO ubc_id FROM universities WHERE name = 'University of British Columbia';
    
    -- If University of British Columbia doesn't exist, we don't update anything
    IF ubc_id IS NOT NULL THEN
        -- Update University of British Columbia with enhanced data
        UPDATE universities
        SET 
            founding_year = 1908,
            campus_image_url = 'https://images.unsplash.com/photo-1582543959262-3be3c2163f4c?q=80&w=1200',
            student_population = 66000,
            international_student_percentage = 28,
            ranking_the = 34,
            ranking_arwu = 44,
            tuition_fee_domestic = 'CAD 5,600 - CAD 9,300 per year (Canadian students)',
            tuition_fee_international = 'CAD 41,000 - CAD 58,000 per year',
            application_fee = 'CAD 123.50 (Canadian/PR), CAD 168.25 (International)',
            other_fees = 'Student fees: Approximately CAD 1,000 per year',
            health_insurance = 'BC Medical Services Plan: CAD 75 per month; International students: CAD 252 per year (iMED) for first three months, then MSP',
            living_expense_accommodation = 'CAD 9,000 - CAD 15,000 per year',
            living_expense_food = 'CAD 4,000 - CAD 6,000 per year',
            living_expense_transportation = 'CAD 500 - CAD 1,500 per year',
            living_expense_other = 'CAD 2,000 - CAD 4,000 per year',
            housing_info = 'UBC offers various on-campus housing options across its two campuses in Vancouver and Okanagan. First-year students are guaranteed housing if they apply by the deadline. The Vancouver campus has 12 residence areas with options ranging from traditional dormitories to apartment-style units. The Student Housing Office assists students in finding off-campus housing. Many students live in the University Endowment Lands, Kitsilano, Point Grey, and other neighborhoods near campus. Vancouver has a competitive housing market with relatively high rental costs compared to many other Canadian cities.',
            campus_facilities = ARRAY['Libraries', 'Research Centers', 'Sports Facilities', 'Museums', 'Gardens', 'Student Union Buildings', 'Health Services'],
            international_support = 'The International Student Development office provides comprehensive services including pre-arrival support, orientation programs, immigration advising, and cultural integration activities. UBC offers workshops on topics like cultural adjustment, work permits, and career development for international students.',
            clubs_info = 'UBC has over 350 student clubs and organizations spanning academic, cultural, recreational, and social interests. The Alma Mater Society (AMS) is the student union that organizes campus-wide events and runs student services. The AMS Student Nest serves as a hub for student life with dining, social, and study spaces.',
            admission_success_rate = '58%',
            students_placed = 890
        WHERE id = ubc_id;
        
        -- Clear any existing programs for University of British Columbia and add new ones
        DELETE FROM university_programs 
        WHERE university_id = ubc_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (ubc_id, 'Computer Science', 'Bachelor', 'Technology', 'English', '4 years', 'A comprehensive program covering algorithms, software development, machine learning, and computer systems with co-op options providing valuable industry experience.', 'CAD 5,600 (Canadian) / CAD 45,000 (International) per year', 'January 15', true),
        (ubc_id, 'Commerce', 'Bachelor', 'Business', 'English', '4 years', 'The Sauder School of Business program offering specializations in areas like finance, marketing, and entrepreneurship with a global focus and professional development opportunities.', 'CAD 8,300 (Canadian) / CAD 52,000 (International) per year', 'January 15', true),
        (ubc_id, 'Master of Data Science', 'Master', 'Technology', 'English', '10-12 months', 'An intensive program developing expertise in data analysis, machine learning, and visualization with emphasis on applying these skills to solve complex real-world problems.', 'CAD 11,250 (Canadian) / CAD 40,000 (International) per year', 'December 1', true),
        (ubc_id, 'Environmental Sciences', 'Bachelor', 'Science', 'English', '4 years', 'An interdisciplinary program examining environmental systems, sustainability, and conservation with field courses, research opportunities, and international exchange options.', 'CAD 5,600 (Canadian) / CAD 43,500 (International) per year', 'January 15', false);
        
        -- Clear any existing admission requirements for University of British Columbia and add new ones
        DELETE FROM admission_requirements 
        WHERE university_id = ubc_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (ubc_id, 'Academic', 'For Bachelor''s programs: Secondary school graduation with specific subject requirements depending on the program. For Master''s programs: Bachelor''s degree with a B+ average (76% at UBC or equivalent) in third and fourth-year courses.', 'UBC weighs academic performance most heavily, but evaluates applications holistically. For competitive programs like Commerce, Engineering, and Computer Science, aim for grades significantly above the minimum requirements. The university values consistency in academic performance across all relevant subjects rather than excellence in just one or two areas.'),
        (ubc_id, 'Language', 'For all programs: TOEFL (minimum 90 with no part less than 22), IELTS (minimum 6.5 with no part less than 6.0), or other accepted English proficiency tests. Some programs may have higher requirements.', 'While meeting minimum language requirements is sufficient for admission, stronger English proficiency will significantly benefit your academic performance, particularly in writing-intensive programs. UBC''s academic English support programs can help bridge any gaps after admission, but starting with strong skills will give you an advantage in your coursework.'),
        (ubc_id, 'Documents', 'Online application, academic transcripts, personal profile (for undergraduate programs), statement of interest and CV (for graduate programs), and letters of recommendation (for graduate programs).', 'The personal profile is a critical component of UBC''s undergraduate application that evaluates non-academic qualities. Focus on demonstrating leadership, community engagement, and personal growth through specific examples rather than general statements. For graduate applications, tailor your statement to specific faculty members'' research that aligns with your interests.'),
        (ubc_id, 'Additional Requirements', 'Some programs have supplementary applications, portfolios, auditions, or interviews. Competitive programs may have additional academic requirements.', 'For highly competitive programs like Commerce, the supplementary application is often the deciding factor among academically qualified candidates. Prepare thoroughly for these additional requirements by researching the specific values and qualities each program seeks. For creative programs requiring portfolios, demonstrate both technical skill and creative thinking.');
        
        -- Clear any existing scholarships for University of British Columbia and add new ones
        DELETE FROM scholarships 
        WHERE university_id = ubc_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (ubc_id, 'International Major Entrance Scholarship', 'University', 'CAD 5,000 - CAD 40,000 (over four years)', 'Prestigious scholarships for outstanding international students based on academic achievement, leadership, and community involvement.', 'International undergraduate applicants with exceptional academic achievement and demonstrated leadership in school and community.', 'Automatically considered when applying for admission by the deadline.', 'January 15', '5%'),
        (ubc_id, 'Outstanding International Student Award', 'University', 'CAD 5,000 - CAD 10,000 (one-time award)', 'Merit-based entrance scholarships for international undergraduate students.', 'International undergraduate applicants with strong academic records.', 'Automatically considered when applying for admission.', 'January 15', '15%'),
        (ubc_id, 'Four Year Doctoral Fellowship', 'University', 'CAD 18,200 per year plus tuition for up to four years', 'UBC''s premier doctoral recruitment package for exceptional PhD students.', 'Incoming PhD students with outstanding academic records and research potential.', 'Nominated by the graduate program; no separate application required.', 'Same as program application', '25%');
        
        -- Clear any existing FAQs for University of British Columbia and add new ones
        DELETE FROM university_faqs 
        WHERE university_id = ubc_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (ubc_id, 'What is UBC known for?', 'The University of British Columbia is consistently ranked among the top 40 universities globally and is particularly renowned for its research in forestry, sustainable development, oceanography, and computer science. UBC has produced 8 Nobel laureates, 71 Rhodes Scholars, and 3 Canadian prime ministers. The university is recognized for its strong commitment to sustainability and was the first Canadian university to adopt a comprehensive sustainability strategy. UBC''s Vancouver campus is renowned for its stunning location between the Pacific Ocean and the Coast Mountains, offering exceptional natural beauty with beaches, forests, and mountain views. The university emphasizes interdisciplinary learning and research, with many programs crossing traditional academic boundaries. UBC is known for its diverse international community, with students from 150+ countries creating a global learning environment. The institution maintains strong connections with industry, particularly in technology, biotechnology, and natural resources sectors, providing excellent career opportunities for graduates.'),
        (ubc_id, 'What is student life like at UBC and in Vancouver?', 'UBC offers a vibrant and diverse student experience across its two campuses. The Vancouver campus spans over 400 hectares at the western tip of the Point Grey Peninsula, surrounded by forest and ocean. This creates a unique environment where students can enjoy outdoor activities like hiking, skiing, and beach volleyball alongside their studies. Vancouver consistently ranks among the world''s most livable cities, known for its outdoor lifestyle, cultural diversity, and mild climate (though it''s famously rainy in winter). The city offers excellent public transportation, making it easy to explore Vancouver''s distinct neighborhoods, each with its own character and attractions. UBC has a strong athletics tradition with the UBC Thunderbirds competing in various varsity sports. Campus recreation programs offer activities from fitness classes to intramural leagues. The university hosts numerous events throughout the year, including Arts & Culture District performances, public lectures, and seasonal celebrations. Vancouver''s diverse population is reflected in its exceptional food scene, with cuisines from around the world available both on campus and throughout the city. The cost of living is relatively high, particularly for housing, though still lower than cities like Toronto or international hubs like London and San Francisco.'),
        (ubc_id, 'What co-op and work opportunities are available at UBC?', 'UBC offers extensive co-op and work-integrated learning opportunities across many disciplines. The co-op program allows students to alternate academic terms with paid work terms, gaining relevant professional experience while earning their degree. Co-op is available in fields including engineering, business, science, arts, and forestry, with placements ranging from 4 to 8 months. Students typically complete 4-5 work terms throughout their degree, with employers including major corporations, government agencies, startups, and research institutions across Canada and internationally. The Work Learn program provides on-campus employment opportunities specifically designed for UBC students, offering positions that complement academic programs. International students can work off-campus up to 20 hours per week during academic terms and full-time during scheduled breaks without requiring a separate work permit. Post-graduation, international students can apply for a Post-Graduation Work Permit, allowing them to stay and work in Canada for up to three years. The Centre for Student Involvement & Careers provides comprehensive career support including counseling, workshops, job fairs, and networking events. Vancouver''s diverse economy, with strengths in sectors like technology, film production, sustainable development, and healthcare, offers numerous internship and employment opportunities for students.'),
        (ubc_id, 'What makes UBC''s Vancouver and Okanagan campuses different?', 'UBC operates two distinct campuses that offer different experiences while maintaining the same academic standards. The Vancouver campus is UBC''s original and largest campus, located in a spectacular setting at the western tip of Point Grey Peninsula. With over 55,000 students, it offers the full range of UBC''s programs and has a comprehensive research infrastructure, including Canada''s national laboratory for particle physics (TRIUMF). The urban-adjacent setting provides access to Vancouver''s cultural amenities while maintaining a separate campus feel. The Okanagan campus in Kelowna was established in 2005 and has grown to around 11,000 students. It offers a more intimate learning environment with smaller class sizes and closer faculty interaction. The Okanagan region provides a drier, sunnier climate than Vancouver and is famous for its wineries, orchards, and outdoor recreation opportunities like skiing and lake activities. The Okanagan campus has developed its own distinct research strengths in areas like healthy living, sustainability, and wine research. Students receive the same UBC degree regardless of which campus they attend, but the learning environment, available programs, and lifestyle differ significantly between the two locations.'),
        (ubc_id, 'What research opportunities are available for UBC students?', 'UBC offers extensive research opportunities for students at all levels, reflecting its status as one of Canada''s premier research universities. Undergraduate students can participate through the Work Learn Research Program, which provides paid research assistantships under faculty supervision. The Undergraduate Research Opportunities program connects students with faculty-led projects across disciplines. Many departments offer dedicated research courses or honors programs with significant research components. The NSERC Undergraduate Student Research Awards provide funding for summer research positions in natural sciences and engineering. Graduate students have access to state-of-the-art research facilities across four major campuses: the Vancouver campus, Okanagan campus, Vancouver General Hospital, and Great Northern Way Campus. UBC has over 300 research centers and facilities, including the Peter Wall Institute for Advanced Studies, the Stewart Blusson Quantum Matter Institute, and the Centre for Blood Research. The university secures approximately CAD 600 million in research funding annually, supporting projects across diverse fields from medicine to sustainable development. UBC encourages interdisciplinary research through initiatives like the Data Science Institute, which bridges computer science, statistics, and domain-specific research. The university maintains research partnerships with industry, government, indigenous communities, and international institutions, providing diverse opportunities for applied and collaborative research.');
        
        -- Delete any existing testimonials for University of British Columbia
        DELETE FROM testimonials 
        WHERE university_id = ubc_id;
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (ubc_id, 'Ananya Patel', 'https://randomuser.me/api/portraits/women/71.jpg', 'Studying Environmental Sciences at UBC has been transformative both academically and personally. The program''s interdisciplinary approach has given me a comprehensive understanding of environmental challenges while allowing me to specialize in marine conservation. What makes UBC special is the perfect balance between rigorous academics and incredible quality of life. The campus setting between mountains and ocean is simply breathtaking - I can go from a morning lecture to an afternoon hike or beach volleyball session in minutes. The professors bring cutting-edge research into the classroom, and I''ve had opportunities to participate in field studies on Vancouver Island and even an exchange semester in Australia. The diverse student community has broadened my perspectives, with classmates from across Canada and around the world sharing their unique insights. Vancouver''s commitment to sustainability aligns perfectly with my studies, providing a living laboratory to observe environmental policies in action. While Vancouver''s housing costs can be challenging, the experience of studying at a world-class institution in one of the most beautiful settings imaginable has been absolutely worth it.', 5, true);
    END IF;
END $$; 
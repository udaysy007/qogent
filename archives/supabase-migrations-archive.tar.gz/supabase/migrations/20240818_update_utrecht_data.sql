-- Find the Utrecht University university ID (assuming it already exists)
DO $$
DECLARE
    utrecht_id uuid;
BEGIN
    -- Get the ID of Utrecht University
    SELECT id INTO utrecht_id FROM universities WHERE name = 'Utrecht University';
    
    -- If Utrecht University doesn't exist, we don't update anything
    IF utrecht_id IS NOT NULL THEN
        -- Update Utrecht University with enhanced data
        UPDATE universities
        SET 
            founding_year = 1636,
            campus_image_url = 'https://images.unsplash.com/photo-1599032509357-478363997acc?q=80&w=1200',
            student_population = 36000,
            international_student_percentage = 13,
            ranking_the = 75,
            ranking_arwu = 53,
            tuition_fee_domestic = '€2,209 per year (EU/EEA students)',
            tuition_fee_international = '€11,000 - €20,000 per year',
            application_fee = '€100',
            other_fees = 'Variable by program',
            health_insurance = 'EU students: European Health Insurance Card; Non-EU: Approximately €550 per year',
            living_expense_accommodation = '€400 - €800 per month',
            living_expense_food = '€200 - €400 per month',
            living_expense_transportation = '€40 - €100 per month',
            living_expense_other = '€150 - €250 per month',
            housing_info = 'Utrecht University does not provide student housing directly but works with SSH Short Stay to offer accommodation for international students. The university guarantees housing for international students in specific programs who apply before the deadline. Most student accommodations are located in the city center or near the Utrecht Science Park (De Uithof) campus. The housing market in Utrecht is competitive, with private accommodations typically costing €400-€800 per month depending on location and type of housing. The university''s housing office provides guidance for students seeking private housing options.',
            campus_facilities = ARRAY['Libraries', 'Research Institutes', 'Sports Centers', 'Student Centers', 'Restaurants', 'Botanical Gardens', 'Museums'],
            international_support = 'The International Office provides comprehensive support for international students, including pre-arrival information, orientation programs, visa and residence permit assistance, and cultural integration activities. Utrecht University offers Dutch language courses and buddy programs to help international students adapt to life in the Netherlands.',
            clubs_info = 'Utrecht University has numerous student organizations covering academic, cultural, sports, and social interests. Study associations are tied to specific academic programs, while student associations focus on social and cultural activities. Parnassos Cultural Centre offers courses and workshops in arts, music, and theater.',
            admission_success_rate = '55%',
            students_placed = 740
        WHERE id = utrecht_id;
        
        -- Clear any existing programs for Utrecht University and add new ones
        DELETE FROM university_programs 
        WHERE university_id = utrecht_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (utrecht_id, 'Artificial Intelligence', 'Master', 'Technology', 'English', '2 years', 'A comprehensive program combining computer science, cognitive science, and logic to develop intelligent systems with applications in various domains from robotics to data science.', '€2,209 (EU) / €18,690 (Non-EU) per year', 'February 1', true),
        (utrecht_id, 'Liberal Arts and Sciences', 'Bachelor', 'Interdisciplinary', 'English', '3 years', 'An interdisciplinary program at Utrecht University College allowing students to design their own curriculum across humanities, science, and social sciences with small-scale, intensive teaching methods.', '€4,630 (EU) / €13,084 (Non-EU) per year', 'January 15', true),
        (utrecht_id, 'Climate Physics', 'Master', 'Science', 'English', '2 years', 'A specialized program focusing on the physics of climate systems, climate modeling, and atmosphere-ocean interactions with emphasis on current climate change research.', '€2,209 (EU) / €20,012 (Non-EU) per year', 'April 1', true),
        (utrecht_id, 'Global Criminology', 'Master', 'Social Sciences', 'English', '1 year', 'An innovative program examining transnational crime, security issues, and criminal justice systems from a global perspective with fieldwork opportunities and internship possibilities.', '€2,209 (EU) / €17,500 (Non-EU) per year', 'April 1', false);
        
        -- Clear any existing admission requirements for Utrecht University and add new ones
        DELETE FROM admission_requirements 
        WHERE university_id = utrecht_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (utrecht_id, 'Academic', 'For Bachelor''s programs: Secondary school diploma equivalent to Dutch VWO diploma with specific subject requirements. For Master''s programs: Bachelor''s degree in a relevant field, often with specific GPA requirements (typically 3.0/4.0 or equivalent).', 'Utrecht University evaluates international qualifications within the context of their national system. For competitive master''s programs, having a bachelor''s GPA significantly above the minimum (ideally in the top 25% of your class) will strengthen your application. The university also values relevant research experience or thesis work in your bachelor''s studies, particularly for research-intensive master''s programs.'),
        (utrecht_id, 'Language', 'For English-taught programs: IELTS (minimum 6.5 overall, with at least 6.0 in each component) or TOEFL (minimum 93 internet-based) depending on the program. Cambridge C1 Advanced or C2 Proficiency certificates also accepted.', 'While the Netherlands is very English-friendly, having some Dutch language skills will enrich your social experience and improve employment prospects if you plan to stay after graduation. Utrecht University offers Dutch language courses at various levels through Babel Language Institute, which many international students find valuable for cultural integration.'),
        (utrecht_id, 'Documents', 'Online application, academic transcripts, CV, motivation letter, research proposal (for research Master''s), and letters of recommendation.', 'The motivation letter is particularly important for Utrecht University applications. Beyond simply explaining why you want to study there, they look for clear connections between your academic background, future goals, and the specific program structure. Reference specific courses, research groups, or faculty members that align with your interests to demonstrate you''ve thoroughly researched the program.'),
        (utrecht_id, 'Additional Requirements', 'Some programs require interviews, writing samples, or additional tests. University College Utrecht (Liberal Arts and Sciences) has a selective admission process requiring supplementary materials and often an interview.', 'For selective programs like University College Utrecht, the interview process evaluates not just academic potential but also how you''ll contribute to the residential college community. Prepare to discuss not only academic interests but also extracurricular activities, community involvement, and how you handle collaborative environments.');
        
        -- Clear any existing scholarships for Utrecht University and add new ones
        DELETE FROM scholarships 
        WHERE university_id = utrecht_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (utrecht_id, 'Utrecht Excellence Scholarship', 'University', '€5,000 - €25,000 per year', 'Merit-based scholarships for outstanding international students in Master''s programs.', 'Non-EU/EEA students with excellent academic achievement (top 10% of class) applying to specific Master''s programs.', 'Apply through the scholarship application portal after being admitted to a Master''s program.', 'February 1', '10%'),
        (utrecht_id, 'Holland Scholarship', 'Dutch Ministry of Education and Utrecht University', '€5,000 (one-time payment)', 'Scholarships for non-EEA international students studying Bachelor''s or Master''s programs in the Netherlands.', 'Non-EU/EEA students with excellent academic records applying for their first year of study at Utrecht University.', 'Apply through the Holland Scholarship application portal after applying to a degree program.', 'February 1', '15%'),
        (utrecht_id, 'Orange Tulip Scholarship', 'Nuffic Neso offices and Dutch institutions', 'Varies (partial to full funding)', 'Country-specific scholarships for students from Brazil, China, India, Indonesia, Korea, Mexico, Russia, South Africa, and Vietnam.', 'Students from eligible countries with strong academic records applying to specific programs.', 'Apply through the Nuffic Neso office in your country.', 'Varies by country (typically April-May)', '20%');
        
        -- Clear any existing FAQs for Utrecht University and add new ones
        DELETE FROM university_faqs 
        WHERE university_id = utrecht_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (utrecht_id, 'What is Utrecht University known for?', 'Utrecht University, founded in 1636, is one of the oldest and most prestigious universities in the Netherlands and consistently ranks among Europe''s top universities. It''s particularly renowned for its research and education in sustainability, life sciences, earth sciences, governance, and culture. The university is known for its innovative research in climate change, dynamics of youth, institutions for open societies, and regenerative medicine. Utrecht University follows a distinctive educational model that emphasizes small-scale teaching, interdisciplinary approaches, and close connections between education and research. The university has a beautiful mix of historic buildings in the city center and modern facilities at the Utrecht Science Park campus. With over 30,000 students from more than 120 countries, it offers a truly international academic environment. Utrecht University is deeply embedded in the vibrant student city of Utrecht, which combines medieval charm with contemporary Dutch culture.'),
        (utrecht_id, 'What is student life like in Utrecht?', 'Utrecht offers one of the most authentic Dutch student experiences in a city that perfectly balances historic charm with a youthful, dynamic atmosphere. As one of the Netherlands'' oldest cities, Utrecht features picturesque canals, medieval architecture, and the iconic Dom Tower at its center. With approximately 70,000 students (about 20% of the population), Utrecht has a genuine student vibe with numerous cafes, restaurants, cultural venues, and events catering to young people. The city is extremely bike-friendly, with most locations accessible within 15-20 minutes by bicycle. Housing is more affordable than in Amsterdam, though still competitive. The historic center offers charming cafes along wharfside terraces unique to Utrecht, while areas like Lombok and Wittevrouwen provide more residential student neighborhoods. Utrecht''s central location in the Netherlands makes it ideal for exploring the country, with Amsterdam just 25 minutes away by train. Student associations play a significant role in social life, organizing parties, cultural events, sports activities, and networking opportunities. The city hosts numerous festivals throughout the year, including the Netherlands Film Festival, SPRING Performing Arts Festival, and Cultural Sundays with free performances and exhibitions.'),
        (utrecht_id, 'How does the Dutch university system work?', 'The Dutch higher education system distinguishes between research universities (like Utrecht University) offering research-oriented programs and universities of applied sciences focusing on professional education. Most bachelor''s programs take three years to complete, while master''s programs range from one to two years depending on the field. The academic year typically runs from September to June, divided into two semesters with four blocks of courses. Dutch universities use a 10-point grading scale, with 10 being the highest and 5.5 the minimum passing grade. The system emphasizes independent learning and critical thinking, with less classroom hours than many other countries but more self-study and group work. Teaching methods include interactive seminars, tutorials, research projects, and internships, with a strong emphasis on student participation. Most programs use the European Credit Transfer System (ECTS), with each year consisting of 60 ECTS credits. Utrecht University offers relatively affordable tuition for EU students (around €2,200 per year), while non-EU students pay higher tuition fees that still compare favorably with those in the UK or US. The bachelor-master structure follows the Bologna process, making degrees internationally recognized and compatible with other European systems.'),
        (utrecht_id, 'What research opportunities are available at Utrecht University?', 'Utrecht University offers extensive research opportunities across all academic levels, reflecting its status as one of Europe''s top research universities. For bachelor''s students, many programs include research components, particularly in the final year thesis project. The university operates an Undergraduate Research Fellowship program that pairs undergraduates with research groups for hands-on experience. Honours programs offer additional research opportunities for high-achieving undergraduates. Master''s programs typically have strong research orientations, with many structured as "research master''s" specifically preparing students for academic careers. The university hosts 11 research institutes and numerous research groups focusing on areas like sustainability, life sciences, governance, and cultural dynamics. Utrecht University has exceptional research facilities, including the Botanic Gardens, the Virtual Reality Lab, the Westerdijk Fungal Biodiversity Institute, and various high-tech laboratories. The university actively participates in European research networks and receives significant funding from national and EU sources, creating opportunities for students to join larger research initiatives. The university encourages interdisciplinary research through platforms like the Utrecht Sustainability Institute, which brings together researchers from different fields to address complex societal challenges.'),
        (utrecht_id, 'What career services does Utrecht University offer?', 'Utrecht University provides comprehensive career support through its Career Services center, helping students transition successfully to the job market. Services include individual career counseling with dedicated advisors for each faculty, helping students explore career paths and develop personalized job search strategies. The center offers regular workshops on topics such as CV writing, interview skills, LinkedIn optimization, and personal branding, with both general sessions and faculty-specific training. Career events include employer presentations, alumni panels, and career days where students can connect with potential employers from various sectors. The university maintains strong connections with employers through partnerships and research collaborations, creating internship and job opportunities. The Utrecht University Career Platform lists job vacancies, internships, and volunteer positions specifically targeting Utrecht students and graduates. For international students, specialized support includes workshops on the Dutch job market, work permit regulations, and cultural aspects of job searching in the Netherlands. Many academic programs incorporate career orientation components, including guest lectures from professionals and company visits. The university''s extensive alumni network provides mentoring opportunities and professional connections across various fields worldwide.');
        
        -- Delete any existing testimonials for Utrecht University
        DELETE FROM testimonials 
        WHERE university_id = utrecht_id;
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (utrecht_id, 'Emma Johansson', 'https://randomuser.me/api/portraits/women/12.jpg', 'Studying Artificial Intelligence at Utrecht University has been an incredible intellectual journey that exceeded my expectations. The program perfectly balances theoretical foundations with practical applications, providing both the depth and breadth needed in this rapidly evolving field. What makes Utrecht special is the close interaction with professors who are leading researchers in their specialties - they''re approachable and genuinely interested in student development. The university''s research facilities are outstanding, and I''ve had opportunities to work on projects using cutting-edge technology that wouldn''t be accessible elsewhere. Beyond academics, Utrecht is the perfect student city - beautiful, vibrant, and distinctly Dutch without being overwhelmed by tourism. Cycling along the canals to classes never gets old! The international student community is welcoming and diverse, creating a rich learning environment where different perspectives enhance discussions. While finding housing was initially challenging, the university''s housing office provided valuable guidance. The Dutch directness took some adjustment, but I''ve come to appreciate the straightforward communication style that permeates both academic and social life here.', 5, true);
    END IF;
END $$; 
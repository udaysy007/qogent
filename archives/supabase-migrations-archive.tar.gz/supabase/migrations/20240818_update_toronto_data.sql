-- Find the University of Toronto ID (assuming it already exists)
DO $$
DECLARE
    university_id uuid;
BEGIN
    -- Get the ID of University of Toronto
    SELECT id INTO university_id FROM universities WHERE name = 'University of Toronto';
    
    -- If University of Toronto doesn't exist, we don't update anything
    IF university_id IS NOT NULL THEN
        -- Update University of Toronto with enhanced data
        UPDATE universities
        SET 
            founding_year = 1827,
            campus_image_url = 'https://images.unsplash.com/photo-1569523276592-937acd646484?q=80&w=1200',
            student_population = 93081,
            international_student_percentage = 25,
            ranking_the = 21,
            ranking_arwu = 22,
            tuition_fee_domestic = 'CAD 6,100 - CAD 14,180 per year',
            tuition_fee_international = 'CAD 57,020 - CAD 64,810 per year',
            application_fee = 'CAD 180',
            other_fees = 'Incidental fees: CAD 1,500 - CAD 1,800 per year',
            health_insurance = 'University Health Insurance Plan (UHIP): CAD 720 per year for international students',
            living_expense_accommodation = 'CAD 10,000 - CAD 20,000 per year',
            living_expense_food = 'CAD 4,000 - CAD 6,000 per year',
            living_expense_transportation = 'CAD 1,200 - CAD 1,500 per year',
            living_expense_other = 'CAD 2,000 - CAD 4,000 per year',
            housing_info = 'U of T guarantees housing for first-year students across its three campuses if certain conditions are met. The university has over 30 residences across its three campuses. Options include dormitory-style, apartment-style, and suite-style accommodations.',
            campus_facilities = ARRAY['Libraries', 'Research Centers', 'Athletic Facilities', 'Student Centers', 'Health Services', 'Museums', 'Dining Halls'],
            international_support = 'The Centre for International Experience offers services including immigration advising, transition assistance, intercultural learning, and social events for international students.',
            clubs_info = 'With over 1,000 student organizations across three campuses, U of T offers countless opportunities to get involved, from academic associations to cultural groups, sports teams, and special interest clubs.',
            admission_success_rate = '43%',
            students_placed = 920
        WHERE id = university_id;
        
        -- Clear any existing programs for University of Toronto and add new ones
        DELETE FROM university_programs WHERE university_id = university_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (university_id, 'Computer Science', 'Bachelor', 'Technology', 'English', '4 years', 'Comprehensive program covering algorithms, artificial intelligence, computer systems, and software engineering with opportunities for specialization and research.', 'CAD 6,100 (Domestic) / CAD 59,300 (International) per year', 'January 15', true),
        (university_id, 'Rotman Commerce', 'Bachelor', 'Business', 'English', '4 years', 'Combines economics with management education, offering specializations in accounting, finance, marketing, and strategy.', 'CAD 14,180 (Domestic) / CAD 64,810 (International) per year', 'January 15', true),
        (university_id, 'Master of Applied Science in Electrical and Computer Engineering', 'Master', 'Engineering', 'English', '2 years', 'Research-intensive program focusing on advanced topics in electrical and computer engineering with thesis component.', 'CAD 12,200 (Domestic) / CAD 54,900 (International) per year', 'December 15', true),
        (university_id, 'Life Sciences', 'Bachelor', 'Science', 'English', '4 years', 'Interdisciplinary program providing a foundation in biological, medical, and environmental sciences with specialized pathways.', 'CAD 6,100 (Domestic) / CAD 59,300 (International) per year', 'January 15', false);
        
        -- Clear any existing admission requirements for University of Toronto and add new ones
        DELETE FROM admission_requirements WHERE university_id = university_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (university_id, 'Academic', 'High academic achievement in senior secondary courses with specific prerequisites depending on program. For Canadian students: Minimum average in final year courses of 80-90% depending on program. For international students: Equivalent qualifications from recognized education systems.', 'U of T prioritizes consistent academic excellence. Focus on achieving high marks in prerequisite subjects for your desired program rather than just overall average.'),
        (university_id, 'Language', 'For non-native English speakers: TOEFL iBT (minimum 100 with at least 22 in writing), IELTS (minimum 6.5 with no band below 6.0), Cambridge Assessment (minimum 180), CAEL (minimum 70), or completion of an acceptable English language program.', 'U of T has higher English requirements than many Canadian universities. Strong writing skills are particularly important given the university''s emphasis on written assignments and research papers.'),
        (university_id, 'Documents', 'Online application, academic transcripts, English proficiency test results, supplementary application for certain programs (personal statement, portfolio, or writing sample).', 'Some competitive programs require supplementary applications. Use these to demonstrate your specific interest in the program and relevant experiences beyond academics.'),
        (university_id, 'Additional Requirements', 'Some programs may require interviews, auditions, portfolio submissions, or subject-specific testing. For example, Engineering requires a Student Profile Form, while Music requires an audition.', 'Research program-specific requirements well in advance. For competitive programs, exceptional supplementary materials can sometimes offset slightly lower grades.');
        
        -- Clear any existing scholarships for University of Toronto and add new ones
        DELETE FROM scholarships WHERE university_id = university_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (university_id, 'Lester B. Pearson International Scholarship', 'University', 'Full tuition, books, incidental fees, and residence for four years (valued at over CAD 250,000)', 'Prestigious scholarship for international students who demonstrate academic excellence, creativity, leadership, and community service.', 'International students nominated by their schools who demonstrate exceptional academic achievement and leadership.', 'Must be nominated by your school, followed by an application to the scholarship program.', 'School nomination: November, Full application: January', '2%'),
        (university_id, 'University of Toronto Scholars Program', 'University', 'CAD 7,500', 'Merit-based entrance scholarship for outstanding domestic and international students.', 'Outstanding students with high academic achievement. Automatically considered upon admission.', 'No separate application required; automatically considered during admission process.', 'Same as admission application', '15%'),
        (university_id, 'Faculty of Applied Science & Engineering Admission Scholarships', 'University', 'CAD 1,000 - CAD 10,000', 'Merit-based scholarships for students entering engineering programs.', 'Based on academic excellence and leadership potential. Some require financial need.', 'Some are automatic upon admission, others require an additional application.', 'Varies by specific scholarship', '20%');
        
        -- Clear any existing FAQs for University of Toronto and add new ones
        DELETE FROM university_faqs WHERE university_id = university_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (university_id, 'Does the University of Toronto have multiple campuses?', 'Yes, U of T has three campuses: St. George (downtown Toronto), Mississauga (UTM), and Scarborough (UTSC). Each has its own unique programs and campus culture, though students from all campuses earn the same U of T degree.'),
        (university_id, 'How does the college system work at U of T?', 'At the St. George campus, undergraduate students in the Faculty of Arts & Science belong to one of seven colleges. Your college provides academic support, residence, social activities, and scholarships. Each college has its own character and community, though all students take the same courses regardless of college affiliation.'),
        (university_id, 'What is the POSt system?', 'Program of Study (POSt) is U of T''s unique system where students typically apply to their major or specialist programs after first year. Admission to some competitive programs is based on first-year performance in prerequisite courses, while others are open to students who have completed the requirements.'),
        (university_id, 'Is housing guaranteed for first-year students?', 'First-year students are guaranteed housing if they meet certain conditions, including applying by the deadline. The guarantee applies to all three campuses but has specific requirements for each. Housing options range from traditional dormitories to apartment-style residences.'),
        (university_id, 'What career services does U of T offer?', 'Each campus has a career center offering services such as resume reviews, mock interviews, career counseling, job postings, networking events, and career fairs. U of T also has an extensive alumni network and industry connections across Canada and globally.');
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (university_id, 'Mei Zhang', 'https://randomuser.me/api/portraits/women/52.jpg', 'My experience at U of T has been intellectually stimulating and rewarding. The professors are leaders in their fields, and I''ve had opportunities to participate in cutting-edge research even as an undergraduate. The diverse student body brings perspectives from around the world, enriching class discussions and campus life. Though the academics are challenging, the support systems and resources have helped me thrive.', 5, true);
    END IF;
END $$; 
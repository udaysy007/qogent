-- Find the Heidelberg University university ID (assuming it already exists)
DO $$
DECLARE
    heidelberg_id uuid;
BEGIN
    -- Get the ID of Heidelberg University
    SELECT id INTO heidelberg_id FROM universities WHERE name = 'Heidelberg University';
    
    -- If Heidelberg University doesn't exist, we don't update anything
    IF heidelberg_id IS NOT NULL THEN
        -- Update Heidelberg University with enhanced data
        UPDATE universities
        SET 
            founding_year = 1386,
            campus_image_url = 'https://images.unsplash.com/photo-1584633155097-19e7753dba76?q=80&w=1200',
            student_population = 29000,
            international_student_percentage = 20,
            ranking_the = 42,
            ranking_arwu = 57,
            tuition_fee_domestic = 'No tuition fees; semester contribution of €171.80 per semester',
            tuition_fee_international = 'Non-EU students: €1,500 per semester plus €171.80 semester contribution',
            application_fee = 'None',
            other_fees = 'Administrative fees included in semester contribution',
            health_insurance = 'Mandatory health insurance: approximately €110 per month for students under 30',
            living_expense_accommodation = '€3,600 - €6,000 per year',
            living_expense_food = '€2,400 - €3,600 per year',
            living_expense_transportation = '€480 per year (public transport covered by semester ticket)',
            living_expense_other = '€1,800 - €3,000 per year',
            housing_info = 'Heidelberg University has student residences managed by Studierendenwerk, offering single rooms, apartments, and shared accommodations at affordable rates compared to the private market. However, these are limited and have waiting lists. The International Relations Office assists international students in finding accommodation, but many students live in private rentals or shared houses ("WGs") in the city.',
            campus_facilities = ARRAY['Libraries', 'Research Institutes', 'Laboratories', 'University Hospital', 'Sports Facilities', 'Canteens', 'Cultural Centers'],
            international_support = 'The International Relations Office provides comprehensive support for international students including pre-arrival guidance, orientation programs, language courses, and cultural integration activities. The International Study Centre offers preparatory courses and language training for international students.',
            clubs_info = 'Heidelberg University has numerous student organizations including subject-specific groups, political associations, cultural clubs, sports teams, and music ensembles. The university''s "Fachschaften" (student councils) organize academic and social events for their respective departments. The university orchestra, choir, and theater groups are particularly active.',
            admission_success_rate = '25%',
            students_placed = 510
        WHERE id = heidelberg_id;
        
        -- Clear any existing programs for Heidelberg University and add new ones
        DELETE FROM university_programs 
        WHERE university_id = heidelberg_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (heidelberg_id, 'Medicine', 'Bachelor/State Examination', 'Medicine', 'German', '6 years', 'One of Germany''s most prestigious medical programs combining fundamental biomedical science with clinical training at the renowned Heidelberg University Hospital.', '€171.80 per semester (EU) / €1,671.80 per semester (Non-EU)', 'July 15 (winter) / January 15 (summer)', true),
        (heidelberg_id, 'Physics', 'Bachelor', 'Science', 'German', '6 semesters', 'A rigorous program covering theoretical and experimental physics with access to cutting-edge research facilities and collaborations with international physics institutes.', '€171.80 per semester (EU) / €1,671.80 per semester (Non-EU)', 'July 15 (winter) / January 15 (summer)', true),
        (heidelberg_id, 'International Health', 'Master', 'Health Sciences', 'English', '1 year (full-time) or 2 years (part-time)', 'An interdisciplinary program addressing global health challenges with a focus on healthcare systems, epidemiology, and health policy in developing countries.', '€171.80 per semester (EU) / €1,671.80 per semester (Non-EU)', 'January 31', true),
        (heidelberg_id, 'Molecular Biosciences', 'Master', 'Science', 'English', '4 semesters', 'An internationally recognized program exploring molecular biology, biochemistry, and cell biology with specialization tracks and research placements at top institutes.', '€171.80 per semester (EU) / €1,671.80 per semester (Non-EU)', 'May 15', false);
        
        -- Clear any existing admission requirements for Heidelberg University and add new ones
        DELETE FROM admission_requirements 
        WHERE university_id = heidelberg_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (heidelberg_id, 'Academic', 'For Bachelor''s programs: Secondary school leaving certificate equivalent to the German Abitur. For Master''s programs: Relevant Bachelor''s degree with good grades (typically 2.5 or better in the German grading system). For Medical programs: Excellent grades and TMS (Test for Medical Studies) may be required.', 'Heidelberg''s admission process for undergraduate programs often uses the "Numerus Clausus" system, where your secondary school GPA is the main factor. For highly competitive programs like Medicine, even perfect grades may not guarantee admission without excellent performance on additional tests.'),
        (heidelberg_id, 'Language', 'For German-taught programs: DSH-2 or TestDaF 4 in all sections, or equivalent. For English-taught programs: IELTS (usually 6.5+), TOEFL (usually 90+ internet-based), or equivalent.', 'German language requirements are strictly enforced for German-taught programs. Consider taking a preparatory German course at Heidelberg''s International Study Centre if you don''t meet the requirements, as this can also help with cultural integration.'),
        (heidelberg_id, 'Documents', 'Application form, secondary school/university certificates, language certificates, CV, motivation letter (for some programs), passport copy, and health insurance proof.', 'For international applicants, all documents must typically be submitted as certified copies with official translations into German or English. Start the authentication process early, especially if your documents are from countries with complex certification procedures.'),
        (heidelberg_id, 'Additional Requirements', 'Some programs have subject-specific entrance exams or selection interviews. Art and music programs require portfolios or auditions. Medicine requires the TMS test. Some Master''s programs require GRE scores.', 'For programs like International Health that conduct interviews, demonstrate not only academic knowledge but also your understanding of global contexts and cross-cultural sensitivity. Heidelberg values students who show awareness of how their academic interests connect to broader societal challenges.');
        
        -- Clear any existing scholarships for Heidelberg University and add new ones
        DELETE FROM scholarships 
        WHERE university_id = heidelberg_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (heidelberg_id, 'Deutschlandstipendium', 'Federal Government and Private Donors', '€300 per month for at least two semesters', 'Merit-based scholarships for talented and high-achieving students regardless of nationality.', 'Bachelor''s and Master''s students with excellent academic records and social/community engagement.', 'Apply through the university''s online portal with academic records, CV, and motivation letter.', 'June 30 for winter semester', '10%'),
        (heidelberg_id, 'DAAD Scholarships', 'German Academic Exchange Service', 'Varies (typically covering living expenses and tuition)', 'Various scholarship programs for international students studying at German universities.', 'International students with excellent academic records. Specific requirements vary by program.', 'Apply directly through the DAAD portal with academic records, research proposal (for graduate students), and letters of recommendation.', 'Varies by program (typically October-December for the following academic year)', '15%'),
        (heidelberg_id, 'Heidelberg University Mobility Grants', 'University', '€500 - €1,000 (one-time payment)', 'Financial support for international students facing financial hardship or unexpected financial difficulties.', 'International students enrolled at Heidelberg University who can demonstrate financial need.', 'Apply through the International Relations Office with documentation of financial situation.', 'Rolling basis, applications reviewed monthly', '30%');
        
        -- Clear any existing FAQs for Heidelberg University and add new ones
        DELETE FROM university_faqs 
        WHERE university_id = heidelberg_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (heidelberg_id, 'What is Heidelberg University known for?', 'Heidelberg University (Ruprecht-Karls-Universität Heidelberg) is Germany''s oldest university, founded in 1386, and one of Europe''s most prestigious research institutions. It''s particularly renowned for excellence in medicine, life sciences, physics, and humanities. The university has associations with 56 Nobel Prize winners as faculty or alumni. Heidelberg consistently ranks among the top German universities and is part of the German "Excellence Initiative." Beyond academics, it''s known for its historic setting in the charming city of Heidelberg, with iconic landmarks like the university''s Old Aula and the nearby Heidelberg Castle creating a unique academic atmosphere that blends tradition with cutting-edge research.'),
        (heidelberg_id, 'How does the German university system work at Heidelberg?', 'The German university system offers considerable academic freedom compared to many other countries. Students choose their courses within their degree program requirements and often create their own study schedules. At Heidelberg, most programs follow the European Bologna system with Bachelor''s (usually 6 semesters) and Master''s degrees (usually 4 semesters). The academic year is divided into two semesters: winter (October-February) and summer (April-July). Each semester includes a lecture period and a lecture-free period for exams, papers, and independent study. German universities emphasize independent learning - lectures provide foundations, but students are expected to deepen their knowledge through self-study. Grading uses a 1-5 scale, with 1 being the best and 4 the minimum passing grade.'),
        (heidelberg_id, 'What is student life like in Heidelberg?', 'Heidelberg offers an exceptional student experience in a picturesque setting. The historic city center with its cobblestone streets, riverside location, and castle overlooking the town creates a magical atmosphere for studying. About 25% of Heidelberg''s population are students, giving the city a youthful energy. Student life centers around the "Altstadt" (old town) with its many cafes, bars, and student hangouts. Traditional student pubs like "Zum Roten Ochsen" have hosted generations of students. The university has numerous traditions including the ceremonial "Studentenkuss" chocolate, matriculation ceremonies in the Old Aula, and boat trips on the Neckar River. Student organizations offer everything from political debates to sports and cultural events. Many students participate in the traditional "Stocherkahnfahren" (punting on the Neckar) during summer months.'),
        (heidelberg_id, 'How difficult is it to get into Heidelberg University as an international student?', 'Admission competitiveness varies significantly by program. Programs like Medicine, Psychology, and Law are extremely competitive, with very high grade requirements and additional entrance tests. For these programs, even excellent applicants may face stiff competition. Other programs, particularly some Master''s degrees and programs in humanities, may be somewhat less competitive. International students face additional requirements, including having their qualifications recognized as equivalent to the German Abitur and demonstrating German language proficiency for German-taught programs. Heidelberg evaluates international credentials through uni-assist, which has specific requirements for each country''s educational system. The university operates on a "Numerus Clausus" system for many programs, setting minimum GPA thresholds that can change each semester based on demand.'),
        (heidelberg_id, 'What research opportunities are available for students at Heidelberg University?', 'Heidelberg offers extensive research opportunities across all academic levels. Undergraduate students can participate in research through seminars, lab rotations, and thesis projects. The university strongly emphasizes research-based learning, with many departments offering research internships and project-based courses. Graduate students have access to state-of-the-art facilities and interdisciplinary research centers like the Center for Molecular Biology (ZMBH), Heidelberg Center for American Studies, and the Marsilius Kolleg. Heidelberg is part of the German Excellence Initiative and hosts several Collaborative Research Centers funded by the German Research Foundation. The university maintains partnerships with nearby research institutions including the German Cancer Research Center (DKFZ), European Molecular Biology Laboratory (EMBL), and Max Planck Institutes, creating a rich ecosystem for scientific collaboration and innovation.');
        
        -- Delete any existing testimonials for Heidelberg University
        DELETE FROM testimonials 
        WHERE university_id = heidelberg_id;
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (heidelberg_id, 'Martin Schmidt', 'https://randomuser.me/api/portraits/men/55.jpg', 'Studying Molecular Biosciences at Heidelberg University has been a profoundly transformative experience. The program strikes a perfect balance between academic rigor and research innovation - lectures provide a solid theoretical foundation, while lab rotations offer hands-on experience with cutting-edge techniques. What makes Heidelberg truly special is the blend of tradition and innovation; you might discuss the latest CRISPR applications in a building that''s centuries old. The professors are not only leaders in their fields but also approachable mentors who genuinely care about student development. Beyond academics, living in Heidelberg itself has been magical - studying in cafes overlooking the Neckar River or hiking the Philosopher''s Way when you need a break from the lab. The international atmosphere means I''ve made friends from around the world, broadening my perspectives beyond science.', 5, true);
    END IF;
END $$; 
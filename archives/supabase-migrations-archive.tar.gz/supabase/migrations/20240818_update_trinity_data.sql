-- Find the Trinity College Dublin university ID (assuming it already exists)
DO $$
DECLARE
    university_id uuid;
BEGIN
    -- Get the ID of Trinity College Dublin
    SELECT id INTO university_id FROM universities WHERE name = 'Trinity College Dublin';
    
    -- If Trinity College Dublin doesn't exist, we don't update anything
    IF university_id IS NOT NULL THEN
        -- Update Trinity College Dublin with enhanced data
        UPDATE universities
        SET 
            founding_year = 1592,
            campus_image_url = 'https://images.unsplash.com/photo-1596394723269-e82228d0cb8b?q=80&w=1200',
            student_population = 18500,
            international_student_percentage = 28,
            ranking_the = 155,
            ranking_arwu = 151,
            tuition_fee_domestic = '€3,000 - €8,000 per year',
            tuition_fee_international = '€18,860 - €25,000 per year',
            application_fee = '€55',
            other_fees = 'Student contribution: €3,000 per year, Sports Centre: €120 per year',
            health_insurance = 'Approximately €200 - €700 per year depending on provider',
            living_expense_accommodation = '€7,000 - €14,000 per year',
            living_expense_food = '€3,000 - €4,000 per year',
            living_expense_transportation = '€1,000 - €1,500 per year',
            living_expense_other = '€2,000 - €3,000 per year',
            housing_info = 'Trinity offers on-campus accommodation for first-year students, though places are limited. The university also has partnerships with private student accommodation providers near campus. Most students live in privately rented accommodation throughout Dublin.',
            campus_facilities = ARRAY['Libraries', 'Sports Centre', 'Science Gallery', 'Students'' Union', 'Health Service', 'Cafes and Restaurants', 'Trinity Enterprise Centre'],
            international_support = 'The Global Room is a hub for international student support, offering orientation programs, cultural events, and advisory services. The International Student Society helps students integrate into campus life.',
            clubs_info = 'Trinity has over 120 societies and 50 sports clubs, ranging from debating to music, politics, and various sports. The Historical Society (the Hist) and the Philosophical Society (the Phil) are two of the world''s oldest student societies.',
            admission_success_rate = '25%',
            students_placed = 635
        WHERE id = university_id;
        
        -- Clear any existing programs for Trinity College Dublin and add new ones
        DELETE FROM university_programs WHERE university_id = university_id;
        
        -- Add featured programs
        INSERT INTO university_programs (
            university_id, name, degree, field, language, duration, description, tuition_fee, application_deadlines, is_popular
        ) VALUES
        (university_id, 'Computer Science', 'Bachelor', 'Technology', 'English', '4 years', 'A comprehensive program covering software development, artificial intelligence, data structures, and computational theory.', '€3,000 (EU) / €25,000 (Non-EU) per year', 'February 1', true),
        (university_id, 'International Business', 'Bachelor', 'Business', 'English', '4 years', 'Combines business education with language proficiency and includes a year studying abroad at a partner university.', '€3,000 (EU) / €21,000 (Non-EU) per year', 'February 1', true),
        (university_id, 'MSc in Computer Science (Intelligent Systems)', 'Master', 'Technology', 'English', '1 year', 'Advanced study in artificial intelligence, machine learning, and data analytics.', '€8,000 (EU) / €19,000 (Non-EU) per year', 'June 30', true),
        (university_id, 'Law (LL.B.)', 'Bachelor', 'Law', 'English', '4 years', 'A comprehensive legal education covering Irish, European, and international law.', '€3,000 (EU) / €22,000 (Non-EU) per year', 'February 1', false);
        
        -- Clear any existing admission requirements for Trinity College Dublin and add new ones
        DELETE FROM admission_requirements WHERE university_id = university_id;
        
        -- Add admission requirements
        INSERT INTO admission_requirements (
            university_id, type, description, qogent_insight
        ) VALUES
        (university_id, 'Academic', 'For EU students: Minimum required points for the course (based on Leaving Certificate or equivalent). For non-EU students: Strong academic record equivalent to Irish Leaving Certificate. For IB, typically 30-36 points depending on the course.', 'Trinity uses a points-based system for EU admissions. Focus on achieving high points in subjects relevant to your desired course.'),
        (university_id, 'Language', 'For non-native English speakers: IELTS score of 6.5 overall (with no band below 6.0), TOEFL iBT score of 90, or equivalent.', 'While meeting minimum requirements is sufficient, stronger English skills help with Trinity''s tutorial-based teaching style and extensive reading requirements.'),
        (university_id, 'Documents', 'Application through CAO (for EU students) or directly to Trinity (for non-EU), academic transcripts, personal statement, references, portfolio (for certain courses).', 'Your personal statement should emphasize genuine interest in your chosen subject and relevant extracurricular activities. For competitive courses, show how you stand out from other qualified applicants.'),
        (university_id, 'Interview', 'Interviews are not required for most undergraduate courses but may be used for certain programs like medicine, drama, and music.', 'If invited for an interview, research the department thoroughly and be prepared to discuss your academic interests, relevant experiences, and motivation for choosing Trinity.');
        
        -- Clear any existing scholarships for Trinity College Dublin and add new ones
        DELETE FROM scholarships WHERE university_id = university_id;
        
        -- Add scholarships
        INSERT INTO scholarships (
            university_id, name, provider, amount, description, eligibility, application_process, deadline, success_rate
        ) VALUES
        (university_id, 'Foundation Scholarship', 'University', 'Tuition fees plus €6,000 stipend', 'Historic and prestigious Trinity scholarship awarded based on a challenging examination. Scholars receive fee remission, free accommodation, and other benefits.', 'Second-year undergraduate students in all disciplines. Must pass rigorous scholarship exams.', 'Register for and sit Scholarship examinations, typically held in January.', 'December (for exam registration)', '3%'),
        (university_id, 'Global Excellence Scholarship', 'University', '€5,000 - €10,000', 'Merit-based scholarships for international undergraduate and postgraduate students demonstrating academic excellence.', 'Non-EU applicants with outstanding academic achievements. Automatically considered upon application.', 'No separate application required; considered automatically with admission application.', 'Same as course application deadline', '15%'),
        (university_id, 'Science Foundation Ireland Scholarships', 'Government', 'Full tuition and €18,500 stipend', 'Research scholarships for outstanding students in STEM disciplines at postgraduate level.', 'Excellent academic record in a relevant field, research proposal approved by a Trinity supervisor.', 'Apply through the School of Graduate Studies with a research proposal and supervisor support.', 'Varies by program', '12%');
        
        -- Clear any existing FAQs for Trinity College Dublin and add new ones
        DELETE FROM university_faqs WHERE university_id = university_id;
        
        -- Add FAQs
        INSERT INTO university_faqs (
            university_id, question, answer
        ) VALUES
        (university_id, 'What is special about Trinity College Dublin?', 'Trinity is Ireland''s oldest and most prestigious university, combining centuries of tradition with cutting-edge research and teaching. Located in the heart of Dublin, it offers a unique collegiate experience with a global reputation for excellence.'),
        (university_id, 'How does the trimester system work?', 'Trinity operates on a two-semester system, with Michaelmas Term (September-December) and Hilary Term (January-April), followed by Trinity Term for examinations (April-June). Most modules run for a full semester, with assessments at the end of each term.'),
        (university_id, 'What support services are available for international students?', 'Trinity offers comprehensive support including pre-arrival information, orientation programs, ongoing advisory services through the Global Room, visa and immigration assistance, English language support, and cultural integration activities.'),
        (university_id, 'Is accommodation guaranteed for first-year students?', 'Accommodation is not guaranteed for any students, but Trinity gives priority to first-year non-EU students in university housing. Students should apply early for university accommodation or explore private options through Trinity''s accommodation advisory service.'),
        (university_id, 'What is the Trinity Education?', 'The Trinity Education is a distinctive educational model that combines depth of disciplinary knowledge with breadth of skills and attributes. It emphasizes critical thinking, communication skills, global perspectives, and independent learning through research opportunities and co-curricular activities.');
        
        -- Add testimonials
        INSERT INTO testimonials (
            university_id, student_name, student_image, content, rating, featured
        ) VALUES
        (university_id, 'Aoife O''Sullivan', 'https://randomuser.me/api/portraits/women/33.jpg', 'Studying at Trinity has been a transformative experience. The beautiful historic campus in the heart of Dublin provides an inspiring environment for learning. The professors are world-class experts who genuinely care about student success. Beyond academics, I''ve made lifelong friends through societies and enjoyed the vibrant student life that Trinity offers.', 5, true);
    END IF;
END $$; 